Config                            = {}

Config.DrawDistance 			  = 20.0
Config.MarkerType                 = {Cloakrooms = 20, Armories = 21, Kantine = 2, BossActions = 20, Vehicles = 36, Helicopters = 34, Bevisskab = 20}
Config.MarkerSize 				  = {x = 1.5, y = 1.5, z = 1.0}
Config.MarkerColor 				  = {r = 50, g = 50, b = 204}

Config.MinimumRang = 9 -- Minimum Rang for at tilgå bossmenuen.
Config.MinimumRangEvidence = 4 -- Minimum rank for at kunne fjerne ting fra Bevisskabet.
Config.UseProgbarAtTrafikzone = true -- Sæt denne til false, hvis man ikke skal bruge progressbarsne ved oprettelse/fjernelse af zoner. 
Config.useSkillbarCuffs = false -- Sæt den til false, hvis der ikke skal komme en skillbar, hvor man kan forsøge om at komme ud af håndjern.
Config.openTabletEvent = 'omik_polititablet:openTablet' -- Det er server eventets callerens trigger der skal stå her. Normal er omikkels polititablet
Config.openOpkaldslisteEvent = '' -- Samme princip som tablettens server event trigger.

Config.Politiforhandler = {
	SpawnLocation = vector3(458.8036, -983.0899, 25.69996), -- Lokationen for det købte køretøj
	SpawnHeading = 91.15152, -- Dens heading / Den vej den pejer imod
}

Config.PolitiStationer = {

	PD = {
		Peds = {
		},

		Bossmenu = {
			vector3(459.9138, -986.2681, 30.7281)
		},

		Cloakrooms = {
			vector3(471.7332, -981.5385, 30.6895),
		},

        ToggleServices = {
            vector3(443.0514, -981.8729, 30.6895),
			vector3(468.8667, -992.3887, 26.2733)
        },

		Bevisskab = {
			vector3(472.3821, -991.3701, 26.2733)
		},
		
		Kantine = {
			vector3(448.8136, -973.9819, 34.9702),
		},
		
        Vehicles = {
            {
				Spawner = vector3(461.7500, -981.1514, 25.7884), 
                Deleters = {
                    {coords = vector3(425.7895, -981.5742, 25.4305 - 0.95)},
                    {coords = vector3(434.6816, -976.1154, 25.4285 - 0.95)},
                },
                SpawnPoints = {
					{coords = vector3(450.2601, -975.7592, 25.4286), heading = 87.0381, radius = 1.0}
                }
            },
        },

		Helicopters = {
			{
				Spawner = vector3(461.1, -981.5, 43.6),
				Deleters = {
					vector3(449.5, -981.2, 42.7),
				},
				SpawnPoints = {
					{coords = vector3(449.5, -981.2, 43.6), heading = 92.6, radius = 10.0}
				}
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(1490.216, 3780.87, 32.21828), 
				Deleters = {
					vector3(1488.341, 3806.428, 30.61899 - 0.8),
				},
				SpawnPoints = {
					{coords = vector3(1488.341, 3806.428, 30.61899), heading = 31.23236, radius = 10.0}
				}
			}
		},

    },
	NOOSE = {

		Bossmenu = {},
		Cloakrooms = {
			vector3(2521.4485, -331.4314, 94.0923), 
			vector3(2516.9600, -344.9744, 101.8933)
		},

        ToggleServices = {
            vector3(2518.2815, -354.9325, 94.1372),
        },

		Bevisskab = {
		},
		
		Kantine = {
			vector3(2517.2393, -344.0090, 94.0922)
		},
		
        Vehicles = {
            {
				Spawner = vector3(2567.5181, -334.0564, 93.1218), 
                Deleters = { 
					{coords = vector3(2573.1064, -339.1346, 92.9928 - 0.87)}
                },
                SpawnPoints = {
					{coords = vector3(2573.1064, -339.1346, 92.9928), heading = 4.4668, radius = 2.0}
                }
            },
        }, 

		Helicopters = {
			{
				Spawner = vector3(10,10,10),
				Deleters = {
					vector3(10,10,10), 
				},
				SpawnPoints = {
					{coords = vector3(10,10,10), heading = 118.1854, radius = 10.0}
				}
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(-1622.706, -1171.073, 1.710228), 
				Deleters = {
					vector3(-1621.178, -1179.348, 0.7012084),
				},
				SpawnPoints = {
					{coords = vector3(-1621.178, -1179.348, 0.7012084), heading = 117.1476, radius = 10.0}
				}
			}
		},

    },

	VespucciPD = {

		Bossmenu = {
		},
		Cloakrooms = { 
			vector3(-547.3899, -131.2404, 38.7964),
			vector3(-561.9739, -116.6619, 42.2543),
		},

        ToggleServices = {
            vector3(-568.6724, -129.6411, 38.4365)
        },

		Bevisskab = {
		},
		
		Kantine = {
			vector3(-542.7868, -127.0959, 47.5148)
		},
		
        Vehicles = {
            {
				Spawner = vector3(-567.0606, -98.5990, 33.9055), 
                Deleters = { 
					{coords = vector3(-565.4732, -105.6920, 33.7545 - 0.9)},
					{coords = vector3(-576.9116, -77.7517, 33.3712 - 0.9)}
                },
                SpawnPoints = { 
					{coords = vector3(-572.5929, -97.3500, 33.3718), heading = 23.8664, radius = 2.0}
                }
            },
        }, 

		Helicopters = {
			{
				Spawner = vector3(-561.9389, -117.1131, 51.9861),
				Deleters = {
					vector3(-565.7149, -123.5271, 51.9871 - 0.9), 
				},
				SpawnPoints = {
					{coords = vector3(-565.7149, -123.5271, 51.9871), heading = 199.1119, radius = 5.0}
				}
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(0.0,0.0,0.0), 
				Deleters = {
					vector3(0.0,0.0,0.0),
				},
				SpawnPoints = {
					{coords = vector3(0.0,0.0,0.0), heading = 0.0, radius = 10.0}
				}
			}
		},

    },

	grsrapd = {

		Bossmenu = {},
		Cloakrooms = {
			vector3(-413.9792, -361.4619, 25.0989)
		},

        ToggleServices = {
			vector3(-378.6427, -351.6355, 31.6546),
        },

		Bevisskab = {
		},
		
		Kantine = {
			vector3(-374.5806, -350.8800, 43.5977),
		},

		Vehicles = {
			{
				Spawner = vector3(-386.6354, -373.5328, 24.7567),
				Deleters = {
					{coords = vector3(-385.4509, -369.6317, 24.7567 - 0.8)}
				},
				SpawnPoints = {
					{coords = vector3(-385.4509, -369.6317, 24.7567), heading = 46.598281860352, radius = 6.0}
				}
			},
		},

		Helicopters = {
			{
				Spawner = vector3(-401.6610, -350.0456, 70.9539), 
				Deleters = {
					vector3(-394.1097, -337.4543, 72.8394 - 0.8),
				},
				SpawnPoints = {
					{coords = vector3(-394.1097, -337.4543, 72.8394), heading = 314.8522644043, radius = 10.0}
				}
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(-1068.6492, -955.3427, 2.3988), 
				Deleters = {
					vector3(-1064.3021, -960.0785, -1.4665),
				},
				SpawnPoints = {
					{coords = vector3(-1064.3021, -960.0785, -1.4665), heading = 273.6794, radius = 10.0}
				}
			}
		},

	},
    

	WeazelPD = {

		Bossmenu = {
		},
		Cloakrooms = { 
			vector3(-568.4925, -911.9328, 23.8590),
		},

        ToggleServices = {
            vector3(-587.6931, -929.7646, 23.8590)
        },

		Bevisskab = {
		},
		
		Kantine = {
			vector3(-574.7379, -929.2467, 28.6955)
		},
		
        Vehicles = {
            {
				Spawner = vector3(-567.7361, -926.3801, 18.1197), 
                Deleters = { 
					{coords = vector3(-562.5342, -935.0912, 18.1197 - 0.9)},
					{coords = vector3(-559.6251, -914.5873, 23.8590 - 0.9)}
                },
                SpawnPoints = { 
					{coords = vector3(-562.4255, -934.8057, 17.6958), heading = 23.8664, radius = 2.0}
                }
            },
        }, 

		Helicopters = {
			{
				Spawner = vector3(-561.9389, -117.1131, 51.9861),
				Deleters = {
					vector3(-565.7149, -123.5271, 51.9871 - 0.9), 
				},
				SpawnPoints = {
					{coords = vector3(-565.7149, -123.5271, 51.9871), heading = 199.1119, radius = 5.0}
				}
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(0.0,0.0,0.0), 
				Deleters = {
					vector3(0.0,0.0,0.0),
				},
				SpawnPoints = {
					{coords = vector3(0.0,0.0,0.0), heading = 0.0, radius = 10.0}
				}
			}
		},

    },

    
    SANDYSHORES = {
		Bossmenu = {
			vector3(1844.8871, 3684.3831, 38.9293)
		},
		Cloakrooms = {
			vector3(1841.7963, 3679.6001, 34.1892)
		},
		
        ToggleServices = {
			vector3(1830.2288, 3683.2188, 34.3261),
        },

		Bevisskab = {
			vector3(1856.2429, 3679.9893, 34.3261),
		},
		
		Kantine = {
		},

		Vehicles = {
			{
				Spawner = vector3(1859.8771, 3681.3162, 34.3271),
				Deleters = {
					{coords = vector3(1868.0385, 3690.8953, 33.7364)}
				},
				SpawnPoints = {
					{coords = vector3(1862.7302, 3683.9368, 33.6797), radius = 3.0}
				}
			},
		},

		Helicopters = {
			{
				Spawner = vector3(1839.9218, 3668.2520, 38.9306),
				Deleters = {
					vector3(1833.5564, 3668.9131, 38.9306),
				},
				SpawnPoints = {
					{coords = vector3(1833.5564, 3668.9131, 38.9306), heading = 45.3042, radius = 10.0}
				} 
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(-283.1966, 6633.255, 7.440195),
				Deleters = {
					vector3(-289.795, 6637.713, -0.08971536),
				},
				SpawnPoints = {
					{coords = vector3(-289.795, 6637.713, -0.08971536), heading = 330.1169, radius = 10.0}
				}
			}
		},

    },
    
    PALETOBAY = {

		Bossmenu = {},
		Cloakrooms = {
			vector3(-458.87881469727, 6003.0307617188, 27.480108261108)
		},

        ToggleServices = {
			vector3(0.0, 0.0, 0.0),
        },

		Bevisskab = {
		},
		
		Kantine = {
			vector3(-439.92572021484, 5992.4462890625, 31.507518768311),
		},

		Vehicles = {
			{
				Spawner = vector3(-446.45742797852, 5981.2788085938, 26.458312988281),
				Deleters = {
					{coords = vector3(-432.39993286133, 5979.7861328125, 26.458320617676 - 0.8)}
				},
				SpawnPoints = {
					{coords = vector3(-431.06698608398, 5982.2080078125, 26.021595001221), heading = 46.598281860352, radius = 6.0}
				}
			},
		},

		Helicopters = {
			{
				Spawner = vector3(-452.07809448242, 6005.984375, 39.784313201904), 
				Deleters = {
					vector3(-451.88064575195, 5994.6513671875, 39.784328460693 - 0.8),
				},
				SpawnPoints = {
					{coords = vector3(-451.88064575195, 5994.6513671875, 39.784328460693), heading = 314.8522644043, radius = 10.0}
				}
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(3867.411, 4462.245, 2.724009), 
				Deleters = {
					vector3(3863.917, 4469.604, -0.4746888),
				},
				SpawnPoints = {
					{coords = vector3(3863.917, 4469.604, -0.4746888), heading = 273.6794, radius = 10.0}
				}
			}
		},

	},
    
    MLITITAERBASE = {

		Bossmenu = {},
		Cloakrooms = {
			vector3(-1779.1967, 2995.2981, 32.8096)
		},

        ToggleServices = {
        },

		Bevisskab = {
		},
		
		Kantine = {
		},

		Vehicles = {
			{
				Spawner = vector3(-1868.0509, 2960.6340, 32.8103),
				Deleters = {
					{coords = vector3(-1864.3180, 2955.0806, 32.8103 - 0.8)}
				},
				SpawnPoints = {
					{coords = vector3(-1864.9847, 2964.4822, 32.8103), heading = 59.5395, radius = 6.0}
				}
			},
		},

		Helicopters = {
			{
				Spawner = vector3(-1879.9414, 2816.2893, 32.8065), 
				Deleters = {
					vector3(-1877.0308, 2805.4351, 32.8065 - 0.8), 
				},
				SpawnPoints = {
					{coords = vector3(-1877.0308, 2805.4351, 32.8065), heading = 151.1263, radius = 10.0}
				}
			}
		},

		BoatGarage = {
			{
				Spawner = vector3(0,0,0), 
				Deleters = {
					vector3(0,0,0),
				},
				SpawnPoints = {
					{coords = vector3(0,0,0), heading = 273.6794, radius = 10.0}
				}
			}
		},

	}

}

Config.AuthorizedArmory = {
	{label = 'Tjenestepistol', weapon = 'WEAPON_COMBATPISTOL', ammo = 250},
	{label = 'M1911', weapon = 'WEAPON_HEAVYPISTOL', ammo = 250},
	{label = 'Fartmåler', weapon = 'WEAPON_MARKSMANPISTOL', ammo = 1},
	{label = 'Lommelygte', weapon = 'WEAPON_FLASHLIGHT', ammo = 1},
	{label = 'Politistav', weapon = 'WEAPON_NIGHTSTICK', ammo = 1},
	{label = 'G36K', weapon = 'WEAPON_SPECIALCARBINE', ammo = 250},
	{label = 'Peberspray', weapon = 'WEAPON_PEPPERSPRAY', ammo = 1},
	{label = 'Brandslukker', weapon = 'WEAPON_FIREEXTINGUISHER', ammo = 4000},
	{label = 'MP5', weapon = 'WEAPON_SMG', ammo = 250},
	{label = 'M-10', weapon = 'WEAPON_CARBINERIFLE', ammo = 250},
	{label = 'Tåregas', weapon = 'WEAPON_SMOKEGRENADE', ammo = 20},
	{label = 'Tag 30x Ammunition', item = 'ammo', amount = 30},
	{label = 'Lyddæmper', item = 'at_suppressor', amount = 1},
	{label = 'Våbenlygte', item = 'at_flashlight', amount = 1},
	{label = 'Våbensigte', item = 'at_scope', amount = 1},
	{label = 'Skudsikkervest', item = 'armour', amount = 1},
	{label = 'NIK-Kit', item = 'nikkit', amount = 1},
	{label = 'Gas maske', item = 'gasmask', amount = 1},
	{label = 'Blegeservietter', item = 'bleachwipes', amount = 1}, 
	{label = 'UV Lygte', item = 'uvlight', amount = 1},
	{label = 'Tag en Notesblok', item = 'cwnotepad', amount = 1},
	{label = 'Tag en Telefon', item = 'phone', amount = 1},
	{label = 'Tag en Radio', item = 'radio', amount = 1}, 
}

Config.Kantine = {
	{label = "Tag Burger x20", item = 'burger'},
	{label = "Tag Brød x20", item = 'bread'},
	{label = "Tag Vand x20", item = 'water'},
	{label = "Tag Cola x20", item = 'cola'},
}


Lang = {
	-- Menu
	['menu_main_title'] = 'Politi Menu',
	['citizen_interaction'] = 'Borger Interaktion',
	['vehicle_interaction'] = 'Køretøjs Interaktion',
	['traffic_menu'] = 'Trafik Menu',
	['show_police_badge'] = 'Vis Politi Skilt',
	['opkaldsliste'] = 'Opkaldsliste',
	['object_spawner'] = 'Object Menu',
	['clothes_menu'] = 'Tøj Menu',
	['police_tablet'] = 'Politi Database',
	['panic_button'] = 'Panik Knap',

	-- Rodet
	['numberplate'] = 'Indtast nummerplade',
	['ugyldig_nummerplade'] = 'Ugyldig nummerplade.',

	-- Omklædningen
	['cloakroom_title'] = 'Omklædningen',
	['citizen_wear'] = 'Civil Outfit',

	-- Trafikzone
	['trafikzone_title'] = 'Trafik Zone',
	['trafikzone_radius'] = 'Radius',
	['trafikzone_maxhastighed'] = 'Max Hastighed',
	['trafikzone_opret'] = 'Opret Zone',
	['trafikzone_slet'] = 'Slet Zone',
	['trafikzone_alert1'] = 'Du har en aktiv hastigheds zone - Slet den før du opretter en ny!',
	['trafikzone_alert2'] = 'Du oprettede en hastigheds zone',
	['trafikzone_alert3'] = 'Du fjernede din hastigheds zone.',
	['trafikzone_progbar1'] = 'Fjerner hastigheds zone..',
	['trafikzone_progbar2'] = 'Opretter hastigheds zone..',
	['trafikzone_progbar3'] = 'Kontrollere zonen..',
	['trafikzone_progbar4'] = 'Udsender hastigheds zone',
	['trafikzone_message1'] = 'Vi beder alle være opmærksomme på at der er pt. nedsat hastighed på ^*%s^r - på nuværende tidspunkt er alt trafik beordret til at køre med en maksimal hastighed på ^*%s km/h',
	['trafikzone_message2'] = 'Vi beder alle være opmærksomme på at der er pt. nedsat hastighed på ^*%s^r - på nuværende tidspunkt er alt trafik beordret til at holde stille.',

	-- Bossmenu
	['bossmenu_title'] = 'Bossmenu',
	['sell_vehicle_to_player'] = 'Sælg Civil Køretøjer',
	['bossmenu_menu'] = 'Tilgå Bossmenuen',

	-- Evindence
    ['evidence_label'] = 'Politiet - Bevis Materialer', 
    ['evidence_menu_list'] = 'Bevis Materialer',
    ['evidence_menu_list_title'] = 'Bevis Materialer',
    ['evidence_menu_insert'] = 'Indsæt',
    ['evidence_menu_insert_title'] = 'Indsæt Bevis Materialer',
    ['evidence_added_money'] = 'Tilføjede %s sorte penge til bevis materialerne.',
    ['evidence_added_item'] = 'Tilføjede %sx %s til bevis materialerne.',
    ['evidence_added_wep'] = 'Tilføjede 1x %s til bevis materialerne.',
    ['evidence_menu_remove'] = 'Fjern',
    ['evidence_menu_remove_title'] = 'Fjern Bevis Materialer',
    ['evidence_removed_money'] = 'Fjernede %s sorte penge fra bevis materialerne.',
    ['evidence_removed_item'] = 'Fjernede %sx %s fra bevis materialerne.',
    ['evidence_removed_wep'] = 'Fjernede 1x %s fra bevis materialerne.',
    ['evidence_amount'] = 'Antal',
    ['evidence_not_enough'] = 'Ugyldigt antal',
    ['evidence_type_number'] = 'Du skal angive et tal.',
    ['evidence_no_access'] = 'Du har ikke adgang til at fjerne ting fra bevis materialerne.',
    ['evidence_no_items'] = 'Der er ingen bevis materialer.',

	-- Object Spawner Menu
	['kegle'] = 'Kegle',
	['ulykke_skilt'] = 'Ulykke Skilt',
	['sommatter'] = 'Sømmåtter',
	['kasse'] = 'Kasse',
	['dirigerings_skilt'] = 'Dirigerings Skilt',
	['hardt_skilt'] = 'Hårdt Skilt',
	['blod_barriere'] = 'Blød Barriere',
	['krim_gazebo'] = 'KRIM Gazebo',
	['krim_arbejdeslys'] = 'KRIM Arbejdes Lys',

	-- Civilinteraktion
	['idcard_menu'] = 'ID-Kort',
	['toggle_handjern_blidt_menu'] = 'Toggle Håndjern (Blidt)',
	['toggle_handjern_hardt_menu'] = 'Toggle Håndjern (Hårdt)',
	['eskorter_menu'] = 'Eskorter',
	['put_in_vehicle_menu'] = 'Sæt i køretøj',
	['out_of_vehicle_menu'] = 'Tag ud af køretøj',
	['saetifaengsel'] = 'Sæt i fængsel',
	['give_fine_menu'] = 'Giv en bøde',
	['administrerlicense_menu'] = 'Administrer licens',

	-- Identitetskort
	['identitetskort_title'] = 'Personlig Informationer',
	['full_name'] = 'Fulde navn: %s %s',
	['dateofbirth'] = 'Fødselsdag: %s',
	['players_height'] = 'Højde: %s cm',
	['gender_man'] = 'Køn: Mand',
	['gender_woman'] = 'Køn: Kvinde',
	['gender_unknown'] = 'Køn: Ukendt',
	['licenses'] = '--- Licenser ---',
	['no_licenses'] = '<b>INGEN LICENSER</b>',

	-- Garage
	['politi_garage_title'] = 'Politi - Garage',
	['garage_took_vehicle'] = 'Du har taget et køretøj ud',
	['garage_vehicle_in_way'] = 'Der holder et køretøj i vejen',

	-- Clothingmenu
	['clothingmenu_title'] = 'Tøj Menu',
	['toggle_reflekt'] = 'Tag Reflektvest af/på',
	['toggle_hat'] = 'Tag Hat af/på',
	['toggle_hjelm']= 'Tag Hjelm af/på',
	['toggle_civilskilt'] = 'Tag Civil Skilt af/på',
	['toggle_gopro'] = 'Tag GoPro af/på',
	['toggle_vest'] = 'Tag Skudsikkervest af/på',

	-- Udbetalte Bøder
	['unpaid_bills_title'] = 'Administrer Ubetalte Bøder',
    ['unpaid_bills_menu_title'] = 'Administrer bøde',
    ['unpaid_bills_menu_edit'] = 'Redigér bøden',
    ['unpaid_bills_menu_edit_amount'] = 'Ændre beløbet af bøden (Nuværende beløb: %s DKK)',
    ['unpaid_bills_menu_remove'] = 'Fjern bøden',

	-- Køretøjsdetajler
    ['vehicle_info_title'] = 'Køretøjsinformation',
	['numberplate_info'] = 'Nummerplade: %s',
	['owner_of_vehicle_is_void'] = 'Ejeren af køretøjet er ukendt. (Muligvis stjålet)',
	['owner_of_vehicle'] = 'Ejer: %s',
	['owners_mobilenumber'] = 'Ejerens Telefon Nummer: %s',
	['owners_dob'] = 'Fødselsdags Dato: %s',
	['owners_height'] = 'Højde: %s (I cm)',
    ['pick_lock'] = 'Åbn Køretøj',
    ['impound_vehicle'] = 'Beslaglæg køretøj',
	['search_database'] = 'Søg efter Køretøjsinformation',

	-- Body Search Menu
	['body_search_title'] = 'Personens Inventar',
    ['weapon_label'] = '--- Våben ---',
    ['inventory_label'] = '--- Inventar ---',
    ['konfisker_sortepenge'] = 'Konfisker sorte penge: <span style="color:red;">%s kr.</span>',
    ['konfisker_vaben'] = 'Konfisker %s med %s skud',
    ['konfisker_inv'] = 'Konfisker %sx %s',

	-- Giv en Bøde
	['fine_title'] = 'Giv en Bøde',
	['fine_label'] = 'Samlet bøde: %s DKK',

	-- Andre menuer (Våbenskab, Kantine etc.)
	['kantine_title'] = 'Kantine',
	['vabenskab_title'] = 'Våbenskab',

	-- Progbars
	['tilgar_vabenskab'] = 'Tilgår våbenskab..',

	-- Notifys
	['notify_1'] = '<b>Politiet</b>',
	['notify_2'] = '<b>Skydebane</b>',
	['notify_3'] = '<b>Håndjern</b>',
	['notify_4'] = '<b>Politi Shortcuts</b>',
	['notify_5'] = '<b>Tøj Menu</b>',
	['notify_6'] = '<b>POLITIFORHANDLER</b>',
	['togglegps_true'] = 'Du har slået din GPS til.',
	['togglegps_false'] = 'Du har slået din GPS fra.',
	['not_police_or_on_duty'] = 'Enten så er du ikke betjent, ellers er du ikke på arbejde!',
	['license_removed'] = 'Du har fået fjernet dit %s',
	['officer_license_remove'] = 'Du har fjernet personens %s',
	['fine_has_been_sent'] = 'Bøden er nu blevet givet til: %s',
    ['no_fine_amount'] = 'Du skal angive et beløb!',
	['on_duty'] = 'Du er taget på vagt.',
	['off_duty'] = 'Du har stoppet din vagt.',
	['skydebane_exit_notify'] = '<b>Tak for besøget på Skydebanen.</b>\n<b>Håber du ramte godt. :D</b>',
	['skydebane_enter_notify'] = '<b>Velkommen til Skydebanen.</b>\n<b>God skydelyst. :)</b>',
	['your_not_on_work'] = 'Du er ikke på vagt.',
	['escape_from_cuffs_success'] = 'Du kom ud af dine håndjern',
	['escape_from_cuffs_failed'] = 'Du fejlede detsværre..',
	['no_vehicles_nearby'] = 'Der er intet køretøj tæt på dig..',
	['time_needs_to_be_in_minutes'] = 'Tiden skal være i minutter',
	['you_need_to_type_something_here'] = 'Du skal skrive noget her',
	['no_access_to_this']= 'Dette har du ikke adgang til.',
    ['vehicle_unlocked'] = 'Køretøjet blev låst op',
	['vehicle_impounded'] = 'Du har impoundet et køretøj',
	['you_got_vehicle'] = 'Du modtog et køretøj (%s), med nummerpladen %s. Køretøjet holder nu i en af politi garagerne.',
	['sold_veh'] = 'Du solgte et køretøj til %s, med nummerpladen %s.',
	['sat_player_in_prison'] = 'Du har nu fængslet %s i %s min',
    ['bill_edited_notify'] = 'Du ændrede bøden til %s DKK',
    ['bill_removed_notify'] = 'Du slettede bøden',
	['ugyldigt_nummer'] = 'Ugyldig nummer!',
    ['quantity_invalid'] = 'Ugyldig mængde!',
    ['you_confiscated'] = 'Du konfiskerede %sx %s fra %s',
    ['got_confiscated'] = '%sx %s blev konfiskeret af %s',
    ['you_confiscated_account'] = 'Du konfiskerede %s kr. (%s) fra %s',
    ['got_confiscated_account'] = 'DKK%s (%s) blev konfiskeret af %s',
    ['you_confiscated_weapon'] = 'Du konfiskerede %s fra %s med %s skud',
    ['got_confiscated_weapon'] = 'Dit %s med %s skud blev konfiskeret af %s',
	['too_long_away'] = 'Du er for langt væk fra personen',
	['too_long_away2'] = 'Ingen personer i nærheden. (Gå tættere på)',
	['clothingmenu_notify'] = 'Du tog din %s %s',
	['politiforhandler_notify1'] = 'Denne bil kan du ikke sælge..',
	['politiforhandler_notify2'] = 'Ingen i nærheden..',
	['got_item'] = 'Du modtog %sx %s, fra våbenskabet.',

	-- Helpnotify
	['tilga_koretojsmenu'] = 'Tryk %s for at tilgå Køretøjs Menuen.',
	['go_on_off_duty'] = 'Tryk %s for at gå %s arbejde.',
	['tilga_cloakroom'] = 'Tryk %s for at åbne Omklædningen.',
	['tilga_evidencemenu'] = 'Tryk %s for at tilgå Bevisskabet.',
	['tilga_bossmenu'] = 'Tryk %s for at tilgå virksomheds menuen.',
	['tilga_kantine'] = 'Tryk %s for at tilgå Kantinen.',
	['tilga_boatgarage'] = 'Tryk %s for at tilgå Båd Garagen.',
	['tilga_helicoptermenu'] = 'Tryk %s for at tilgå Helikopter Garagen.',
	['remove_vehicle'] = 'Tryk %s for at fjerne køretøj.',
	['escorting_person'] = 'Tryk %s for at <b>slippe personen</b>. \n%s for at sætte personen ind i nærmeste <b>køretøj</b>',
    ['impound_prompt'] = 'Tryk %s for at anullere beslaglægningen',

	-- 3dme
	['eskortere_personen']= '~o~## Eskortere personen ##',
	['slipper_personen'] = '~o~## Slipper personen ##',
	['saetter_i_koretoj'] = '~o~## Sætter personen ind i køretøjet ##',
	['visitere_personen'] = '~o~## Visitere personen ##',
	['tager_fra_koretoj'] = '~o~## Tager personen ud af køretøjet ##',
	['panikknap_3dme'] = '~o~## Trykker panikknap ##',

	-- Keymappings Navne
	['idkortpoliti'] = 'Tjek ID-Kort på den nærmeste person',
	['håndjernpeacefully'] = 'Toggle Håndjern (Blidt)',
	['håndjernhard'] = 'Toggle Håndjern (Hårdt)',
	['dragpoliti'] = 'Eskortere',
	['putinvehicle'] = 'Sæt person i køretøj',
	['outthevehicle'] = 'Tag personen ud af køretøj',
	['givenbøde'] = 'Giv en bøde',
	['vispolitiskilt'] = 'Vis Politi Skilt',

	-- Eyetarget
	['vehicle_interaction_eyetarget'] = 'Køretøjsinformationer',
	['tilga_vabenskabet'] = 'Tilgå våbenskabet',
}

Config.Uniforms = {
	['romeo'] = {
		name = 'Special Afdeling - Romeo',
        male = {
            tshirt_1 = 61,  tshirt_2 = 0,
            torso_1 = 200,   torso_2 = 0,
            decals_1 = 19,   decals_2 = 0,
            arms = 17,       arms_2 = 0,
            pants_1 = 40,   pants_2 = 0,
            shoes_1 = 25,   shoes_2 = 0,
            helmet_1 = 104,  helmet_2 = 0,
            chain_1 = 6,    chain_2 = 0,
            ears_1 = -1,     ears_2 = 0,
            mask_1 = 87,     mask_2     = 0,
            bproof_1 = 5,  bproof_2 = 0,
            bags_1 = 13,    bags_2 = 0,
            glasses_1 = 11,  glasses_2 = 0
        }
	},
	['langaermet'] = {
		name = 'Politi - Langærmet',
        male = {
            tshirt_1 = 15,  tshirt_2 = 0,
            torso_1 = 24,   torso_2 = 0,
            decals_1 = 24,   decals_2 = 0,
            arms = 11,       arms_2 = 0,
            pants_1 = 49,   pants_2 = 1,
            shoes_1 = 25,   shoes_2 = 0,
            helmet_1 = -1,  helmet_2 = 0,
            chain_1 = 8,    chain_2 = 0,
            ears_1 = -1,     ears_2 = 0,
            mask_1 = 120,     mask_2     = 0,
            bproof_1 = 3,  bproof_2 = 0,
            bags_1 = 3,    bags_2 = 0,
            glasses_1 = 0,  glasses_2 = 0
        }
	},
	['striktroje'] = {
		name = 'Politi - Striktrøje',
        male = {
            tshirt_1 = 15,  tshirt_2 = 0,
            torso_1 = 10,   torso_2 = 0,
            decals_1 = 24,   decals_2 = 0,
            arms = 11,       arms_2 = 0,
            pants_1 = 49,   pants_2 = 1,
            shoes_1 = 25,   shoes_2 = 0,
            helmet_1 = -1,  helmet_2 = 0,
            chain_1 = 8,    chain_2 = 0,
            ears_1 = -1,     ears_2 = 0,
            mask_1 = 120,     mask_2     = 0,
            bproof_1 = 3,  bproof_2 = 0,
            bags_1 = 3,    bags_2 = 0,
            glasses_1 = 0,  glasses_2 = 0
        }
	},
	['tshirt'] = {
		name = 'Politi - Grå T-Shirt',
        male = {
            tshirt_1 = 15,  tshirt_2 = 0,
            torso_1 = 4,   torso_2 = 0,
            decals_1 = 24,   decals_2 = 0,
            arms = 0,       arms_2 = 0,
            pants_1 = 49,   pants_2 = 1,
            shoes_1 = 25,   shoes_2 = 0,
            helmet_1 = -1,  helmet_2 = 0,
            chain_1 = 8,    chain_2 = 0,
            ears_1 = -1,     ears_2 = 0,
            mask_1 = 120,     mask_2     = 0,
            bproof_1 = 3,  bproof_2 = 0,
            bags_1 = 3,    bags_2 = 0,
            glasses_1 = 0,  glasses_2 = 0
        }
	},
	['indsatsleder'] = {
		name = 'Politi - Indsatsleder',
        male = {
            tshirt_1 = 15,  tshirt_2 = 0,
            torso_1 = 24,   torso_2 = 0,
            decals_1 = 24,   decals_2 = 0,
            arms = 11,       arms_2 = 0,
            pants_1 = 49,   pants_2 = 1,
            shoes_1 = 25,   shoes_2 = 0,
            helmet_1 = -1,  helmet_2 = 0,
            chain_1 = 8,    chain_2 = 0,
            ears_1 = -1,     ears_2 = 0,
            mask_1 = 120,     mask_2     = 0,
            bproof_1 = 9,  bproof_2 = 0,
            bags_1 = 69,    bags_2 = 0,
            glasses_1 = 0,  glasses_2 = 0
        }
	},
	['krim1'] = {
		name = 'Politi - Kriminalteknik Sæt #1',
        male = {
            tshirt_1 = 15,  tshirt_2 = 0,
            torso_1 = 44,   torso_2 = 0,
            decals_1 = 24,   decals_2 = 0,
            arms = 85,       arms_2 = 0,
            pants_1 = 49,   pants_2 = 0,
            shoes_1 = 25,   shoes_2 = 0,
            helmet_1 = -1,  helmet_2 = 0,
            chain_1 = 8,    chain_2 = 0,
            ears_1 = -1,     ears_2 = 0,
            mask_1 = 120,     mask_2     = 0,
            bproof_1 = 9,  bproof_2 = 3,
            bags_1 = 3,    bags_2 = 0,
            glasses_1 = 0,  glasses_2 = 0
        }
	},
	['krim2'] = {
		name = 'Politi - Kriminalteknik Sæt #2',
        male = {
            tshirt_1 = 15,  tshirt_2 = 0,
            torso_1 = 215,   torso_2 = 0,
            decals_1 = 24,   decals_2 = 0,
            arms = 85,       arms_2 = 0,
            pants_1 = 49,   pants_2 = 0,
            shoes_1 = 25,   shoes_2 = 0,
            helmet_1 = -1,  helmet_2 = 0,
            chain_1 = 8,    chain_2 = 0,
            ears_1 = -1,     ears_2 = 0,
            mask_1 = 120,     mask_2     = 0,
            bproof_1 = 9,  bproof_2 = 3,
            bags_1 = 3,    bags_2 = 0,
            glasses_1 = 0,  glasses_2 = 0
        }
	},
}

panikknap = function()
	RequestAnimDict('random@arrests')
	while not HasAnimDictLoaded('random@arrests') do Wait(10) end
	TaskPlayAnim(PlayerPedId(), 'random@arrests', 'generic_radio_chatter', 2.0, 2.0, 3000, 51, 0, false, false, false)
	local playerCoords = GetEntityCoords(PlayerPedId())
	streetNam= GetStreetNameAtCoord(playerCoords.x, playerCoords.y, playerCoords.z)
	streetName = GetStreetNameFromHashKey(streetNam)
	TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 5.0, 'panic_button', 1.0)
	ESX.TriggerServerCallback('Emil_police:server:getname', function (name)
		TriggerServerEvent('Emil_police:server:setGPS', playerCoords)
		TriggerServerEvent('fae-dispatch:alert', name.." er i nød!", "Assister hurtigst muligt.\nDer er automatisk blevet sat en GPS, til lokationen.", playerCoords, exports['fae-dispatch']:CoordToString(playerCoords))
	end)
	SetNewWaypoint(playerCoords.x, playerCoords.y)
end