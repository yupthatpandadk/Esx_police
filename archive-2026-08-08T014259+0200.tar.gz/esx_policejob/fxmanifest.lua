fx_version      'adamant'
game            'gta5'

author          'Emil X Lund.dk'
description     'Emil - Politijob'
version         '2.0.0'

dependencies {
    'es_extended',
    'mythic_notify'
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',
    'config.lua',
    'server/*.lua'
}

client_scripts {
    'config.lua',
    'client/*.lua'
}
shared_script '@es_extended/imports.lua'
shared_script '@ox_lib/init.lua'

escrow_ignore {
    'client/vehicle.lua',
    'config.lua',
}

lua54 'yes'
dependency '/assetpacks'