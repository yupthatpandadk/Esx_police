
RegisterNetEvent('esx_policejob:handcuff')
AddEventHandler('esx_policejob:handcuff', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'police' then
		TriggerClientEvent('esx_policejob:handcuff', target)
	else
		print(('esx_policejob: %s attempted to handcuff a player (not cop)!'):format(xPlayer.identifier))
	end
end)

RegisterNetEvent('Emil_police:server:setGPS')
AddEventHandler('Emil_police:server:setGPS', function(coords)
	TriggerClientEvent('Emil_police:client:setGPS', -1, coords)
end)

RegisterNetEvent('esx_policejob:unhandcuff')
AddEventHandler('esx_policejob:unhandcuff', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'police' then
		TriggerClientEvent('esx_policejob:unrestrain', target)
	else
		print(('esx_policejob: %s attempted to handcuff a player (not cop)!'):format(xPlayer.identifier))
	end
end)

ESX.RegisterServerCallback('esx_policejob:getVehicleFromPlate', function(source, cb, plate)
	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {
		['@plate'] = plate
	}, function(result)
		if result[1] ~= nil then

			MySQL.Async.fetchAll('SELECT firstname, lastname FROM users WHERE identifier = @identifier',  {
				['@identifier'] = result[1].owner
			}, function(result2)

				cb(result2[1].firstname .. ' ' .. result2[1].lastname, true)

			end)
		else
			cb('Ukendt', false)
		end
	end)
end)

ESX.RegisterServerCallback('Emil_police:server:tlfcheckup', function (source,cb,number)
	MySQL.query('SELECT * FROM phone_phones WHERE phone_number = @phone_number', {['@phone_number'] = number}, function(result)
		if result then
			for _, v in pairs(result) do
				MySQL.query('SELECT * FROM users WHERE identifier = @identifier', {['@identifier'] = v.id}, function(result2)
					if result2 then
						for a, o in pairs(result2) do
							cb(o.firstname..' '..o.lastname)
						end
					end
				end)
			end
		end
	end)
end)

ESX.RegisterServerCallback('Emil_policejob:server:checkItem', function (source, cb, item)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer.getInventoryItem(item).count >= 1 then
		cb(true)
	else
		cb(false)
	end
end)

ESX.RegisterServerCallback('Emil_police:server:checktelefonnumber', function (source,cb,fornavn,efternavn)
	MySQL.scalar('SELECT identifier FROM users WHERE firstname = @firstname AND lastname = @lastname', {['@firstname'] = fornavn, ['@lastname'] = efternavn}, function(identifier)
	MySQL.scalar('SELECT phone_number FROM phone_phones WHERE id = @id', {['@id'] = identifier}, function(phone_number)
		cb(phone_number)
	end)
	end)
end)

--[[RegisterNetEvent('Emil_policejob:server:itemHandle')
AddEventHandler('Emil_policejob:server:itemHandle', function (option, item)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer.getJob().name == 'police' then
		if option == 'rem' then
			xPlayer.removeInventoryItem(item, 1)
		elseif option == 'give' then
			xPlayer.addInventoryItem(item, 1)
		end
	end
end)]]

ESX.RegisterServerCallback('Emil_police:server:housecheckup', function (source,cb,number)
	MySQL.query('SELECT * FROM allhousing WHERE id = @id', {['@id'] = number}, function(result)
		if result then
			for _, v in pairs(result) do
				cb(v.ownername)
			end
		end
	end)
end)
RegisterNetEvent('esx_policejob:giveWeapon')
AddEventHandler('esx_policejob:giveWeapon', function(weaponName, ammo)
	local xPlayer = ESX.GetPlayerFromId(source)

	if ammo == nil then
		ammo = 250
	end

	if xPlayer.hasWeapon(weaponName) then
		xPlayer.removeInventoryItem(weaponName)
	end

	xPlayer.addInventoryItem(weaponName, 1)
	local data = {
		['Player'] = source,
		['Log'] = 'police_weaponshop',
		['Title'] = '👮 Taget våben fra Våbenskab',
		['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..'\n``Tog:`` '..weaponName..', med '..ammo..' skud.',
		['Color'] = 'blue',
	}

	TriggerEvent('Boost-Logs:SendLog', data)
end)

RegisterNetEvent('Emil_giveitems:Lyddaemper')
AddEventHandler('Emil_giveitems:Lyddaemper', function()
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addInventoryItem('suppressor', 2)
end)

RegisterServerEvent('XmX:giveItem')
AddEventHandler('XmX:giveItem', function(itemName, count)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name ~= 'police' then
		print(('esx_ambulancejob: %s attempted to spawn in an item!'):format(xPlayer.identifier))
		return
	end
	
	TriggerClientEvent('ox_lib:notify', xPlayer.source, {type = 'success', description = Lang['got_item']:format(count, ESX.GetItemLabel(itemName))})
	local data = {
		['Player'] = source,
		['Log'] = 'police_weaponshop',
		['Title'] = '👮 Taget items fra Våbenskab',
		['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..'\n``Tog:`` '..itemName..', antal '..count..'.',
		['Color'] = 'blue',
	}

	TriggerEvent('Boost-Logs:SendLog', data)
	if itemName == "armour" then
		exports.ox_inventory:AddItem(xPlayer.source, itemName, count, 100)
	else
		xPlayer.addInventoryItem(itemName, count)
	end
end)

RegisterServerEvent('Kantine:giveItem')
AddEventHandler('Kantine:giveItem', function(itemName)
	local xPlayer = ESX.GetPlayerFromId(source)

	local xItem = xPlayer.getInventoryItem(itemName)
	local count = 20
	xPlayer.addInventoryItem(itemName, count)
	local data = {
		['Player'] = xPlayer.source,
		['Log'] = 'policekantine',
		['Title'] = 'Politi - Kantine.',
		['Message'] = '``Spiller:`` '.. GetPlayerName(xPlayer.source) ..' - '..xPlayer.getName() ..' ``Tog:`` 1x - '..ESX.GetItemLabel(itemName) ,
	}
	TriggerEvent('Boost-Logs:SendLog', data)
end)

RegisterNetEvent('esx_policejob:drag')
AddEventHandler('esx_policejob:drag', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'police' then
		TriggerClientEvent('esx_policejob:drag', target, source)
	else
		print(('esx_policejob: %s attempted to drag (not cop)!'):format(xPlayer.identifier))
	end
end)

RegisterNetEvent('esx_policejob:drag2')
AddEventHandler('esx_policejob:drag2', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'police' then
		TriggerClientEvent('esx_policejob:drag2', target, source)
	else
		print(('esx_policejob: %s attempted to drag (not cop)!'):format(xPlayer.identifier))
	end
end)
RegisterNetEvent('esx_policejob:startdragStatus')
AddEventHandler('esx_policejob:startdragStatus', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'police' then
		TriggerClientEvent('esx_policejob:dragStatus', source, target)
	else
		print(('esx_policejob: %s attempted to drag (not cop)!'):format(xPlayer.identifier))
	end
end)

RegisterNetEvent('esx_policejob:putInVehicle')
AddEventHandler('esx_policejob:putInVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'police' then
		TriggerClientEvent('esx_policejob:putInVehicle', target)
	else
		print(('esx_policejob: %s attempted to put in vehicle (not cop)!'):format(xPlayer.identifier))
	end 
end)

RegisterNetEvent('esx_policejob:OutVehicle')
AddEventHandler('esx_policejob:OutVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.job.name == 'police' then
		TriggerClientEvent('esx_policejob:OutVehicle', target)
	else
		print(('esx_policejob: %s attempted to drag out from vehicle (not cop)!'):format(xPlayer.identifier))
	end
end)


ESX.RegisterServerCallback('esx_policejob:getOtherPlayerData', function(source, cb, target)
	local xPlayer = ESX.GetPlayerFromId(target)
	local result = MySQL.Sync.fetchAll('SELECT firstname, lastname, sex, dateofbirth, height FROM users WHERE identifier = @identifier', {
		['@identifier'] = xPlayer.identifier
	})

	local firstname = result[1].firstname
	local lastname  = result[1].lastname
	local sex       = result[1].sex
	local dob       = result[1].dateofbirth
	local height    = result[1].height

	local data = {
		name      = GetPlayerName(target),
		job       = xPlayer.job,
		inventory = xPlayer.inventory,
		accounts  = xPlayer.accounts,
		weapons   = xPlayer.loadout,
		firstname = firstname,
		lastname  = lastname,
		sex       = sex,
		dob       = dob,
		height    = height
	}


	TriggerEvent('esx_license:getLicenses', target, function(licenses)
		data.licenses = licenses
		cb(data)
	end)
end)

ESX.RegisterServerCallback('esx_policejob:getVehicleInfos', function(source, cb, plate)
	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {
		['@plate'] = plate
	}, function(result)
		local retrivedInfo = {plate = plate}

		if result[1] then
			-- is the owner online?
				MySQL.Async.fetchAll('SELECT firstname, lastname, phone_number, dateofbirth, height FROM users WHERE identifier = @identifier',  {
					['@identifier'] = result[1].owner
				}, function(result2)
					if result2[1] then
						MySQL.Async.fetchAll('SELECT phone_number FROM phone_phones WHERE id = @id',  {
							['@id'] = result[1].owner
						}, function(result3)
							retrivedInfo.owner = ('%s %s'):format(result2[1].firstname, result2[1].lastname)
							retrivedInfo.phone = ('%s'):format(result3[1].phone_number)
							retrivedInfo.birthday = ('%s'):format(result2[1].dateofbirth)
							retrivedInfo.height = ('%s'):format(result2[1].height)
							cb(retrivedInfo)
						end)
					else
						cb(retrivedInfo)
					end
				end)
		else
			cb(retrivedInfo)
		end
	end)
end)

function getPriceFromHash(vehicleHash, jobGrade, type)
	local vehicles = Config.AuthorizedVehicles[type][jobGrade]

	for k,v in ipairs(vehicles) do
		if GetHashKey(v.model) == vehicleHash then
			return v.price
		end
	end

	return 0
end

ESX.RegisterServerCallback('esx_policejob:getStockItems', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_police', function(inventory)
		cb(inventory.items)
	end)
end)

ESX.RegisterServerCallback('esx_policejob:getPlayerInventory', function(source, cb)

	local xPlayer    = ESX.GetPlayerFromId(source)
	local black_money = xPlayer.getAccount('black_money').money
	local money = xPlayer.getMoney()
	local items      = xPlayer.inventory
	local weapons = xPlayer.getLoadout()
  
	cb({
		money = money,
		black_money = black_money,
		items      = items,
		weapons      = weapons
	})
end)

AddEventHandler('onResourceStop', function(resource)
	if resource == GetCurrentResourceName() then
		TriggerEvent('esx_phone:removeNumber', 'police')
	end
end)

RegisterNetEvent('esx_policejob:updateBlip')
AddEventHandler('esx_policejob:updateBlip', function(data)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if data[3] then
        TriggerEvent("eblips:add", {name = '['..data[1]..' - '..data[2]..'] '..xPlayer.getName(), src = src, color = 3})
		local data = {
			['Player'] = xPlayer.source,
			['Log'] = 'policeGPS',
			['Title'] = 'Opdateret GPS',
			['Message'] = '``Betjent:`` '.. GetPlayerName(source) ..' - '..xPlayer.getName()..'\n``Badge:`` ' .. data[1] .. '\n`Valgte:` '..data[2],
		}
		TriggerEvent('Boost-Logs:SendLog', data)
    else
        TriggerEvent("eblips:remove", src)
		local data = {
			['Player'] = xPlayer.source,
			['Log'] = 'policeGPS',
			['Title'] = 'Slog GPS fra',
			['Message'] = '``Betjent:`` '.. GetPlayerName(source) ..' - '..xPlayer.getName(),
		}
		TriggerEvent('Boost-Logs:SendLog', data)
    end
end)

ESX.RegisterServerCallback('Emil_police:server:getname', function (source,cb)
    local xPlayer = ESX.GetPlayerFromId(source)
	cb(xPlayer.getName())
end)

AddEventHandler('playerDropped', function()
	-- Save the source in case we lose it (which happens a lot)
	local playerId = source

	-- Did the player ever join?
	if playerId then
		local xPlayer = ESX.GetPlayerFromId(playerId)

		-- Is it worth telling all clients to refresh?
		if xPlayer and xPlayer.job.name == 'police' then
			Citizen.Wait(5000)
			TriggerEvent("eblips:remove", playerId)
		end
	end
end)


RegisterNetEvent('esx_policejob:editBill')
AddEventHandler('esx_policejob:editBill', function(billId, amount)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    if not xPlayer.job.name == 'police' then
        print(('esx_policejob: %s prøvede at ændre i en bøde!'):format(xPlayer.identifier))
        return
    end

    MySQL.Async.execute('UPDATE billing SET amount = @amount, label = @label WHERE id = @id', {
        ['@amount'] = ESX.Math.Round(amount),
        ['@label'] = Lang['fine_label']:format(ESX.Math.GroupDigits(amount)),
        ['@id'] = billId
    }, function()
		TriggerClientEvent('ox_lib:notify', xPlayer.source, {type = 'inform', description = Lang['bill_edited_notify']:format(ESX.Math.GroupDigits(amount))})
    end)
end)

RegisterNetEvent('esx_policejob:removeBill')
AddEventHandler('esx_policejob:removeBill', function(billId, amount)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    if not xPlayer.job.name == 'police' then
        print(('esx_policejob: %s prøvede at ændre i en bøde!'):format(xPlayer.identifier))
        return
    end

    MySQL.Async.execute('DELETE FROM billing WHERE id = @id', {
        ['@id'] = billId
    }, function()
		TriggerClientEvent('ox_lib:notify', xPlayer.source, {type = 'inform', description = Lang['bill_removed_notify']})
    end)
end)

--========================
--==       ARREST       ==
--========================
RegisterServerEvent('esx_policejob:requestarrest')
AddEventHandler('esx_policejob:requestarrest', function(targetid, playerheading, playerCoords,  playerlocation)
    _source = source
    TriggerClientEvent('esx_policejob:getarrested', targetid, playerheading, playerCoords, playerlocation)
    TriggerClientEvent('esx_policejob:doarrested', _source)
end)


RegisterServerEvent('esx_policejob:requestarrest2')
AddEventHandler('esx_policejob:requestarrest2', function(targetid, playerheading, playerCoords,  playerlocation)
    _source = source
    TriggerClientEvent('esx_policejob:getarrested2', targetid, playerheading, playerCoords, playerlocation)
    TriggerClientEvent('esx_policejob:doarrested2', _source)
end)

RegisterServerEvent('esx_policejob:requestrelease')
AddEventHandler('esx_policejob:requestrelease', function(targetid, playerheading, playerCoords,  playerlocation)
    _source = source
    TriggerClientEvent('esx_policejob:getuncuffed', targetid, playerheading, playerCoords, playerlocation)
    TriggerClientEvent('esx_policejob:douncuffing', _source)
end)


RegisterServerEvent('esx_policejob:requestrelease2')
AddEventHandler('esx_policejob:requestrelease2', function(targetid, playerheading, playerCoords,  playerlocation)
    _source = source
    TriggerClientEvent('esx_policejob:getuncuffed2', targetid, playerheading, playerCoords, playerlocation)
    TriggerClientEvent('esx_policejob:douncuffing2', _source)
end)
local Shared = {}
Shared.StashSize = 500000
Shared.StashSlots = 40

RegisterNetEvent('Emil_policejob:server:createEvidence')
AddEventHandler('Emil_policejob:server:createEvidence', function (sagsNr)
	local source = source
	local name = 'politi_bevisskab_'..sagsNr
	exports.ox_inventory:RegisterStash(name, "Politi Bevisskab - Journal Nummer: "..sagsNr, Shared.StashSlots, Shared.StashSize)
	TriggerClientEvent('Emil_policejob:client:createEvidence', source, name)
end)


RegisterServerEvent('Emil_trafikzone:server:ZoneActivated')
AddEventHandler('Emil_trafikzone:server:ZoneActivated', function(msg, speed, radius, x, y, z)
    local xPlayer = ESX.GetPlayerFromId(source)

    local fal = 'Vigtig Meddelse'
    TriggerClientEvent('chat:addMessage', -1, {
        template = '<div style="padding: 0.5vw; background-color: rgba(22, 38, 64, 0.8); border-radius: 6px; display: inline-block; max-width: 500px; word-break: break-word;"><i class="fas fa-user-shield"></i> ^*Politiet @ {0}^r: {1}</div>',
        args = { fal, msg }
    })
	print('BESKED '..source)
    TriggerClientEvent('Emil_trafikzone:client:Zone', -1, speed, radius, x, y, z)
end)
RegisterServerEvent('Emil_trafikzone:server:Disable')
AddEventHandler('Emil_trafikzone:server:Disable', function(blip)
    TriggerClientEvent('Emil_trafikzone:client:RemoveBlip', -1)
end)
RegisterNetEvent('esx_policejob:shootingRangeWep')
AddEventHandler('esx_policejob:shootingRangeWep', function(suppressor)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    local xLoadout = xPlayer.getLoadout()

    if suppressor then
        for k,xWeapon in pairs(xLoadout) do
            if not xPlayer.hasWeaponComponent(xWeapon.name, 'suppressor') then
                xPlayer.addWeaponComponent(xWeapon.name, 'suppressor')
            end
        end
    else
        for k,xWeapon in pairs(xLoadout) do
            if xPlayer.hasWeaponComponent(xWeapon.name, 'suppressor') and xWeapon.name:lower() ~= 'weapon_specialcarbine_mk2' then
                xPlayer.removeWeaponComponent(xWeapon.name, 'suppressor')
            end
        end
        for k, xItem in pairs(xPlayer.inventory) do
            if xItem.name == 'suppressor' and xItem.count > 0 then
                xPlayer.removeInventoryItem(xItem.name, xItem.count)
            end
        end
    end
end)

RegisterNetEvent('esx_policejob:send')
AddEventHandler('esx_policejob:send', function (setting, info, info2)
	local xPlayer = ESX.GetPlayerFromId(source)
	if setting == 'bill' then
		local zPlayer = ESX.GetPlayerFromId(info)
		local data = {
			['Player'] = source,
			['Target'] = info,
			['Log'] = 'fineplayer',
			['Title'] = '👮 Giv en bøde',
			['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..' gav en bøde til '..GetPlayerName(info) ..' - '..zPlayer.getName()..' på ``'..info2..' kr.``',
			['Color'] = 'blue',
		}
	
        TriggerEvent('Boost-Logs:SendLog', data)
	elseif setting == 'license_removed' then
		local zPlayer = ESX.GetPlayerFromId(info)
		local data = {
			['Player'] = source,
			['Target'] = info,
			['Log'] = 'licenseremove',
			['Title'] = '👮 Fjern et Kørekort',
			['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..' fjernede ``'..info2..'`` kørtet fra: '..GetPlayerName(info) ..' - '..zPlayer.getName()..'',
			['Color'] = 'blue',
		}
	
        TriggerEvent('Boost-Logs:SendLog', data)
	elseif setting == 'visiter' then
		local zPlayer = ESX.GetPlayerFromId(info)
		local data = {
			['Player'] = source,
			['Target'] = info,
			['Log'] = 'visiter',
			['Title'] = '👮 Visterede en person',
			['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..' visiterede: '..GetPlayerName(info) ..' - '..zPlayer.getName()..'',
			['Color'] = 'blue',
		}
	
        TriggerEvent('Boost-Logs:SendLog', data)
	elseif setting == 'give_weapon' then
		local data = {
			['Player'] = source,
			['Log'] = 'police_weaponshop',
			['Title'] = '👮 Taget våben fra Våbenskab',
			['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..'\n``Tog:`` '..info..', med '..info2..' skud.',
			['Color'] = 'blue',
		}
	
        TriggerEvent('Boost-Logs:SendLog', data)
	elseif setting == 'give_item' then
		local data = {
			['Player'] = source,
			['Log'] = 'police_weaponshop',
			['Title'] = '👮 Taget items fra Våbenskab',
			['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..'\n``Tog:`` '..info..', antal '..info2..'.',
			['Color'] = 'blue',
		}
	
        TriggerEvent('Boost-Logs:SendLog', data)
	elseif setting == 'kantine' then
		local data = {
			['Player'] = source,
			['Log'] = 'police_kantine',
			['Title'] = '🍔 Tog mad fra Kantine',
			['Message'] = '' .. GetPlayerName(source) ..' - '..xPlayer.getName() ..'\n``Tog:`` '..info..', antal '..info2..'.',
			['Color'] = 'blue',
		}
	
        TriggerEvent('Boost-Logs:SendLog', data)
	end
end)