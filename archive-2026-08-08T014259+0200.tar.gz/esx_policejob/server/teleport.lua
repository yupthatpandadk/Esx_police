ESX.RegisterServerCallback('Emil_policejob:codes:getCodes', function(source, cb)
    MySQL.query('SELECT * FROM Emil_codes WHERE option = @option', {['@option'] = 'elevator'}, function(result)
        if result then
            for i = 1, #result do
                local row = result[i]
                cb(row.code)
            end
        else
            cb(1234)
        end
    end)
end)

lib.cron.new('0 * * * *', function(task, date)
    MySQL.update('UPDATE Emil_codes SET code = @code WHERE option = @option', {
        ['@code'] = math.random(1000,9999), ['@option'] = 'elevator'
    }, function(affectedRows)
    end)
end)