
ESX.RegisterServerCallback('Emil_vehicleshop:isPlateTaken', function(source, cb, plate)
	MySQL.Async.fetchAll('SELECT 1 FROM owned_vehicles WHERE plate = @plate', {
		['@plate'] = plate
	}, function(result)
		cb(result[1] ~= nil)
		
	end)
end)

RegisterNetEvent('Emil_dealership:giveVehicle')
AddEventHandler('Emil_dealership:giveVehicle', function (player, car, plate)
	local zPlayer = ESX.GetPlayerFromId(player)
	local xPlayer = ESX.GetPlayerFromId(source)
	if xPlayer.getJob().name ~= 'police' then 
		DropPlayer(source, 'Stop med at modde bro! Wtf....')
		return end
    MySQL.Async.execute('INSERT INTO owned_vehicles (owner, plate, vehicle) VALUES (@owner, @plate, @vehicle)',
    {
        ['@owner'] = zPlayer.identifier,
        ['@plate'] = plate,
		['@vehicle'] = json.encode({model = GetHashKey(car), plate = plate})
    }, function(rowsChanged)
		exports['t1ger_keys']:UpdateKeysToDatabase(plate, false)
    end)
end)