--#########################################
--#		     	   LOCALS            	  #
--#########################################

local CurrentActionData, dragStatus, currentTask, blipsCops = {}, {}, {}, {}, {}
local HasAlreadyEnteredMarker, isHandcuffed, hasAlreadyJoined = false, false, false, false, false
local playerInService, blipActive, isInService = false, false, false
local LastStation, LastPart, LastPartNum, LastEntity, CurrentAction
local HandjernBlidt = false
local HandjernHaardt = false
local getOnDuty = {active = false, timer = 0}
dragStatus.isDragged, isInShopMenu = false, false


--#########################################
--#		     	  ESX FUNC            	  #
--#########################################


Citizen.CreateThread(function()
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	for stationNum, station in pairs(Config.PolitiStationer) do
        if station.Peds then
            for i=1, #station.Peds, 1 do
                local Peds = station.Peds[i]

                local coords = vector3(Peds.x, Peds.y, Peds.z)
				createNPC(coords, Peds.w)

                SetEntityInvincible(ped, true)
                FreezeEntityPosition(ped, true)
            end
        end
    end

	ESX.PlayerData = ESX.GetPlayerData() 
end)
				
createNPC = function(coords, heading)
	local lmodel = (true) and GetHashKey('s_m_m_ciasec_01') or GetHashKey(GetHashKey('s_m_m_ciasec_01'))
	RequestModel(lmodel)
	while not HasModelLoaded(lmodel) do
		Wait(10)
	end
	lPed = CreatePed(4, lmodel, coords, heading, false, false)
	SetEntityInvincible(lPed, true)
	FreezeEntityPosition(lPed, true)
	SetBlockingOfNonTemporaryEvents(lPed, true)
	SetAmbientVoiceName(lPed, "s_m_y_dealer_01")
	SetModelAsNoLongerNeeded(lmodel)
end

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job

end)

AddEventHandler('esx:onPlayerDeath', function(data)
	isDead = true
end) 

exports.qtarget:AddTargetModel({`s_m_m_ciasec_01`}, {
	options = {
        {
			icon = "fa-solid fa-gun", --<i class="fa-solid fa-gun"></i>
			label = Lang['tilga_vabenskabet'],
            job = 'police',
            action = function()
				exports['progressBars']:startUI(300, Lang['tilgar_vabenskab'])
				Citizen.Wait(302)
                OpenArmoryMenu()
			end,
		},
	},
	distance = 2
})


--#########################################
--#		     	POLITIMENU            	  #
--######################################### 

function PolitiMenu()
	ESX.UI.Menu.CloseAll()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'police_actions', {
		title    = Lang['menu_main_title'],
		align    = 'top-left',
		elements = {
			{label = Lang['citizen_interaction'], value = 'citizen_interaction'},
			{label = Lang['vehicle_interaction'], value = 'vehicle_interaction'}, 
			{label = Lang['traffic_menu'], value = 'traffic_menu'}, 
			{label = 'Politi Emotes', value = 'animations'},
			{label = 'Database Opsøgning', value = 'opsogningdatabase'},
			{label = Lang['show_police_badge'], value = 'show_police_badge'},
			{label = Lang['object_spawner'], value = 'object_spawner'},
			{label = Lang['clothes_menu'], value = 'clothes_menu'},
			{label = 'GPS Funktioner', value = 'gpsFunctions'},
            {label = Lang['panic_button'], value = 'panic_button'},
	}}, function(data, menu)
		local closestPlayer = ESX.Game.GetClosestPlayer()
		if data.current.value == 'citizen_interaction' then
			TriggerEvent('Emil-politimenu:civilinteraktion')
		elseif data.current.value == 'vehicle_interaction' then
			TriggerEvent('Emil-politimenu:koretojsinteraktion')
        elseif data.current.value == 'traffic_menu' then
            TrafficMenu()
		elseif data.current.value == 'animations' then
			OpenAnimMenu()
		elseif data.current.value == 'opsogningdatabase' then
            menu.close()
			Database()
		elseif data.current.value == 'gpsFunctions' then
            menu.close()
			ExecuteCommand('+GPSmenu')
		elseif data.current.value == 'clothes_menu' then
			TriggerEvent('Emil-politimenu:clothesmenu')
		elseif data.current.value == "object_spawner" then
			TriggerEvent('Emil-politimenu:objectspawner')
		elseif data.current.value == 'show_police_badge' then
			TriggerEvent('Emil-politimenu:ShowPoliceBagde')
		elseif data.current.value == 'police_tablet_trigger' then
			TriggerServerEvent(Config.openTabletEvent)
        elseif data.current.value == 'panic_button' then
			TriggerEvent('Emil-politimenu:panikknap')
		end
	end, function (data2, menu)
		menu.close()
	end)
end
local deleteableprops = {
	'prop_roadcone01a',
	'prop_barrier_work05',
	'p_ld_stinger_s',
	'prop_boxpile_07d',
	'prop_mp_arrow_barrier_01',
	'prop_mp_barrier_02b',
	'prop_barrier_work06a',
	'prop_roadpole_01b',
	'prop_paint_brush01',
	'prop_gazebo_02',
	'prop_worklight_03b'
}
exports.qtarget:AddTargetModel(deleteableprops, {
	options = {
		{
			icon = "fas fa-trash-alt",
			label = "Fjern Objekt",
			job = 'police',
			num = 1,
			action = function(entity)
				DeleteLocalObject(entity)
			end,
			canInteract = function()
				return isInService
			end,
		},
	},
	distance = 2.0
})

DeleteLocalObject = function(object)
    local attempt = 0
    while not NetworkHasControlOfEntity(object) and attempt < 100 and DoesEntityExist(object) do
        Wait(100)
        NetworkRequestControlOfEntity(object)
        attempt = attempt + 1
    end

    if DoesEntityExist(object) and NetworkHasControlOfEntity(object) then
        ESX.Game.DeleteObject(object)
    end
end

OpenAnimMenu = function()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'citizen_interaction', {
		title    = 'Politi Emotes',
		align    = 'left',
		elements = {
			{label = 'Hold Vest #1', value = 'holdvest'},
			{label = 'Hold Vest #2', value = 'holdvest2'},
			{label = 'Hold Vest #3', value = 'holdvest3'},
		}
	}, function(data2, menu2)
		local action = data2.current.value

		ExecuteCommand('p '..action)
	end, function(data2, menu2)
		menu2.close()
	end)
end

RegisterCommand('+GPSmenu', function()
	if ESX.GetPlayerData().job.name == 'police' then
		local input = lib.inputDialog('Sæt badgenummer og gruppe', {
			{type = 'input', label = 'Badge nummer', description = 'Angiv dit badge nummer (Ses på GPS)', icon = 'hashtag', required = true},
			{type = 'select', label = 'Vælg beredskab', description = 'Vælg dit beredskab, der skal vises på GPSen.', icon = 'building-shield', options = {
				{
					label = 'Indsatsleder', value = 'LIMA'
				},
				{
					label = 'Beredskabet', value = 'ALM'
				},
				{
					label = 'MC', value = 'MC'
				},
				{
					label = 'Civil', value = 'CIVIL'
				},
				{
					label = 'Romeo', value = 'ROMEO'
				},
				{
					label = 'Krim', value = 'Krim'
				}
			}},
			{type = 'select', label = 'GPS Status', icon = 'sliders', options = {
				{
					label = 'GPS Status 🟢', value = true
				},
				{
					label = 'GPS Status 🔴', value = false
				}
			}}
		})
		TriggerServerEvent('esx_policejob:updateBlip', input)
		if input[3] then
			lib.notify({
				title = 'GPS System',
				description = 'Du gik på GPSen som: '..input[1]..' - '..input[2],
				type = 'success'
			})
		else
			lib.notify({
				title = 'GPS System',
				description = 'Du gik af GPSen.',
				type = 'error'
			})
		end
	end
end)

--#########################################
--#		     	  FUNCTIONS            	  #
--#########################################

function OpenBevis(station)
	ESX.UI.Menu.CloseAll()
	local input = lib.inputDialog('Åben for Bevisskab', {'Sags Nr. / Journal Nr.'})

	if not input then return end
	TriggerServerEvent('Emil_policejob:server:createEvidence', input[1])
end
RegisterNetEvent('Emil_policejob:client:createEvidence')
AddEventHandler('Emil_policejob:client:createEvidence', function (name)
	TriggerEvent('ox_inventory:openInventory', 'stash', name)
end)

--[[
	0: Face\ 1: Mask\ 2: Hair\ 3: Torso\ 4: Bukser\ 5: Taske\ 6: Sko\ 7: Halskæde\ 8: Undertrøje\ 9: Skudsikkervest\ 10: Mærkater\ 11: Jakke
]]

function cleanPlayer(playerPed)
	SetPedArmour(playerPed, 0)
	ClearPedBloodDamage(playerPed)
	ResetPedVisibleDamage(playerPed)
	ClearPedLastWeaponDamage(playerPed)
    ResetPedMovementClipset(playerPed, 0)
end

function setUniform(uniform, playerPed, isArmor)
	TriggerEvent('skinchanger:getSkin', function(skin)
		local uniformObject

		if skin.sex == 0 then
			uniformObject = Config.Uniforms[uniform].male
		else
            if Config.Uniforms[uniform].female then
			    uniformObject = Config.Uniforms[uniform].female
            end
		end

		if uniformObject then
			TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
            TriggerEvent('skinchanger:getSkin', function(skin)
                TriggerServerEvent('esx_skin:save', skin)
            end)

			if isArmor then
                SetPedArmour(playerPed, 100)
                vestEquipped = true
                vestEquippedData = {bproof_1 = uniformObject.bproof_1, bproof_2 = uniformObject.bproof_2}
			end
		end
	end)
end
function OpenCloakroomMenu()
	local playerPed = PlayerPedId()

	local elements = {}

	table.insert(elements, {
		title = Lang['citizen_wear'],
		onSelect = function(args)
			cleanPlayer(PlayerPedId())
			ESX.TriggerServerCallback('fivem-appearance:getPlayerSkin', function(skin)
				TriggerEvent('skinchanger:loadSkin', skin)
			end)
		end
	})

    for k,v in pairs(Config.Uniforms) do
        if k ~= 'bullet_wear' then
            table.insert(elements, {
				title = v.name,
				onSelect = function(args)
					cleanPlayer(PlayerPedId())
					setUniform(k, PlayerPedId(), v.male.isArmor)
				end
            })
        end
    end
	
	lib.registerContext({
		id = 'cloakroom',
		title = 'Politi - Klædeskab',
		onExit = function()
		end,
		options = elements
	})
    lib.showContext('cloakroom')
end

function OpenKantineMenu(station)
	local playerPed = PlayerPedId()
	FreezeEntityPosition(playerPed, true)
	ESX.UI.Menu.CloseAll()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'kantine', {
		title    = Lang['kantine_title'],
		align    = 'top-left',
		elements = Config.Kantine
	}, function(data, menu)
		if data.current.item ~= nil then
			TriggerServerEvent('Kantine:giveItem', data.current.item, data.current.amount)
			TriggerServerEvent('esx_policejob:send', 'kantine', data.current.item, data.current.amount)
		end
	end, function(data, menu)
		menu.close()
		FreezeEntityPosition(playerPed, false)

		CurrentAction     = 'menu_kantine'
		CurrentActionData = {station = station}
	end)
end

BossmenuOpen = function()
	if ESX.PlayerData.job.grade >= Config.MinimumRang then
		local playerPed = PlayerPedId()
		ESX.UI.Menu.CloseAll()
	
		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'kantine', {
			title    = Lang['bossmenu_title'],
			align    = 'top-left',
			elements = {
				{label = Lang['bossmenu_menu'], value = 'openboss'},
				{label = Lang['sell_vehicle_to_player'], value = 'opensellvehicle'},
			}
		}, function(data, menu)
			local v = data.current.value
	
			if v == 'opensellvehicle' then
				TriggerEvent('Emil_chefmenu:police:openclient')
			elseif v == 'openboss' then
				-- TriggerEvent('Oliver-Menu:openBossMenu', 'police', function(data, menu)
				-- 	menu.close()
				-- end, { wash = false })
				exports["kylling_bossmenu"]:open('police')
			end
	
		end, function(data, menu)
			menu.close()
	
			CurrentAction     = 'menu_bossmenu'
			CurrentActionData = {station = station}
		end)
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end


LoadAnim = function(dict)
	while not HasAnimDictLoaded(dict) do
		RequestAnimDict(dict)
		Citizen.Wait(1)
	end
end

RegisterCommand("flip", function()
    local dict = "anim@mp_helmets@on_foot"
    local upAnim = "goggles_up"
    local downAnim = "goggles_down"

    LoadAnim(dict)

    local playerPed = PlayerPedId()
    local texture = GetPedPropTextureIndex(playerPed, 0)

    if GetPedPropIndex(playerPed, 0) == 2 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 7, texture, true)
        return
    end
    if GetPedPropIndex(playerPed, 0) == 7 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 2, texture, true)
        return
    end
    if GetPedPropIndex(playerPed, 0) == 106 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 107, texture, true)
        return
    end
    if GetPedPropIndex(playerPed, 0) == 107 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 106, texture, true)
        return
    end
    if GetPedPropIndex(playerPed, 0) == 3 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 2, texture, true)
        return
    end
    if GetPedPropIndex(playerPed, 0) == 91 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 92, texture, true)
        return
    end
    if GetPedPropIndex(playerPed, 0) == 92 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 91, texture, true)
        return
    end
end)


Database = function()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'citizen_interaction', {
		title    = 'Database Opsøgning',
		align    = 'left',
		elements = {
			{label = 'Opsøg person via. Tlf Nummer', value = 'tlfnummer'},
			{label = 'Opsøg nummer via. fulde navn', value = 'checkphonenumber'},
			{label = 'Opsøg huse via. ID', value = 'opsoghus'},
			{label = 'Opsøg person via. Hus-ID', value = 'husid'},
			{label = 'Søg hus-information via. HUs-ID', value = 'husid2'}
		}
	}, function(data2, menu2)
		local action = data2.current.value

		if action == 'tlfnummer' then
			ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'tlfnummer', {
				title = 'Personens Telefonnummer'
			}, function(data2, menu2)
				menu2.close()
				local number = tonumber(data2.value)
				ESX.TriggerServerCallback('Emil_police:server:tlfcheckup', function(name)
					lib.notify({
						description = 'Telefon nummeret: '..number..' blev slået op til: '..name,
						type = 'success'
					})
				end, number)
			end, function(data2, menu2)
				menu2.close()
			end)
		elseif action == 'husid' then
			ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'housecheckup', {
				title = 'Indskriv Hus-ID her'
			}, function(data2, menu2)
				menu2.close()
				local number = tonumber(data2.value)
				ESX.TriggerServerCallback('Emil_police:server:housecheckup', function(name)
					lib.notify({
						description = 'Hus-ID\'et: '..number..' blev slået op til: '..name,
						type = 'success'
					})
				end, number)
			end, function(data2, menu2)
				menu2.close()
			end)
		elseif action == 'husid2' then
			ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'housecheckup', {
				title = 'Indskriv Hus-ID her'
			}, function(data2, menu2)
				menu2.close()
				local number = tonumber(data2.value)
				TriggerServerEvent('Allhousing:getOwner', number)
			end, function(data2, menu2)
				menu2.close()
			end)
		elseif action == 'opsoghus' then
			ExecuteCommand('houses')
		elseif action == 'checkphonenumber' then
			local input = lib.inputDialog('Opsøg nummer via. fuldenavn', {'Fornavn', 'Efternavn'})

			if not input then return end
			ESX.TriggerServerCallback('Emil_police:server:checktelefonnumber', function(name)
				lib.notify({
					description = 'Navnet: '..input[1]..' '..input[2]..' blev slået op til nummeret: '..name,
					type = 'success'
				})
			end, input[1], input[2])
		end
	end, function(data2, menu2)
		menu2.close()
	end)
end
OpenIdentityCardMenu = function(closestPlayer)
    ESX.TriggerServerCallback("esx_policejob:getOtherPlayerData", function(data)
        if data then
            local elements = {}

            local nameLabel = Lang['full_name']:format(data.firstname, data.lastname)
            local dobLabel = Lang['dateofbirth']:format(data.dob)
            local heightLabel = Lang['players_height']:format(data.height)

			if data.sex then
				if string.lower(data.sex) == 'm' then
					sexLabel = Lang['gender_man']
				else
					sexLabel = Lang['gender_woman']
				end
			else
				sexLabel = Lang['gender_unknown']
			end

            table.insert(elements, {label = nameLabel, value = nil})
            table.insert(elements, {label = dobLabel, value = nil})
            table.insert(elements, {label = heightLabel, value = nil})
            table.insert(elements, {label = sexLabel, value = nil})

            if data.licenses then
                table.insert(elements, {label = '', value = nil})
                table.insert(elements, {label = Lang['licenses'], value = nil})

                if #data.licenses > 0 then
                    for i = 1, #data.licenses, 1 do
                        if data.licenses[i].label and data.licenses[i].type then
                            table.insert(elements, {
                                label = data.licenses[i].label,
                                type = data.licenses[i].type,
                                value = 'license',
                            })
                        end
                    end
                end

                if #data.licenses <= 0 then
                    table.insert(elements, {label = Lang['no_licenses'], value = nil})
                end
            end

            ESX.UI.Menu.Open("default", GetCurrentResourceName(), "citizen_interaction", {
                title = Lang['identitetskort_title'],
                align = "top-left",
                elements = elements
            }, function(data, menu)
                local value = data.current.value
                if value == 'license' then

                TriggerEvent("showNotification", Lang['officer_license_remove']:format(data.current.label), 'error')
                TriggerEvent("showNotification", GetPlayerServerId(closestPlayer), Lang['license_removed']:format(data.current.label), 'error')
				TriggerServerEvent('esx_policejob:send', 'license_removed', GetPlayerServerId(closestPlayer), data.current.label)
                TriggerServerEvent("esx_license:removeLicense", GetPlayerServerId(closestPlayer), data.current.type)
                TriggerServerEvent("esx_dmvschool:reloadLicenses", GetPlayerServerId(closestPlayer))
				end

                ESX.SetTimeout(300, function()
                    OpenIdentityCardMenu(closestPlayer)
                end)
            end, function(data, menu)
                menu.close()
            end)
        end
    end, GetPlayerServerId(closestPlayer))
end

function OpenFineMenu(player)
    ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'fine', {
        title    = Lang['fine_title'],
    }, function(data, menu)
        menu.close()
        if tonumber(data.value) > 0 then
            lib.notify({
                description = Lang['fine_has_been_sent']:format(GetPlayerServerId(player)),
                type = 'success'
            })
            TriggerServerEvent("esx_billing:sendBill", GetPlayerServerId(player), "society_police", Lang['fine_label']:format(ESX.Math.GroupDigits(data.value)), tonumber(data.value))
            TriggerServerEvent('esx_policejob:send', 'bill', GetPlayerServerId(player), data.value)
        else 
            lib.notify({
                description = Lang['no_fine_amount'],
                type = 'error'
            })
        end
    end, function(data, menu)
        menu.close()
    end)
end

function OpenFineMenu2(player)
	ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'fine', {
		title    = Lang['fine_title'],
	}, function(data, menu)
		menu.close()
		if tonumber(data.value) > 0 then
			lib.notify({
				description = Lang['fine_has_been_sent']:format(player),
				type = 'success'
			})
            TriggerServerEvent("esx_billing:sendBill", player, "society_police", Lang['fine_label']:format(ESX.Math.GroupDigits(data.value)), tonumber(data.value))
		else
			lib.notify({
				description = Lang['no_fine_amount'],
				type = 'error'
			})
		end
	end, function(data, menu)
		menu.close()
	end)
end


lib.registerContext({
	id = 'onoffduty',
	title = 'Gå af/på arbejde',
	onExit = function()
	end,
	options = {
		{
			title = 'Gå på arbejde',
			description = 'Gå på arbejde, som betjent.',
			arrow = true,
			onSelect = function(args)
				ToggleService()
			end
		},
		{
			title = 'Gå af arbejde',
			description = 'Gå af arbejde, som betjent.',
			arrow = true,
			onSelect = function(args)
				ToggleService2()
			end
		}
	}
})


RegisterCommand('toggleblip', function()
    if ESX.PlayerData.job.name == 'police' and playerInService then
        blipDisplay = not blipDisplay
        if blipDisplay then
			awaitService = true
			playerInService = true
			isInService = true
			TriggerServerEvent('esx_policejob:updateBlip', true)
			blipActive = true
			playerInService = true
			lib.notify({
				description = Lang['togglegps_true'],
				type = 'success'
			})
        else
			TriggerServerEvent('esx_policejob:updateBlip', false)
			isInService = false
			blipActive = false
			isInService = false
			playerInService = false
			awaitService = false
			lib.notify({
				description = Lang['togglegps_false'],
				type = 'error'
			})
        end
	else
		lib.notify({
			description = Lang['not_police_or_on_duty'],
			type = 'error'
		})
    end
end, false)

ToggleService = function()
	local player = PlayerId()
	if not isInService then
		awaitService = true
		playerInService = true
		isInService = true
		blipActive = true
		playerInService = true
		lib.notify({
			description = Lang['on_duty'],
			type = 'success'
		})
	end
end
ToggleService2 = function()
	local player = PlayerId()
	if isInService == true then
		lib.notify({
			description = Lang['off_duty'],
			type = 'error'
		})
		isInService = false
		blipActive = false
		isInService = false
		playerInService = false
		awaitService = false
	end
end

GetDutyStatus = function()
	return playerInService
end
exports('GetDutyStatus', GetDutyStatus)

GetVehicleInfosFromPlate = function()
    ESX.UI.Menu.Open("dialog", GetCurrentResourceName(), "fine_amount",  {
        title = Lang['numberplate']
    }, function(data, menu)
        menu.close()

        local plate = data.value
        if plate == nil then
			lib.notify({
				title = 'Nummerplade opsøgning',
				description = Lang['ugyldig_nummerplade'],
				type = 'error'
			})
            return
        end

        if plate ~= nil then
            GetVehicleInfos(plate)
        end
    end, function(data, menu)
        menu.close()
    end)
end

function OpenUnpaidBillsMenu(player)
	local elements = {}
	
	ESX.TriggerServerCallback('esx_billing:getTargetBills', function(bills)
		for k,bill in ipairs(bills) do
			table.insert(elements, {
				label = ('%s'):format(bill.label),
				billId = bill.id,
                amount = bill.amount
			})
		end

		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'billing', {
			title    = Lang['unpaid_bills_title'],
			align    = 'left',
			elements = elements
		}, function(data, menu)
            menu.close()
            if ESX.PlayerData.job.grade >= 4 then
                ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'billing_edit', {
                    title = Lang['unpaid_bills_menu_title'],
                    align = 'left',
                    elements = {
                        {label = Lang['unpaid_bills_menu_edit'], value = 'edit'},
                        {label = Lang['unpaid_bills_menu_remove'], value = 'remove'}
                }}, function(data2, menu2)
                    menu2.close()
                    if data2.current.value == 'edit' then
                        ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'billing_edit_menu', {
                            title = Lang['unpaid_bills_menu_edit_amount']:format(ESX.Math.GroupDigits(data.current.amount))
                        }, function(data3, menu3)
                            if tonumber(data3.value) then
                                menu3.close()
                                TriggerServerEvent('esx_policejob:editBill', data.current.billId, tonumber(data3.value))
                                OpenUnpaidBillsMenu(player)
                            else
								lib.notify({
									description = Lang['ugyldigt_nummer'],
									type = 'error'
								})
                            end
                        end, function(data3, menu3)
                            menu3.close()
                        end)
                    elseif data2.current.value == 'remove' then
                        TriggerServerEvent('esx_policejob:removeBill', data.current.billId)
                        OpenUnpaidBillsMenu(player)
                    end
                end, function(data2, menu2)
                    menu2.close()
                    OpenUnpaidBillsMenu(player)
                end)
            end
        end, function(data, menu)
			menu.close()
		end)
	end, player)
end

function OpenVehicleInfosMenu(vehicleData)
	ESX.TriggerServerCallback('esx_policejob:getVehicleInfos', function(retrivedInfo)
		local elements = {{label = Lang['numberplate_info']:format(retrivedInfo.plate)}}

		if not retrivedInfo.owner then
			table.insert(elements, {label = Lang['owner_of_vehicle_is_void']})
		else
			table.insert(elements, {label = Lang['owner_of_vehicle']:format(retrivedInfo.owner)})
			table.insert(elements, {label = Lang['owners_mobilenumber']:format(retrivedInfo.phone)})
			table.insert(elements, {label = Lang['owners_dob']:format(retrivedInfo.birthday)})
			table.insert(elements, {label = Lang['owners_height']:format(retrivedInfo.height)})
		end

		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_infos', {
			title    = Lang['vehicle_info_title'],
			align    = 'top-left',
			elements = elements
		}, nil, function(data, menu)
			menu.close()
		end)
	end, vehicleData.plate)
end 

function loadanimdict(dictname)
	if not HasAnimDictLoaded(dictname) then
		RequestAnimDict(dictname) 
		while not HasAnimDictLoaded(dictname) do 
			Citizen.Wait(1)
		end
	end
end



--#########################################
--#		     	  THREADS            	  #
--#########################################
local wait = {}
Citizen.CreateThread(function()
	local wasDragged

	while true do
		Citizen.Wait(wait.Time)
		local playerPed = PlayerPedId()
		if isHandcuffed and dragStatus.isDragged then
			local targetPed = GetPlayerPed(GetPlayerFromServerId(dragStatus.CopId))

			if DoesEntityExist(targetPed) and IsPedOnFoot(targetPed) and not IsPedDeadOrDying(targetPed, true) then
				if not wasDragged then
					AttachEntityToEntity(playerPed, targetPed, 11816, 0.54, 0.54, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
					wasDragged = true
				else
					wait.Time = 1000
				end
			else
				wasDragged = false
				dragStatus.isDragged = false
				DetachEntity(playerPed, true, false)
			end
		elseif wasDragged then
			wasDragged = false
			DetachEntity(playerPed, true, false)
		else
			wait.Time = 500
		end
	end
end)



local onShootingRange = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(wait.Time2)

        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
            local playerPed = PlayerPedId()
            local coords = GetEntityCoords(playerPed)
            local doorPos = vector3(486.81, -1003.55, 30.69)

            if GetDistanceBetweenCoords(coords, doorPos, true) < 1.0 then
                onShootingRange = not onShootingRange
                TriggerServerEvent('esx_policejob:shootingRangeWep', onShootingRange)
                if onShootingRange then
					lib.notify({
						description = Lang['skydebane_enter_notify'],
						type = 'success'
					})
                    PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET')
					SetPedPropIndex(GetPlayerPed(-1), 0, 0, 0, true)
                else
					lib.notify({
						description = Lang['skydebane_exit_notify'],
						type = 'error'
					})
                    PlaySoundFrontend(-1, 'SHOOTING_RANGE_ROUND_OVER', 'HUD_AWARDS')
					SetPedPropIndex(GetPlayerPed(-1), 0, 11, 0, true)
					Citizen.Wait(4000)
                end
				wait.Time2 = 2500
			else
				wait.Time2 = 3000
            end
        else
			wait.Time2 = 30000
        end
    end
end)


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		local playerPed = PlayerPedId()

		if isHandcuffed then
			DisableControlAction(0, 24, true) -- Attack
			DisableControlAction(0, 257, true) -- Attack 2
			DisableControlAction(0, 25, true) -- Aim
			DisableControlAction(0, 263, true) -- Melee Attack 1
			DisableControlAction(0, 21, true) -- Melee Attack 1
			DisableControlAction(0, 45, true) -- Reload
			DisableControlAction(0, 22, true) -- Jump
			DisableControlAction(0, 44, true) -- Cover
			DisableControlAction(0, 37, true) -- Select Weapon
			DisableControlAction(0, 288,  true) -- Disable phone
			DisableControlAction(0, 289, true) -- Inventory
			DisableControlAction(0, 170, true) -- Animations
			DisableControlAction(0, 59, true) -- Disable steering in vehicle
			DisableControlAction(0, 71, true) -- Disable driving forward in vehicle
			DisableControlAction(0, 72, true) -- Disable reversing in vehicle
			DisableControlAction(2, 36, true) -- Disable going stealth
			DisableControlAction(0, 47, true)  -- Disable weapon
			DisableControlAction(0, 264, true) -- Disable melee
			DisableControlAction(0, 257, true) -- Disable melee
			DisableControlAction(0, 140, true) -- Disable melee
			DisableControlAction(0, 141, true) -- Disable melee
			DisableControlAction(0, 142, true) -- Disable melee
			DisableControlAction(0, 143, true) -- Disable melee
			DisableControlAction(0, 75, true)  -- Disable exit vehicle
			DisableControlAction(27, 75, true) -- Disable exit vehicle
			DisableControlAction(0, 23, true) -- Disable enter vehicle

			if IsEntityPlayingAnim(playerPed, 'mp_arresting', 'idle', 3) ~= 1 then
				ESX.Streaming.RequestAnimDict('mp_arresting', function()
					TaskPlayAnim(playerPed, 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0.0, false, false, false)
				end)
			end
		else
			Citizen.Wait(500)
		end
	end
end)


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
			local playerPed = PlayerPedId()
			local playerCoords = GetEntityCoords(playerPed)
			local isInMarker, hasExited, letSleep = false, false, true
			local currentStation, currentPart, currentPartNum

			for k,v in pairs(Config.PolitiStationer) do


				for i=1, #v.Kantine, 1 do
					local distance = #(playerCoords - v.Kantine[i])

					if distance <= Config.DrawDistance and distance >= 1.0 then
						DrawMarker(Config.MarkerType.Kantine, v.Kantine[i], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < 1.0 then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'Kantine', i
					end
				end
				
				for i=1, #v.Cloakrooms, 1 do
					local distance = #(playerCoords - v.Cloakrooms[i])

					--if distance < Config.DrawDistance and isInMarkerMenu == false then
					if distance <= Config.DrawDistance and distance >= 1.0 then
						DrawMarker(Config.MarkerType.Cloakrooms, v.Cloakrooms[i], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < 1.0 then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'Cloakroom', i
					end
				end
				
				for i=1, #v.ToggleServices, 1 do
					local distance = #(playerCoords - v.ToggleServices[i])

					if distance < Config.DrawDistance and distance >= 1.0 then
						DrawMarker(24, v.ToggleServices[i], 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.0, 1.0, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < Config.MarkerSize.x then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'ToggleService', i
					end
				end 

				for i=1, #v.Bossmenu, 1 do
					local distance = #(playerCoords - v.Bossmenu[i])

					if distance < Config.DrawDistance and distance >= 1.0 then
						DrawMarker(20, v.Bossmenu[i], 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.0, 1.0, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < Config.MarkerSize.x then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'Bossmenu', i
					end
				end 
				
				for i=1, #v.Bevisskab, 1 do
					local distance = #(playerCoords - v.Bevisskab[i])

					if distance <= Config.DrawDistance and distance >= 1.0 then
						DrawMarker(Config.MarkerType.Bevisskab, v.Bevisskab[i], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < 1.0 then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'Bevisskab', i
					end
				end

				for i=1, #v.Vehicles, 1 do 
					local distance = #(playerCoords - v.Vehicles[i].Spawner)

					if distance <= Config.DrawDistance and distance >= 1.0 then
						DrawMarker(36, v.Vehicles[i].Spawner, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, true, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < 1.0 then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'Vehicles', i
					end
					
					for j=1, #v.Vehicles[i].Deleters, 1 do
						local distance2 = #(playerCoords - v.Vehicles[i].Deleters[j].coords)

						if distance2 <= Config.DrawDistance and distance2 >= 1.0 then
							DrawMarker(25, v.Vehicles[i].Deleters[j].coords, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.0, 3.0, 3.0, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, false, 2, false, false, false, false)
							letSleep = false
						elseif distance2 <= 1.0 then
							letSleep = false
						end

						if distance2 < 1.0 then
							isInMarker, currentStation, currentPart, currentPartNum = true, k, 'del_veh', i
						end
					end
				end

				for i=1, #v.Helicopters, 1 do
					local distance =  #(playerCoords - v.Helicopters[i].Spawner)

					if distance <= Config.DrawDistance and distance >= 1.0 then
						DrawMarker(34, v.Helicopters[i].Spawner, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, true, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < 1.0 then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'Helicopters', i
					end

					for j=1, #v.Helicopters[i].Deleters, 1 do
						local distance2 = #(playerCoords - v.Helicopters[i].Deleters[j])

						if distance2 < Config.DrawDistance then
							DrawMarker(25, v.Helicopters[i].Deleters[j], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.5, 3.5, 3.5, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, false, 2, false, false, false, false)
							letSleep = false

							if distance2 < 3.5 then
								isInMarker, currentStation, currentPart, currentPartNum = true, k, 'del_veh', i
							end
						end
					end
				end

				for i=1, #v.BoatGarage, 1 do
					local distance =  #(playerCoords - v.BoatGarage[i].Spawner)

					if distance <= Config.DrawDistance and distance >= 1.0 then
						DrawMarker(20, v.BoatGarage[i].Spawner, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, true, false, false, false)
						letSleep = false
					elseif distance <= 1.0 then
						letSleep = false
					end

					if distance < 1.0 then
						isInMarker, currentStation, currentPart, currentPartNum = true, k, 'BoatGarage', i
					end

					for j=1, #v.BoatGarage[i].Deleters, 1 do
						local distance2 = #(playerCoords - v.BoatGarage[i].Deleters[j])

						if distance2 < Config.DrawDistance then
							DrawMarker(25, v.BoatGarage[i].Deleters[j], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.5, 3.5, 3.5, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, false, 2, false, false, false, false)
							letSleep = false

							if distance2 < 3.5 then
								isInMarker, currentStation, currentPart, currentPartNum = true, k, 'del_veh', i
							end
						end
					end
				end
			end

			if isInMarker and not HasAlreadyEnteredMarker or (isInMarker and (LastStation ~= currentStation or LastPart ~= currentPart or LastPartNum ~= currentPartNum)) then
				if
					(LastStation and LastPart and LastPartNum) and
					(LastStation ~= currentStation or LastPart ~= currentPart or LastPartNum ~= currentPartNum)
				then
					TriggerEvent('esx_policejob:hasExitedMarker', LastStation, LastPart, LastPartNum)
					hasExited = true
				end

				HasAlreadyEnteredMarker = true
				LastStation             = currentStation
				LastPart                = currentPart
				LastPartNum             = currentPartNum

				TriggerEvent('esx_policejob:hasEnteredMarker', currentStation, currentPart, currentPartNum)
			end

			if not hasExited and not isInMarker and HasAlreadyEnteredMarker then
				HasAlreadyEnteredMarker = false
				TriggerEvent('esx_policejob:hasExitedMarker', LastStation, LastPart, LastPartNum)
			end

			if letSleep then
				Citizen.Wait(500)
			end
		else
			Citizen.Wait(500)
		end
	end
end)

Citizen.CreateThread(function()
    while true do
        if getOnDuty.active then
            if getOnDuty.timer > 0 then
                getOnDuty.timer = getOnDuty.timer - 1
            else
                getOnDuty.active = false
                getOnDuty.timer = 0
            end
        end
        Citizen.Wait(1000)
    end
end)

-- Enter / Exit entity zone events
Citizen.CreateThread(function()
	local trackedEntities = {
		"prop_roadcone01a",
		"prop_roadcone02a",
		"prop_barrier_work05",
		"p_ld_stinger_s",
		"prop_boxpile_07d",
		"hei_prop_cash_crate_half_full",
		"prop_mp_arrow_barrier_01",
		"prop_mp_barrier_02b",
		"prop_barrier_work06a",
		'prop_roadpole_01b',
		'prop_paint_brush01',
		"prop_gazebo_02",
		"prop_worklight_03b"
	}

	while true do
		Citizen.Wait(500)

		local playerPed = PlayerPedId()
		local playerCoords = GetEntityCoords(playerPed)

		local closestDistance = -1
		local closestEntity   = nil

		for i=1, #trackedEntities, 1 do
			local object = GetClosestObjectOfType(playerCoords, 3.0, GetHashKey(trackedEntities[i]), false, false, false)

			if DoesEntityExist(object) then
				local objCoords = GetEntityCoords(object)
				local distance = #(playerCoords - objCoords)

				if closestDistance == -1 or closestDistance > distance then
					closestDistance = distance
					closestEntity   = object
				end
			end
		end

		if closestDistance ~= -1 and closestDistance <= 3.0 then
			if LastEntity ~= closestEntity then
				TriggerEvent('esx_policejob:hasEnteredEntityZone', closestEntity)
				LastEntity = closestEntity
			end
		else
			if LastEntity then
				TriggerEvent('esx_policejob:hasExitedEntityZone', LastEntity)
				LastEntity = nil
			end
		end
	end
end)
local firsttime = true
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if CurrentAction then

			if IsControlJustReleased(0, 38) and ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
                exports['id_helpnotify']:hideUI()

				if CurrentAction == 'menu_kantine' then
					if playerInService then
						OpenKantineMenu(CurrentActionData.station)
					else
						lib.notify({
							description = Lang['your_not_on_work'],
							type = 'error'
						})
					end
				elseif CurrentAction == 'menu_ToggleService' then
					if firsttime then
						ToggleService()
						firsttime = false
					else
						ToggleService2()
						firsttime = true
					end
				elseif CurrentAction == 'menu_bossmenu' then
					BossmenuOpen()
				elseif CurrentAction == 'menu_cloakroom' then
					OpenCloakroomMenu(CurrentActionData.station)
				elseif CurrentAction == 'menu_bevis' then
					if playerInService then
						OpenBevis(CurrentActionData.station)
					else
						lib.notify({
							description = Lang['your_not_on_work'],
							type = 'error'
						})
					end
				elseif CurrentAction == 'menu_vehicle_spawner' then
					if playerInService then
						OpenVehicleSpawnerMenu('car', CurrentActionData.station, CurrentActionData.part, CurrentActionData.partNum)
					else
						lib.notify({
							description = Lang['your_not_on_work'],
							type = 'error'
						})
					end
				elseif CurrentAction == 'Helicopters' then
					if playerInService then
						OpenVehicleSpawnerMenu('helicopter', CurrentActionData.station, CurrentActionData.part, CurrentActionData.partNum)
					else
						lib.notify({
							description = Lang['your_not_on_work'],
							type = 'error'
						})
					end
				elseif CurrentAction == 'BoatGarage' then
					if playerInService then
						OpenVehicleSpawnerMenu('BoatGarage', CurrentActionData.station, CurrentActionData.part, CurrentActionData.partNum)
					else
						lib.notify({
							description = Lang['your_not_on_work'],
							type = 'error'
						})
					end
				elseif CurrentAction == 'delete_vehicle' then
					if playerInService then
						ESX.Game.DeleteVehicle(CurrentActionData.vehicle)
					else
						lib.notify({
							description = Lang['your_not_on_work'],
							type = 'error'
						})
					end
				elseif CurrentAction == 'remove_entity' then
					DeleteEntity(CurrentActionData.entity)
				end

				CurrentAction = nil
			end
		end -- []

		if IsControlJustReleased(0, 167) and ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and not ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'police_actions') then
			if playerInService then
				PolitiMenu()
			else
				lib.notify({
					description = Lang['your_not_on_work'],
					type = 'error'
				})
			end
		end
		if IsControlJustReleased(0, 166) and ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
			lib.showContext('onoffduty')
		end
		if IsControlJustReleased(0, 38) and currentTask.busy then
			ESX.ClearTimeout(currentTask.task)
			ClearPedTasks(PlayerPedId())

			currentTask.busy = false
		end
	end
end)






--#########################################
--#		  	    EVENT HANDLER         	  #
--#########################################
AddEventHandler('playerSpawned', function(spawn)
	isDead = false
	TriggerEvent('esx_policejob:unrestrain')

	if not hasAlreadyJoined then
		TriggerServerEvent('esx_policejob:spawned')
	end
	hasAlreadyJoined = true
end)

AddEventHandler('esx_policejob:hasEnteredMarker', function(station, part, partNum)
	if part == 'Vehicles' then
		CurrentAction     = 'menu_vehicle_spawner'
		exports['id_helpnotify']:showUI(Lang['tilga_koretojsmenu']:format('<b>[E]</b>'))
		CurrentActionData = {station = station, part = part, partNum = partNum}
	elseif part == 'ToggleService' then
		CurrentAction     = 'menu_ToggleService'
		if firsttime then
			exports['id_helpnotify']:showUI(Lang['go_on_off_duty']:format('<b>[E]</b>', 'på'))
		else
			exports['id_helpnotify']:showUI(Lang['go_on_off_duty']:format('<b>[E]</b>', 'af'))
		end
		CurrentActionData = {}
	elseif part == 'Cloakroom' then
		CurrentAction     = 'menu_cloakroom'
		exports['id_helpnotify']:showUI(Lang['tilga_cloakroom']:format('<b>[E]</b>'))
		CurrentActionData = {}
	elseif part == 'Bevisskab' then
		CurrentAction     = 'menu_bevis'
		exports['id_helpnotify']:showUI(Lang['tilga_evidencemenu']:format('<b>[E]</b>'))
		CurrentActionData = {}
	elseif part == 'Kantine' then
		CurrentAction     = 'menu_kantine'
		exports['id_helpnotify']:showUI(Lang['tilga_kantine']:format('<b>[E]</b>'))
		CurrentActionData = {station = station, part = part, partNum = partNum}
	elseif part == 'Bossmenu' then
		CurrentAction     = 'menu_bossmenu'
		exports['id_helpnotify']:showUI(Lang['tilga_bossmenu']:format('<b>[E]</b>'))
		CurrentActionData = {station = station, part = part, partNum = partNum}
	elseif part == 'Helicopters' then
		CurrentAction     = 'Helicopters'
		exports['id_helpnotify']:showUI(Lang['tilga_helicoptermenu']:format('<b>[E]</b>'))
		CurrentActionData = {station = station, part = part, partNum = partNum}
	elseif part == 'BoatGarage' then
		CurrentAction     = 'BoatGarage'
		exports['id_helpnotify']:showUI(Lang['tilga_boatgarage']:format('<b>[E]</b>'))
		CurrentActionData = {station = station, part = part, partNum = partNum}
	elseif part == 'del_veh' then 
		local playerPed = PlayerPedId()
		local vehicle   = GetVehiclePedIsIn(playerPed, false)
		CurrentAction     = 'delete_vehicle'
		exports['id_helpnotify']:showUI(Lang['remove_vehicle']:format('<b>[E]</b>'))
		CurrentActionData = {vehicle = vehicle}
	end
end)

AddEventHandler('esx_policejob:hasExitedMarker', function(station, part, partNum)
	if not isInShopMenu then
		exports['id_helpnotify']:hideUI()
		ESX.UI.Menu.CloseAll()
	end

	CurrentAction = nil
end)

AddEventHandler('esx_policejob:hasEnteredEntityZone', function(entity)
	local playerPed = PlayerPedId()

	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and IsPedOnFoot(playerPed) then
		CurrentAction     = 'remove_entity'
		CurrentActionData = {entity = entity}
	end

	if GetEntityModel(entity) == GetHashKey('p_ld_stinger_s') then
		local playerPed = PlayerPedId()
		local coords    = GetEntityCoords(playerPed)

		if IsPedInAnyVehicle(playerPed, false) then
			local vehicle = GetVehiclePedIsIn(playerPed)

			for i=0, 7, 1 do
				SetVehicleTyreBurst(vehicle, i, true, 1000)
			end
		end
	end
end)

AddEventHandler('esx_policejob:hasExitedEntityZone', function(entity)
	if CurrentAction == 'remove_entity' then
		CurrentAction = nil
	end
end)



--#########################################
--#		  	   EVENT/NET EVENT         	  #
--#########################################
--[[
RegisterNetEvent('crp-police:handcuffPeacefully')
AddEventHandler('crp-police:handcuffPeacefully', function()
	ESX.TriggerServerCallback('Emil_policejob:server:checkItem', function(hasItem)
		if hasItem then
			if HandjernBlidt == false then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1))
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				if distance <= 2.0 then
					HandjernBlidt = true
					TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-on', 1.0)
					TriggerServerEvent('Emil_policejob:server:itemHandle', 'rem', 'handcuff')
					TriggerServerEvent('esx_policejob:requestarrest', target_id, playerheading, playerCoords, playerlocation)
				else
					ESX.ShowNotification('Du er ikke tæt nok på nogle..')
				end
			elseif HandjernBlidt == true then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1)) 
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				HandjernBlidt = false
				TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
				TriggerServerEvent('Emil_policejob:server:itemHandle', 'give', 'handcuff')
				TriggerServerEvent('esx_policejob:requestrelease', target_id, playerheading, playerCoords, playerlocation)
			end
		else
			if HandjernHaardt == true then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1))
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				HandjernHaardt = false
				TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
				TriggerServerEvent('Emil_policejob:server:itemHandle', 'give', 'handcuff')
				TriggerServerEvent('esx_policejob:requestrelease2', target_id, playerheading, playerCoords, playerlocation)
			elseif HandjernBlidt == true then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1)) 
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				HandjernBlidt = false
				TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
				TriggerServerEvent('Emil_policejob:server:itemHandle', 'give', 'handcuff')
				TriggerServerEvent('esx_policejob:requestrelease', target_id, playerheading, playerCoords, playerlocation)
			else
				lib.notify({
					title = 'Politiet',
					description = 'Du har ikke nogle håndjern på dig..',
					type = 'error'
				})
			end
		end
	end, 'handcuff')
end)

RegisterNetEvent('crp-police:handcuffHard')
AddEventHandler('crp-police:handcuffHard', function()
	ESX.TriggerServerCallback('Emil_policejob:server:checkItem', function(hasItem)
		if hasItem then
			if HandjernHaardt == false then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1))
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				if distance <= 2.0 then
					HandjernHaardt = true
					TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-on', 1.0)
					TriggerServerEvent('Emil_policejob:server:itemHandle', 'rem', 'handcuff')
					TriggerServerEvent('esx_policejob:requestarrest2', target_id, playerheading, playerCoords, playerlocation)
				else
					ESX.ShowNotification('Du er ikke tæt nok på nogle..')
				end
			elseif HandjernHaardt == true then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1))
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				HandjernHaardt = false
				TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
				TriggerServerEvent('Emil_policejob:server:itemHandle', 'give', 'handcuff')
				TriggerServerEvent('esx_policejob:requestrelease2', target_id, playerheading, playerCoords, playerlocation)
			end
		else
			if HandjernHaardt == true then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1))
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				HandjernHaardt = false
				TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
				TriggerServerEvent('Emil_policejob:server:itemHandle', 'give', 'handcuff')
				TriggerServerEvent('esx_policejob:requestrelease2', target_id, playerheading, playerCoords, playerlocation)
			elseif HandjernBlidt == true then
				local target, distance = ESX.Game.GetClosestPlayer()
				playerheading = GetEntityHeading(GetPlayerPed(-1)) 
				playerlocation = GetEntityForwardVector(PlayerPedId())
				playerCoords = GetEntityCoords(GetPlayerPed(-1))
				local target_id = GetPlayerServerId(target)
				HandjernBlidt = false
				TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
				TriggerServerEvent('Emil_policejob:server:itemHandle', 'give', 'handcuff')
				TriggerServerEvent('esx_policejob:requestrelease', target_id, playerheading, playerCoords, playerlocation)
			else
				lib.notify({
					title = 'Politiet',
					description = 'Du har ikke nogle håndjern på dig..',
					type = 'error'
				})
			end
		end
	end, 'handcuff')
end)]]

RegisterNetEvent('crp-police:handcuffPeacefully')
AddEventHandler('crp-police:handcuffPeacefully', function()
	if HandjernBlidt == false then
		local target, distance = ESX.Game.GetClosestPlayer()
		playerheading = GetEntityHeading(GetPlayerPed(-1))
		playerlocation = GetEntityForwardVector(PlayerPedId())
		playerCoords = GetEntityCoords(GetPlayerPed(-1))
		local target_id = GetPlayerServerId(target)
		if distance <= 2.0 then
			HandjernBlidt = true
			TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-on', 1.0)
			TriggerServerEvent('esx_policejob:requestarrest', target_id, playerheading, playerCoords, playerlocation)
		else
			ESX.ShowNotification('Du er ikke tæt nok på nogle..')
		end
	elseif HandjernBlidt == true then
		local target, distance = ESX.Game.GetClosestPlayer()
		playerheading = GetEntityHeading(GetPlayerPed(-1)) 
		playerlocation = GetEntityForwardVector(PlayerPedId())
		playerCoords = GetEntityCoords(GetPlayerPed(-1))
		local target_id = GetPlayerServerId(target)
		HandjernBlidt = false
		TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
		TriggerServerEvent('esx_policejob:requestrelease', target_id, playerheading, playerCoords, playerlocation)
	end
end)

RegisterNetEvent('crp-police:handcuffHard')
AddEventHandler('crp-police:handcuffHard', function()
	if HandjernHaardt == false then
		local target, distance = ESX.Game.GetClosestPlayer()
		playerheading = GetEntityHeading(GetPlayerPed(-1))
		playerlocation = GetEntityForwardVector(PlayerPedId())
		playerCoords = GetEntityCoords(GetPlayerPed(-1))
		local target_id = GetPlayerServerId(target)
		if distance <= 2.0 then
			HandjernHaardt = true
			TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-on', 1.0)
			TriggerServerEvent('esx_policejob:requestarrest2', target_id, playerheading, playerCoords, playerlocation)
		else
			ESX.ShowNotification('Du er ikke tæt nok på nogle..')
		end
	elseif HandjernHaardt == true then
		local target, distance = ESX.Game.GetClosestPlayer()
		playerheading = GetEntityHeading(GetPlayerPed(-1))
		playerlocation = GetEntityForwardVector(PlayerPedId())
		playerCoords = GetEntityCoords(GetPlayerPed(-1))
		local target_id = GetPlayerServerId(target)
		HandjernHaardt = false
		TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'handcuffs-off', 1.0)
		TriggerServerEvent('esx_policejob:requestrelease2', target_id, playerheading, playerCoords, playerlocation)
	end
end)

RegisterNetEvent('esx_policejob:startSkillbar')
AddEventHandler('esx_policejob:startSkillbar', function(target)
	TriggerEvent('opod-skillbar:startSkillbar', function(success)
		if success then
			TriggerEvent('esx_policejob:unrestrain')
			lib.notify({
				description = Lang['escape_from_cuffs_success'],
				type = 'success'
			})
		else
			lib.notify({
				description = Lang['escape_from_cuffs_failed'],
				type = 'error'
			})
		end
	end, math.random(2,4))
end)

RegisterNetEvent('esx_policejob:handcuff')
AddEventHandler('esx_policejob:handcuff', function()
	isHandcuffed = not isHandcuffed
	local playerPed = PlayerPedId()

	if isHandcuffed then
		RequestAnimDict('mp_arresting')
		while not HasAnimDictLoaded('mp_arresting') do
			Citizen.Wait(100)
		end
		TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 3.0, 'handcuff', 0.4)

		AttachEntityToEntity(PlayerPedId(), 11816, 0.0, 0.45, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
		TaskPlayAnim(playerPed, 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0, 0, 0, 0)

		SetEnableHandcuffs(playerPed, true)
		DisablePlayerFiring(playerPed, true)
		SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'), true) -- unarm player
		SetPedCanPlayGestureAnims(playerPed, false)
		--FreezeEntityPosition(playerPed, true)
		DisplayRadar(false)


		ClearPedSecondaryTask(playerPed)
		SetEnableHandcuffs(playerPed, false)
		DisablePlayerFiring(playerPed, false)
		SetPedCanPlayGestureAnims(playerPed, true)
		FreezeEntityPosition(playerPed, false)
		DisplayRadar(true)
	end
end)


RegisterNetEvent('esx_policejob:unrestrain')
AddEventHandler('esx_policejob:unrestrain', function()
	if isHandcuffed then
		TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 5.0, 'uncuff', 0.4)
		local playerPed = PlayerPedId()
		isHandcuffed = false

		ClearPedSecondaryTask(playerPed)
		SetEnableHandcuffs(playerPed, false)
		DisablePlayerFiring(playerPed, false)
		SetPedCanPlayGestureAnims(playerPed, true)
		FreezeEntityPosition(playerPed, false)
		DisplayRadar(true)
	end
end)

RegisterNetEvent('esx_policejob:drag')
AddEventHandler('esx_policejob:drag', function(copId)
	if isHandcuffed then
		dragStatus.isDragged = true
		dragStatus.CopId = copId
	end
end)
RegisterNetEvent('esx_policejob:drag2')
AddEventHandler('esx_policejob:drag2', function(copId)
	if isHandcuffed then
		dragStatus.isDragged = not dragStatus.isDragged
		dragStatus.CopId = copId
	end
end)
RegisterCommand('getonduty', function()
	playerInService = true
end)
local dragging = false
RegisterNetEvent('esx_policejob:dragStatus')
AddEventHandler('esx_policejob:dragStatus', function(target)
	dragStatus.target = target

	dragging = true
	if dragging == true then
		exports['id_helpnotify']:showUI(Lang['escorting_person']:format('<b>[K]</b>', '<b>[G]</b>'))
	end

	local playerPed = GetPlayerPed(-1)
	Citizen.CreateThread(function()
		while dragStatus.target ~= nil do
			Wait(1)
			if IsPedFalling(playerPed) or IsPedDeadOrDying(playerPed) then
				exports['id_helpnotify']:hideUI()
				TriggerServerEvent('esx_policejob:drag2', dragStatus.target)
				TriggerServerEvent('3dme:executeMe', Lang['slipper_personen'])
				dragStatus.target = nil
				dragging = false
			end
			if IsControlJustReleased(0, 311) then
				exports['id_helpnotify']:hideUI()
				TriggerServerEvent('esx_policejob:drag2', dragStatus.target)
				TriggerServerEvent('3dme:executeMe', Lang['slipper_personen'])
				dragStatus.target = nil
				dragging = false
			elseif IsControlJustReleased(0, 47) then
				local coords    = GetEntityCoords(playerPed)
				if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 2.0) then
					exports['id_helpnotify']:hideUI()
					TriggerServerEvent('3dme:executeMe', Lang['saetter_i_koretoj'])
					TriggerServerEvent('esx_policejob:putInVehicle', dragStatus.target)
					TriggerServerEvent('esx_policejob:drag2', dragStatus.target)
					dragStatus.target = nil
					dragging = false
				else
					lib.notify({
						description = Lang['no_vehicles_nearby'],
						type = 'inform'
					})
				end
			end
		end
	end)
end)


RegisterNetEvent("esx_policejob:putInVehicle")
AddEventHandler("esx_policejob:putInVehicle", function()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    if IsAnyVehicleNearPoint(playerCoords, 2.5) then
        local vehicle = GetClosestVehicle(playerCoords, 2.5, 0, 71)

        if vehicle == 0 then
            vehicle = VehicleInFront()
        end
        
        if DoesEntityExist(vehicle) then
            local maxSeats, freeSeat = GetVehicleMaxNumberOfPassengers(vehicle)
            for i = maxSeats - 1, 0, -1 do
                if IsVehicleSeatFree(vehicle, i) then
                    freeSeat = i
                    break
                end
            end
            
            if freeSeat then
                TaskWarpPedIntoVehicle(playerPed, vehicle, freeSeat)
                isDragged = false
            end
        end
    end
end)

RegisterNetEvent("esx_policejob:OutVehicle")
AddEventHandler("esx_policejob:OutVehicle", function()
    local playerPed = PlayerPedId()
        
    if not IsPedSittingInAnyVehicle(playerPed) then
        return
    end
    
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    TaskLeaveVehicle(playerPed, vehicle, 16)
end)

--#########################################
--#		  	        TARGET         		  #
--#########################################

RegisterNetEvent('crp-police:GivBøde')
AddEventHandler('crp-police:GivBøde', function(Spiller)
	OpenFineMenu2(Spiller)
end)


RegisterNetEvent('crp-police:IDKort')
AddEventHandler('crp-police:IDKort', function(Spiller)
	OpenIdentityCardMenu(Spiller)
end)
RegisterNetEvent('crp-police:Eskorter')
AddEventHandler('crp-police:Eskorter', function(Spiller)
	TriggerServerEvent('3dme:executeMe', Lang['eskortere_personen'])
	TriggerServerEvent('esx_policejob:drag', Spiller)
	TriggerServerEvent('esx_policejob:startdragStatus', Spiller)
end)

RegisterNetEvent('crp-police:TjekUbetalteBooder')
AddEventHandler('crp-police:TjekUbetalteBooder', function(Spiller)
	OpenUnpaidBillsMenu(Spiller)
end)

RegisterNetEvent('crp-police:TagGSRTest')
AddEventHandler('crp-police:TagGSRTest', function(Spiller)
	TriggerServerEvent('esx_gsr:Check', Spiller)
end)



RegisterCommand('idkortpoliti', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 3.0 then
			OpenIdentityCardMenu(closestPlayer)
		end
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)

RegisterCommand('håndjernpeacefully', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 3.0 then
			TriggerEvent('crp-police:handcuffPeacefully')
		end
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)

RegisterCommand('håndjernhard', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 3.0 then
			TriggerEvent('crp-police:handcuffHard')
		end
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)

RegisterCommand('dragpoliti', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 3.0 then

			TriggerServerEvent('3dme:executeMe', Lang['eskortere_personen'])
			TriggerServerEvent('esx_policejob:drag', GetPlayerServerId(closestPlayer))
			TriggerServerEvent('esx_policejob:startdragStatus', GetPlayerServerId(closestPlayer))
			
		end
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)

RegisterCommand('pitinvehicle', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 3.0 then
			TriggerServerEvent('3dme:executeMe', Lang['saetter_i_koretoj'])
			TriggerServerEvent('esx_policejob:putInVehicle', GetPlayerServerId(closestPlayer))
		end
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)

RegisterCommand('outthevehicle', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 3.0 then
			TriggerServerEvent('3dme:executeMe', Lang['tager_fra_koretoj'])
			TriggerServerEvent('esx_policejob:OutVehicle', GetPlayerServerId(closestPlayer))
		end
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)

RegisterCommand('givenbøde', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 3.0 then
			OpenFineMenu(closestPlayer)
		end
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)

RegisterCommand('vispolitiskilt', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		TriggerEvent('Emil-politimenu:ShowPoliceBagde')
	else
		lib.notify({
			description = Lang['no_access_to_this'],
			type = 'error'
		})
	end
end)


RegisterKeyMapping("idkortpoliti", Lang['idkortpoliti'], "keyboard", '')
RegisterKeyMapping("håndjernpeacefully", Lang['håndjernpeacefully'], "keyboard", '')
RegisterKeyMapping("håndjernhard", Lang['håndjernhard'], "keyboard", '')
RegisterKeyMapping("dragpoliti", Lang['dragpoliti'], "keyboard", '')
RegisterKeyMapping("pitinvehicle", Lang['putinvehicle'], "keyboard", '')
RegisterKeyMapping("outthevehicle", Lang['outthevehicle'], "keyboard", '')
RegisterKeyMapping("givenbøde", Lang['givenbøde'], "keyboard", '')
RegisterKeyMapping("vispolitiskilt", Lang['vispolitiskilt'], "keyboard", '')




--#########################################
--#		  	        ANIM         		  #
--#########################################


RegisterNetEvent('Emil_police:client:setGPS')
AddEventHandler('Emil_police:client:setGPS', function(coords)
	if ESX.GetPlayerData().job.name == 'police' then
		SetNewWaypoint(coords.x, coords.y)
	end
end)

RegisterNetEvent('esx_policejob:getarrested')
AddEventHandler('esx_policejob:getarrested', function(playerheading, playercoords, playerlocation)
	playerPed = GetPlayerPed(-1)
	if Config.LBPhone then
	exports["lb-phone"]:ToggleDisabled(true)
	end
	SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'), true) -- unarm player
	local x, y, z   = table.unpack(playercoords + playerlocation * 1.0)
	SetEntityCoords(GetPlayerPed(-1), x, y, z)
	SetEntityHeading(GetPlayerPed(-1), playerheading)
	Citizen.Wait(250)
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'b_uncuff', 8.0, -8, 3750 , 2, 0, 0, 0, 0)
	Citizen.Wait(3760)
	cuffed = true
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0.0, false, false, false)
	TriggerEvent('esx_policejob:handcuff')
	if Config.useSkillbarCuffs then
		TriggerEvent('esx_policejob:startSkillbar')
	end
end)

RegisterNetEvent('esx_policejob:doarrested')
AddEventHandler('esx_policejob:doarrested', function()
	Citizen.Wait(250)
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'a_uncuff', 8.0, -8,3750, 2, 0, 0, 0, 0)
	Citizen.Wait(3000)

end) 

RegisterNetEvent('esx_policejob:douncuffing')
AddEventHandler('esx_policejob:douncuffing', function()
	Citizen.Wait(250)
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'a_uncuff', 8.0, -8,-1, 2, 0, 0, 0, 0)
	Citizen.Wait(5500)
	ClearPedTasks(GetPlayerPed(-1))
end)

RegisterNetEvent('esx_policejob:getuncuffed')
AddEventHandler('esx_policejob:getuncuffed', function(playerheading, playercoords, playerlocation)
	local x, y, z   = table.unpack(playercoords + playerlocation * 1.0)
	SetEntityCoords(GetPlayerPed(-1), x, y, z)
	if Config.LBPhone then
	exports["lb-phone"]:ToggleDisabled(false)
	end
	SetEntityHeading(GetPlayerPed(-1), playerheading)
	Citizen.Wait(250)
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'b_uncuff', 8.0, -8,-1, 2, 0, 0, 0, 0)
	Citizen.Wait(5500)
	cuffed = false
	ClearPedTasks(GetPlayerPed(-1))
	TriggerEvent('esx_policejob:unrestrain')
end)

RegisterNetEvent('esx_policejob:getarrested2')
AddEventHandler('esx_policejob:getarrested2', function(playerheading, playercoords, playerlocation)
	playerPed = GetPlayerPed(-1)
	SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'), true) -- unarm player
	local x, y, z   = table.unpack(playercoords + playerlocation * 1.0)
	SetEntityCoords(GetPlayerPed(-1), x, y, z)
	if Config.LBPhone then
	exports["lb-phone"]:ToggleDisabled(true)
	end
	SetEntityHeading(GetPlayerPed(-1), playerheading)
	Citizen.Wait(250)
	loadanimdict('mp_arrest_paired')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arrest_paired', 'crook_p2_back_right', 8.0, -8, 3750 , 2, 0, 0, 0, 0)
	Citizen.Wait(3760)
	cuffed = true
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0.0, false, false, false)
	TriggerEvent('esx_policejob:handcuff')
	if Config.useSkillbarCuffs then
		TriggerEvent('esx_policejob:startSkillbar')
	end
end)

RegisterNetEvent('esx_policejob:doarrested2')
AddEventHandler('esx_policejob:doarrested2', function()
	Citizen.Wait(250)
	loadanimdict('mp_arrest_paired')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arrest_paired', 'cop_p2_back_right', 8.0, -8,3750, 2, 0, 0, 0, 0)
	Citizen.Wait(3000)

end) 

RegisterNetEvent('esx_policejob:douncuffing2')
AddEventHandler('esx_policejob:douncuffing2', function()
	Citizen.Wait(250)
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'a_uncuff', 8.0, -8,-1, 2, 0, 0, 0, 0)
	Citizen.Wait(5500)
	ClearPedTasks(GetPlayerPed(-1))
end)

RegisterNetEvent('esx_policejob:getuncuffed2')
AddEventHandler('esx_policejob:getuncuffed2', function(playerheading, playercoords, playerlocation)
	local x, y, z   = table.unpack(playercoords + playerlocation * 1.0)
	SetEntityCoords(GetPlayerPed(-1), x, y, z)
	SetEntityHeading(GetPlayerPed(-1), playerheading)
	if Config.LBPhone then
	exports["lb-phone"]:ToggleDisabled(false)
	end
	Citizen.Wait(250)
	loadanimdict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'b_uncuff', 8.0, -8,-1, 2, 0, 0, 0, 0)
	Citizen.Wait(5500)
	cuffed = false
	ClearPedTasks(GetPlayerPed(-1))
	TriggerEvent('esx_policejob:unrestrain')
end)
exports.qtarget:Vehicle({
	options = {
		{
			icon = "fa-solid fa-flux-capacitor",
			label = Lang['vehicle_interaction_eyetarget'],
            job = 'police',
            action = function(entity)
                if DoesEntityExist(entity) then
					local vehicleData = ESX.Game.GetVehicleProperties(entity)
                    OpenVehicleInfosMenu(vehicleData) 
                end
			end,
		},
	},
	distance = 2
})


local speedZoneActive = false
local blip
local speedZone
local speedzones = {}
local GlobalData = ""
TrafficMenu = function()
    local elements = {}
	local radiusnum = { }
	local speednum = { }
	local speed = 0
	local radius = 0

    table.insert(elements, {
        label      = Lang['trafikzone_radius'],
        option     = "set_zone_radius",

        -- menu properties
        value      = 25,
        type       = 'slider',
        min        = 1,
        max        = 100
    })

    table.insert(elements, {
        label      = Lang['trafikzone_maxhastighed'],
        option     = "set_zone_speed",

        -- menu properties
        value      = 0,
        type       = 'slider',
        min        = 0,
        max        = 80
    })

    table.insert(elements, {
        label      = Lang['trafikzone_opret'],
        option     = "create_zone",
    })

    table.insert(elements, {
        label      = Lang['trafikzone_slet'],
        option     = "delete_zone",
    })

    ESX.UI.Menu.CloseAll()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'trafficzone', {
		title    = Lang['trafikzone_title'],
		align    = 'bottom-right',
		elements = elements
    }, function(data, menu)
        local playerPed = PlayerPedId()

        if data.current.option == 'create_zone' then
			if zoneActive then
				lib.notify({
					description = Lang['trafikzone_alert1'],
					type = 'error'
				})
                return
            end

            local zoneRadius, zoneSpeed = 0, 0
            for k,v in pairs(data.elements) do
                if v.option == "set_zone_radius" then
                    zoneRadius = v.value
                end

                if v.option == "set_zone_speed" then
                    zoneSpeed = v.value
                end
            end
            
            
			speedZoneActive = true
			local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1)))
			radius = zoneRadius + 0.0
			speed = zoneSpeed + 0.0
			
			local streetName, crossing = GetStreetNameAtCoord(x, y, z)
			streetName = GetStreetNameFromHashKey(streetName)
	  
			if Config.UseProgbarAtTrafikzone then
				exports['progressBars']:startUI(600, Lang['trafikzone_progbar2'])
				Citizen.Wait(650)
				exports['progressBars']:startUI(600, Lang['trafikzone_progbar3'])
				Citizen.Wait(650)
				exports['progressBars']:startUI(600, Lang['trafikzone_progbar4'])
				Citizen.Wait(650)
			end
			local msg = Lang['trafikzone_message1']:format(streetName, speed)
			if speed == 0 then
                msg = Lang['trafikzone_message2']:format(streetName)
            end
            TriggerServerEvent('Emil_trafikzone:server:ZoneActivated', msg, speed, radius, x, y, z)

            zoneActive = true
			lib.notify({
				description = Lang['trafikzone_alert2'],
				type = 'success'
			})
        end
            
        if data.current.option == 'delete_zone' then
			if Config.UseProgbarAtTrafikzone then
				exports['progressBars']:startUI(600, Lang['trafikzone_progbar1'])
				Citizen.Wait(650)
			end
			TriggerServerEvent('Emil_trafikzone:server:Disable')

			zoneActive = false
			lib.notify({
				description = Lang['trafikzone_alert3'],
				type = 'success'
			})
        end
	end, function(data, menu)
		menu.close()
	end)
end

RegisterNetEvent('Emil_trafikzone:client:Zone')
AddEventHandler('Emil_trafikzone:client:Zone', function(speed, radius, x, y, z)

  blip = AddBlipForRadius(x, y, z, radius)
  SetBlipSprite(blip,9)
  SetBlipColour(blip,70)
  SetBlipAlpha(blip,75)

  speedZone = AddSpeedZoneForCoord(x, y, z, radius, speed, false)

  table.insert(speedzones, {x, y, z, speedZone, blip})

end)

RegisterNetEvent('Emil_trafikzone:client:RemoveBlip')
AddEventHandler('Emil_trafikzone:client:RemoveBlip', function()

	if speedzones == nil then
		return
	end
	
    local playerPed = GetPlayerPed(-1)
    local x, y, z = table.unpack(GetEntityCoords(playerPed, true))
    local closestSpeedZone = 0
    local closestDistance = 1000
    for i = 1, #speedzones, 1 do
        local distance = Vdist(speedzones[i][1], speedzones[i][2], speedzones[i][3], x, y, z)
        if distance < closestDistance then
            closestDistance = distance
            closestSpeedZone = i
        end
    end
    RemoveSpeedZone(speedzones[closestSpeedZone][4])
    RemoveBlip(speedzones[closestSpeedZone][5])
    table.remove(speedzones, closestSpeedZone)

end)







-- Objectmenu
RegisterNetEvent('Emil-politimenu:objectspawner')
AddEventHandler('Emil-politimenu:objectspawner', function()
	ESX.UI.Menu.Open(
		"default",
		GetCurrentResourceName(),
		"citizen_interaction",
		{
			title = Lang['object_spawner'],
			align = "top-left",
			elements = {
				{label = Lang['kegle'], value = "prop_roadcone01a"},
				{label = Lang['ulykke_skilt'], value = "prop_barrier_work05"},
				{label = Lang['sommatter'], item = "p_ld_stinger_s", value = 1, type = 'slider', min = 1, max = 5},
				{label = Lang['kasse'], value = "prop_boxpile_07d"},
				{label = Lang['dirigerings_skilt'], value = 'prop_mp_arrow_barrier_01'},
				{label = Lang['hardt_skilt'], value = 'prop_mp_barrier_02b'},
				{label = Lang['blod_barriere'], value = 'prop_barrier_work06a'},
				{label = Lang['blod_barriere'], value = 'prop_barrier_work06a'},
				{label = Lang['krim_gazebo'], value = 'prop_gazebo_02'},
				{label = Lang['krim_arbejdeslys'], value = 'prop_worklight_03b'},
				{label = 'Advarselstrekant', value = 'prop_paint_brush01'},
			}
		},
		function(data2, menu2)
			local model 	= data2.current.value
			local playerPed = PlayerPedId()
			local coords    = GetEntityCoords(playerPed)
			local forward   = GetEntityForwardVector(playerPed)
			local x, y, z   = table.unpack(coords + forward * 1.0)
			local amount 	= data2.current.value

			if data2.current.value ~= "delete_props_zone" then
			
			if model == "prop_roadcone02a" then
				z = z - 2.0
			end
			
			if data2.current.item == 'p_ld_stinger_s' then
				FreezeEntityPosition(GetPlayerPed(-1),true)
				local spawnCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 2.0, 0.0)
				exports['progressBars']:startUI(amount * 750, 'Placere Spike Strips')
				RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@")
				while not HasAnimDictLoaded("anim@amb@clubhouse@tutorial@bkr_tut_ig3@") do
					Citizen.Wait(100)
				end

				TaskPlayAnim(playerPed, "anim@amb@clubhouse@tutorial@bkr_tut_ig3@", "machinic_loop_mechandplayer", 2.0, 2.0, -1, 1, 0, false, false, false)
				for a = 1, amount do
					Wait(750)
					local spike = CreateObject(GetHashKey(data2.current.item), spawnCoords.x, spawnCoords.y, spawnCoords.z, 1, 1, 1)
					SetEntityHeading(spike, GetEntityHeading(playerPed))
					PlaceObjectOnGroundProperly(spike)
					spawnCoords = GetOffsetFromEntityInWorldCoords(spike, 0.0, 4.0, 0.0)
				end
				FreezeEntityPosition(GetPlayerPed(-1),false)
				ClearPedTasks(GetPlayerPed(-1))
				return
			end

			local spawnCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 2.0, 0.0)
			local obj = CreateObject(GetHashKey(model), spawnCoords.x, spawnCoords.y, spawnCoords.z, 1, 1, 1)
			SetEntityHeading(obj, GetEntityHeading(playerPed))
			PlaceObjectOnGroundProperly(obj)
			spawnCoords = GetOffsetFromEntityInWorldCoords(obj, 0.0, 4.0, 0.0)

			else
				local trackedEntities = {
					"prop_roadcone01a",
					"prop_roadcone02a",
					"prop_barrier_work05",
					"p_ld_stinger_s",
					"prop_boxpile_07d",
					"hei_prop_cash_crate_half_full",
					"prop_mp_arrow_barrier_01",
					"prop_mp_barrier_02b",
					"prop_barrier_work06a",
					"prop_gazebo_02",
					"prop_worklight_03b"
				}

				local objects        = ESX.Game.GetObjects()
				local objectsInArea  = {}
				
				local playerPed = PlayerPedId()
				local coords = GetEntityCoords(playerPed)

				for i=1, #objects, 1 do
					local objectsCoords = GetEntityCoords(objects[i])
					local distance      = GetDistanceBetweenCoords(objectsCoords, coords.x, coords.y, coords.z, true)

					if distance <= 20 then
						for j=1, #trackedEntities, 1 do
							local attempt = 0
							if GetEntityModel(objects[i]) == trackedEntities[j] then

								while not NetworkHasControlOfEntity(objects[i]) and attempt < 100 and DoesEntityExist(objects[i]) do
									Wait(100)
									NetworkRequestControlOfEntity(objects[i])
									attempt = attempt + 1
								end
								if DoesEntityExist(objects[i]) and NetworkHasControlOfEntity(objects[i]) then
									ESX.Game.DeleteObject(objects[i])
								end
							end
						end
					end
				end
			end
		end,
		function(data2, menu2)
			menu2.close()
		end)
end)


-- Borger Interaktion
RegisterNetEvent('Emil-politimenu:civilinteraktion')
AddEventHandler('Emil-politimenu:civilinteraktion', function()
	local elements = {
		{label = Lang['idcard_menu'], value = 'identity_card'},
		{label = Lang['toggle_handjern_blidt_menu'], value = 'handjernb'},
		{label = Lang['toggle_handjern_hardt_menu'], value = 'handjernh'},
		{label = Lang['eskorter_menu'], value = 'drag'},
		{label = Lang['put_in_vehicle_menu'], value = 'put_in_vehicle' },
		{label = Lang['out_of_vehicle_menu'], value = 'out_the_vehicle' },
		{label = Lang['give_fine_menu'], value = 'fine' },
		{label = Lang['administrerlicense_menu'], value = 'license' },
	}

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'citizen_interaction', {
		title    = Lang['citizen_interaction'],
		align    = 'top-left',
		elements = elements
	}, function(data2, menu2)
        local closestPlayer, distance = ESX.Game.GetClosestPlayer()
        if closestPlayer ~= -1 and distance ~= -1 and distance <= 2.0 then
			local action = data2.current.value

			if action == 'identity_card' then
				OpenIdentityCardMenu(closestPlayer)
			elseif action == 'handjernb' then
				TriggerEvent('crp-police:handcuffPeacefully')
			elseif action == 'visiter' then
				TriggerServerEvent('3dme:executeMe', Lang['visitere_personen'])
                exports.ox_inventory:openInventory('player', GetPlayerServerId(closestPlayer))
			elseif action == 'handjernh' then
				TriggerEvent('crp-police:handcuffHard')
			elseif action == 'drag' then
				TriggerServerEvent('3dme:executeMe', Lang['eskortere_personen'])
				TriggerServerEvent('esx_policejob:drag', GetPlayerServerId(closestPlayer))
				TriggerServerEvent('esx_policejob:startdragStatus', GetPlayerServerId(closestPlayer))
			elseif action == 'put_in_vehicle' then
				TriggerServerEvent('3dme:executeMe', Lang['saetter_i_koretoj'])
				TriggerServerEvent('esx_policejob:putInVehicle', GetPlayerServerId(closestPlayer))
			elseif action == 'out_the_vehicle' then
				TriggerServerEvent('3dme:executeMe', Lang['tager_fra_koretoj'])
				TriggerServerEvent('esx_policejob:OutVehicle', GetPlayerServerId(closestPlayer))
			elseif action == 'fine' then
                OpenFineMenu(closestPlayer)
			end
        elseif distance < 20 or distance > 2.0 then
			lib.notify({
				description = Lang['too_long_away'],
				type = 'error'
			})
        else
			lib.notify({
				description = Lang['too_long_away2'],
				type = 'error'
			})
		end
	end, function(data2, menu2)
		menu2.close()
	end)
end)

exports.qtarget:Player({
	options = {
		{
			icon = "fas fa-handcuffs",
			label = "Sæt i håndjern (Blidt)",
            job = 'police',
            action = function(entity)
				TriggerEvent('crp-police:handcuffPeacefully')
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		}, {
			icon = "fas fa-handcuffs",
			label = "Sæt i håndjern (Hårdt)",
            job = 'police',
            action = function(entity)
				TriggerEvent('crp-police:handcuffHard')
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		}, {
			icon = "fas fa-id-card",
			label = "ID Kort",
            job = 'police',
            action = function(entity)
                OpenIdentityCardMenu(NetworkGetPlayerIndexFromPed(entity))
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		}, {
			icon = "fa-solid fa-ticket",
			label = "Giv en bøde",
            job = 'police',
            action = function(entity)
                OpenFineMenu(NetworkGetPlayerIndexFromPed(entity))
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		}, {
			icon = "fa-solid fa-person",
			label = "Eskorter",
            job = 'police',
            action = function(entity)
                local closestPlayer = NetworkGetPlayerIndexFromPed(entity)
				TriggerServerEvent('3dme:executeMe', Lang['eskortere_personen'])
				TriggerServerEvent('esx_policejob:drag', GetPlayerServerId(closestPlayer))
				TriggerServerEvent('esx_policejob:startdragStatus', GetPlayerServerId(closestPlayer))
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		}, {
			icon = "fa-solid fa-person",
			label = "Visiter",
            job = 'police',
            action = function(entity)
				TriggerServerEvent('esx_policejob:send', 'visiter', GetPlayerServerId(NetworkGetPlayerIndexFromPed(entity)))
				exports.ox_inventory:openInventory('player', GetPlayerServerId(NetworkGetPlayerIndexFromPed(entity)))
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		}, {
			icon = "fas fa-clipboard-list",
			label = "Tjek Ubetalte bøder",
            job = 'police',
            action = function(entity)
                OpenUnpaidBillsMenu(GetPlayerServerId(NetworkGetPlayerIndexFromPed(entity)))
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		}, {
			icon = "fa-solid fa-gun",
			label = "Tag GSR Test",
            job = 'police',
            action = function(entity)
                TriggerServerEvent("esx_gsr:Check", GetPlayerServerId(NetworkGetPlayerIndexFromPed(entity)))
			end,
            canInteract = function()
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					return true
				else
					return false
				end
            end,
		},
	},
	distance = 2
})
-- Politiskilt
RegisterNetEvent('Emil-politimenu:ShowPoliceBagde')
AddEventHandler('Emil-politimenu:ShowPoliceBagde', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local badge={"paper_1_rcm_alt1-9","player_one_dual-9","prop_fib_badge"}
		ClearPedTasks(PlayerPedId())
		RequestAnimDict(badge[1])
		while not HasAnimDictLoaded(badge[1])do
		  Wait(100)
		end
		RequestModel(badge[3])
		while not HasModelLoaded(badge[3])do
		Wait(100)
		end
		local x,y,z=table.unpack(GetEntityCoords(PlayerPedId(),true))
		skilt=CreateObject(GetHashKey(badge[3]),x,y,z-5,true,true)
		AttachEntityToEntity(skilt,PlayerPedId(),GetPedBoneIndex(PlayerPedId(),64017),0.025,-0.025,-0.01,85.0,0.0,80.0,false,false,false,false,false,true)
		TaskPlayAnim(PlayerPedId(),badge[1],badge[2],8.0,8.0,-1,49,1.0,false,false,false)
		Wait(2500)
		DeleteEntity(skilt)
		ClearPedTasks(PlayerPedId())
	end
end)

-- Køretøjsinteraktion
RegisterNetEvent('Emil-politimenu:koretojsinteraktion')
AddEventHandler('Emil-politimenu:koretojsinteraktion', function()
	local elements  = {}
	local playerPed = PlayerPedId()
	local vehicle = ESX.Game.GetVehicleInDirection()
	if DoesEntityExist(vehicle) then
		table.insert(elements, {label = Lang['vehicle_info_title'], value = 'vehicle_infos'})
		table.insert(elements, {label = Lang['pick_lock'], value = 'hijack_vehicle'})
		table.insert(elements, {label = Lang['impound_vehicle'], value = 'impound'})
	end
	table.insert(elements, {label = Lang['search_database'], value = 'search_database'})
	table.insert(elements, {label = 'Permanent beslaglæggelse', value = 'beslaglaeg'})

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_interaction', {
		title    = Lang['vehicle_info_title'],
		align    = 'top-left',
		elements = elements
	}, function(data2, menu2)
		local coords  = GetEntityCoords(playerPed)
		local vehicle2 = ESX.Game.GetVehicleInDirection()
		action  = data2.current.value 

		if action == 'search_database' then
			LookupVehicle()
		elseif action == 'beslaglaeg' then
			menu2.close()
			ExecuteCommand('+impound_menu')
			Citizen.Wait(200)
			ESX.UI.Menu.CloseAll()
		elseif DoesEntityExist(vehicle2) then
			if action == 'vehicle_infos' then
				local vehicleData = ESX.Game.GetVehicleProperties(vehicle2)
				OpenVehicleInfosMenu(vehicleData)
			elseif action == 'hijack_vehicle' then
				if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 3.0) then
					TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_WELDING', 0, true)
					Citizen.Wait(20000)
					ClearPedTasksImmediately(playerPed)

					exports['t1ger_keys']:SetVehicleLocked(vehicle2, 0)
					SetVehicleDoorsLockedForAllPlayers(vehicle2, false)
					lib.notify({
						description = Lang['vehicle_unlocked'],
						type = 'success'
					})
				end
			elseif action == 'impound' then
				if currentTask.busy then
					return
				end

				exports['id_helpnotify']:showUI(Lang['impound_prompt']:format('<b>[E]</b>'))
				TaskStartScenarioInPlace(playerPed, 'CODE_HUMAN_MEDIC_TEND_TO_DEAD', 0, true)

				currentTask.busy = true
				currentTask.task = ESX.SetTimeout(10000, function()
					ClearPedTasks(playerPed)
					ESX.Game.DeleteVehicle(vehicle)
					exports['id_helpnotify']:hideUI()
					lib.notify({
						description = Lang['vehicle_impounded'],
						type = 'success'
					})
					currentTask.busy = false
					Citizen.Wait(100)
				end)

	
			end
		else
			lib.notify({
				description = Lang['no_vehicles_nearby'],
				type = 'error'
			})
		end

	end, function(data2, menu2)
		menu2.close()
	end)
end)

function LookupVehicle()
	ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'lookup_vehicle',
	{
		title = 'Køretøjsoplysninger - Søg på nummerplade',
	}, function(data, menu)
		local length = string.len(data.value)
		if data.value == nil or length < 2 or length > 13 then
			lib.notify({
				description = 'Køretøjsoplysninger - Ugyldigt nummerplade',
				type = 'error'
			})
		else
			ESX.TriggerServerCallback('esx_policejob:getVehicleFromPlate', function(owner, found)
				if found then
					lib.notify({
						description = 'Køretøjsoplysninger - Køretøjet er indregistreret, ejer: '..owner,
						type = 'inform'
					})
				else
					lib.notify({
						description = 'Køretøjsoplysninger - Ikke registreret',
						type = 'error'
					})
				end
			end, data.value)
			menu.close()
		end
	end, function(data, menu)
		menu.close()
	end)
end

-- Panikknap
RegisterNetEvent('Emil-politimenu:panikknap')
AddEventHandler('Emil-politimenu:panikknap', function()
	panikknap()
end)
function CoordToString(coord)
    zones = { ['AIRP'] = "Los Santos International Airport", ['ALAMO'] = "Alamo Sea", ['ALTA'] = "Alta", ['ARMYB'] = "Fort Zancudo", ['BANHAMC'] = "Banham Canyon Dr", ['BANNING'] = "Banning", ['BEACH'] = "Vespucci Beach", ['BHAMCA'] = "Banham Canyon", ['BRADP'] = "Braddock Pass", ['BRADT'] = "Braddock Tunnel", ['BURTON'] = "Burton", ['CALAFB'] = "Calafia Bridge", ['CANNY'] = "Raton Canyon", ['CCREAK'] = "Cassidy Creek", ['CHAMH'] = "Chamberlain Hills", ['CHIL'] = "Vinewood Hills", ['CHU'] = "Chumash", ['CMSW'] = "Chiliad Mountain State Wilderness", ['CYPRE'] = "Cypress Flats", ['DAVIS'] = "Davis", ['DELBE'] = "Del Perro Beach", ['DELPE'] = "Del Perro", ['DELSOL'] = "La Puerta", ['DESRT'] = "Grand Senora Desert", ['DOWNT'] = "Downtown", ['DTVINE'] = "Downtown Vinewood", ['EAST_V'] = "East Vinewood", ['EBURO'] = "El Burro Heights", ['ELGORL'] = "El Gordo Lighthouse", ['ELYSIAN'] = "Elysian Island", ['GALFISH'] = "Galilee", ['GOLF'] = "GWC and Golfing Society", ['GRAPES'] = "Grapeseed", ['GREATC'] = "Great Chaparral", ['HARMO'] = "Harmony", ['HAWICK'] = "Hawick", ['HORS'] = "Vinewood Racetrack", ['HUMLAB'] = "Humane Labs and Research", ['JAIL'] = "Bolingbroke Penitentiary", ['KOREAT'] = "Little Seoul", ['LACT'] = "Land Act Reservoir", ['LAGO'] = "Lago Zancudo", ['LDAM'] = "Land Act Dam", ['LEGSQU'] = "Legion Square", ['LMESA'] = "La Mesa", ['LOSPUER'] = "La Puerta", ['MIRR'] = "Mirror Park", ['MORN'] = "Morningwood", ['MOVIE'] = "Richards Majestic", ['MTCHIL'] = "Mount Chiliad", ['MTGORDO'] = "Mount Gordo", ['MTJOSE'] = "Mount Josiah", ['MURRI'] = "Murrieta Heights", ['NCHU'] = "North Chumash", ['NOOSE'] = "N.O.O.S.E", ['OCEANA'] = "Pacific Ocean", ['PALCOV'] = "Paleto Cove", ['PALETO'] = "Paleto Bay", ['PALFOR'] = "Paleto Forest", ['PALHIGH'] = "Palomino Highlands", ['PALMPOW'] = "Palmer-Taylor Power Station", ['PBLUFF'] = "Pacific Bluffs", ['PBOX'] = "Pillbox Hill", ['PROCOB'] = "Procopio Beach", ['RANCHO'] = "Rancho", ['RGLEN'] = "Richman Glen", ['RICHM'] = "Richman", ['ROCKF'] = "Rockford Hills", ['RTRAK'] = "Redwood Lights Track", ['SANAND'] = "San Andreas", ['SANCHIA'] = "San Chianski Mountain Range", ['SANDY'] = "Sandy Shores", ['SKID'] = "Mission Row", ['SLAB'] = "Stab City", ['STAD'] = "Maze Bank Arena", ['STRAW'] = "Strawberry", ['TATAMO'] = "Tataviam Mountains", ['TERMINA'] = "Terminal", ['TEXTI'] = "Textile City", ['TONGVAH'] = "Tongva Hills", ['TONGVAV'] = "Tongva Valley", ['VCANA'] = "Vespucci Canals", ['VESP'] = "Vespucci", ['VINE'] = "Vinewood", ['WINDF'] = "Ron Alternates Wind Farm", ['WVINE'] = "West Vinewood", ['ZANCUDO'] = "Zancudo River", ['ZP_ORT'] = "Port of South Los Santos", ['ZQ_UAR'] = "Davis Quartz" }
    local zoneNameFull = zones[GetNameOfZone(coord.x, coord.y, coord.z)]
    local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(coord.x, coord.y, coord.z))
    local adres = zoneNameFull ..' ' .. streetName

    return adres

end
-- Tøjmenu
RegisterNetEvent('Emil-politimenu:clothesmenu')
AddEventHandler('Emil-politimenu:clothesmenu', function()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'clothes_menu', {
		title    = Lang['clothingmenu_title'],
		align    = 'top-left',
		elements = {
			{label = Lang['toggle_reflekt'], value = 'toggle_reflekt'},
			{label = Lang['toggle_hat'], value = 'toggle_hat'},
			{label = Lang['toggle_hjelm'], value = 'toggle_hjelm'},
            {label = Lang['toggle_civilskilt'], value = 'toggle_civil'},
			{label = Lang['toggle_gopro'], value = 'toggle_gopro'},
			{label = Lang['toggle_vest'], value = 'toggle_vest'},
		}
	}, function(data2, menu2)
		action  = data2.current.value
	if action == 'toggle_vest' then
		if vestEquipped == false then
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Vest', 'på'),
				type = 'success'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 9, 3, 0, 0)
			vestEquipped = true
		else
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Vest', 'af'),
				type = 'error'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 9, 0, 0, 0)
			vestEquipped = false 
		end
	elseif action == 'toggle_hjelm' then
		if hjelmEquipped == false then
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Hjelm', 'på'),
				type = 'success'
			})
            SetPedPropIndex(GetPlayerPed(-1), 0, 117, 0, true)
			hjelmEquipped = true
		else
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Hjelm', 'af'),
				type = 'error'
			})
            SetPedPropIndex(GetPlayerPed(-1), 0, 11, 0, true)
			hjelmEquipped = false
		end
	elseif action == 'toggle_hat' then
		if hatEquipped == false then
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Hat', 'på'),
				type = 'success'
			})
            SetPedPropIndex(GetPlayerPed(-1), 0, 108, 0, true)
			hatEquipped = true
		else
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Hat', 'af'),
				type = 'error'
			})
            SetPedPropIndex(GetPlayerPed(-1), 0, 11, 0, true)
			hatEquipped = false
		end
	elseif action == 'toggle_gopro' then
		if goproEquipped == false then
			lib.notify({
				description = Lang['clothingmenu_notify']:format('GoPro', 'på'),
				type = 'success'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 5, 66, 0, 0)
			goproEquipped = true
		else
			lib.notify({
				description = Lang['clothingmenu_notify']:format('GoPro', 'af'),
				type = 'error'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 5, 0, 0, 0)
			goproEquipped = false
		end
	elseif action == 'toggle_civil' then
		if civilEquipped == false then
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Civil Skilt', 'på'),
				type = 'success'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 7, 128, 0, 0)
			civilEquipped = true
		else
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Civil Skilt', 'af'),
				type = 'error'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 7, 0, 0, 0)
			civilEquipped = false
		end
	elseif action == 'toggle_reflekt' then
		if reflektEquipped == false then
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Reflektvest', 'på'),
				type = 'success'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 8, 59, 0, 0)
			reflektEquipped = true
		else
			lib.notify({
				description = Lang['clothingmenu_notify']:format('Reflektvest', 'af'),
				type = 'error'
			})
			SetPedComponentVariation(GetPlayerPed(-1), 8, 15, 0, 0)
			reflektEquipped = false
		end
	end
    end, function(data2, menu2)
		menu2.close()
	end)
end)