local NumberCharset = {}
local Charset = {}

for i = 48,  57 do table.insert(NumberCharset, string.char(i)) end

for i = 65,  90 do table.insert(Charset, string.char(i)) end
for i = 97, 122 do table.insert(Charset, string.char(i)) end

function OpenVehicleSpawnerMenu(type, station, part, partNum)
	ESX.UI.Menu.CloseAll()
	local playerPed = PlayerPedId()
	FreezeEntityPosition(playerPed, true)
	local foundSpawn, spawnPoint = GetAvailableVehicleSpawnPoint(station, part, partNum)
	if type == 'car' then
		lib.registerContext({
			id = 'some_menu',
			title = 'Politi Garage',
			onExit = function ()
			  FreezeEntityPosition(playerPed, false)
			end,
			options = {
				{
				  title = 'Vælg venligst en kategori.',
				  icon = 'fa-solid fa-arrow-down'
				},
				{
				  title = 'Markerede Køretøjer',
				  description = 'Vælg en af de markerede køretøjer.',
				  icon = 'fa-solid fa-car',
				  onSelect = function()
					lib.registerContext({
						id = 'some_menu2',
						title = 'Markerede Køretøjer',
						onExit = function ()
						  FreezeEntityPosition(playerPed, false)
						end,
						options = {
							{
							  title = 'Vælg en af de nedenstående køretøjer.',
							  icon = 'fa-solid fa-arrow-down'
							},
							{
							  title = 'Argento - Markeret',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polargento', spawnPoint)
							  end
							},
							{
							  title = 'Rhinehart - Landbetjent',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polrhinehart', spawnPoint)
							  end
							  },
						    {
							  title = 'Sherif - Landbetjent',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('ll1rb', spawnPoint)
							  end
							},
							{
							  title = 'Buffaloh - Markeret',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polcbuffaloh', spawnPoint)
							  end
							},
							{
							  title = 'Jugular - Indsatsleder',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('poljugular', spawnPoint)
							  end
							},
							{
							  title = 'Raiden - Markeret',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polraiden', spawnPoint)
							  end
							},
							{
							  title = 'Jugular - Markeret',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('jugular2', spawnPoint)
							  end
							},
							{
							  title = 'Streiter - Markeret',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polstreiter', spawnPoint)
							  end
							},
							{
							  title = 'XLS Romio/Aks - Markeret',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polxls', spawnPoint)
							  end
							},
						}
					})
					lib.showContext('some_menu2')
				  end
				},
				{
				  title = 'Civile Køretøjer',
				  description = 'Vælg en af de civile køretøjer.',
				  icon = 'fa-solid fa-car',
				  onSelect = function()
					lib.registerContext({
						id = 'some_menu3',
						title = 'Civile Køretøjer',
						onExit = function ()
						  FreezeEntityPosition(playerPed, false)
						end,
						options = {
							{
							  title = 'Vælg en af de nedenstående køretøjer.',
							  icon = 'fa-solid fa-arrow-down'
							},
							{
							  title = 'Tailgater2 - Civil',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polctailgater2', spawnPoint)
							  end
							},
							{
							  title = 'Schafter - Civil',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polcschafter3', spawnPoint)
							  end
							},
							{
							  title = 'Komoda - Civil',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polckomoda', spawnPoint)
							  end
							},
						}
					})
					lib.showContext('some_menu3')
				  end
				},
				{
				  title = 'Motorcykler',
				  description = 'Vælg en af motorcyklerne.',
				  icon = 'fa-solid fa-car',
				  onSelect = function()
					lib.registerContext({
						id = 'some_menu4',
						title = 'Motorcykler',
						onExit = function ()
						  FreezeEntityPosition(playerPed, false)
						end,
						options = {
							{
							  title = 'Vælg en af de nedenstående motorcykler.',
							  icon = 'fa-solid fa-arrow-down'
							},
							{
							  title = 'BF400 - MC',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polbf400', spawnPoint)
							  end
							},
							{
							  title = 'Shinobi - MC',
							  icon = 'fa-solid fa-car',
							  onSelect = function()
								SpawnVehicle('polshinobi', spawnPoint)
							  end
							},
						}
					})
					lib.showContext('some_menu4')
				  end
				},
			}
		})
		lib.showContext('some_menu')
	elseif type == 'helicopter' then
		lib.registerContext({
			id = 'some_menu5',
			title = 'Helikopter',
			onExit = function ()
			  FreezeEntityPosition(playerPed, false)
			end,
			options = {
				{
				  title = 'Vælg en af de nedenstående helikoptere.',
				  icon = 'fa-solid fa-arrow-down'
				},
				{
				  title = 'Politi - Helikopter',
				  icon = 'fa-solid fa-car',
				  onSelect = function()
					SpawnVehicle('polmav', spawnPoint)
				  end
				},
			}
		})
		lib.showContext('some_menu5')
	elseif type == 'BoatGarage' then
		lib.registerContext({
			id = 'some_menu6',
			title = 'Både',
			onExit = function ()
			  FreezeEntityPosition(playerPed, false)
			end,
			options = {
				{
				  title = 'Vælg en af de nedenstående Både.',
				  icon = 'fa-solid fa-arrow-down'
				},
				{
				  title = 'Politi - Båd',
				  icon = 'fa-solid fa-car',
				  onSelect = function()
					SpawnVehicle('POLDINGHY', spawnPoint)
				  end
				},
			}
		})
		lib.showContext('some_menu6')
	end
end

SpawnVehicle = function(model, spawnPoint)
	local playerPed = PlayerPedId()
	FreezeEntityPosition(playerPed, false)

	ESX.Game.SpawnVehicle(model, spawnPoint.coords, spawnPoint.heading, function(vehicle)

		if model == "mercedesc250" then
			SetEntityRotation(vehicle, 1.0, 1.0, 1.0, 1.0, true)
		end

		local plate     = GetVehicleNumberPlateText(vehicle)
		local veh_name = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)))
		exports['t1ger_keys']:SetVehicleLocked(vehicle, 1)
		exports['t1ger_keys']:GiveTemporaryKeys(plate, veh_name, 'Politibil')
		Entity(vehicle).state.fuel = 100

		
		lib.notify({
			title = 'Garage',
			description = Lang['garage_took_vehicle'],
			type = 'success'
		})
	end)
end

function GetAvailableVehicleSpawnPoint(station, part, partNum)
	local spawnPoints = Config.PolitiStationer[station][part][partNum].SpawnPoints
	local found, foundSpawnPoint = false, nil

	for i=1, #spawnPoints, 1 do
		if ESX.Game.IsSpawnPointClear(spawnPoints[i].coords, spawnPoints[i].radius) then
			found, foundSpawnPoint = true, spawnPoints[i]
			break
		end
	end

	if found then
		return true, foundSpawnPoint
	else
		lib.notify({
			title = 'Garage',
			description = Lang['garage_vehicle_in_way'],
			type = 'error'
		})
		return false
	end
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if isInShopMenu then
			DisableControlAction(0, 75, true)  -- Disable exit vehicle
			DisableControlAction(27, 75, true) -- Disable exit vehicle
		else
			Citizen.Wait(500)
		end
	end
end)

OpenResellerMenu = function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
		local playerPed = PlayerPedId()

		local playersNearby = ESX.Game.GetPlayersInArea(GetEntityCoords(playerPed), 3.0)
		local elements = {}

		if #playersNearby > 0 then
			for i = 1, #playersNearby, 1 do
				if playersNearby[i] ~= PlayerId() then
					table.insert(elements, {label = GetPlayerName(playersNearby[i]), value = playersNearby[i]})
				end
			end
		else
			TriggerEvent('ox_lib:notify', {type = 'error', description = 'Ingen spiller i nærheden'})
		end
		local input = lib.inputDialog('Udlever ét Civil Køretøj', {
			{type = 'select', label = 'Modtager', options = elements},
			{type = 'select', label = 'Vælg Civil Køretøjet', options = {
				{
					label = 'Tailgater - Civil', 
					value = 'tailgatercivil'
				},
				{
					label = 'Jackal - Civil', 
					value = 'jackalcivil'
				},
				{
					label = 'Tailgater S - Civil', 
					value = 'tailgater2-unmarked'
				},
				{
					label = 'Drafter - Civil', 
					value = 'draftercivil'
				},
				{
					label = 'Argento - Civil', 
					value = 'argento_unmarked'
				},
				{
					label = 'Cinquemila - Civil', 
					value = 'cinquemila_unmarked'
				},
				{
					label = 'Revolter - Civil', 
					value = 'revolter-unmarked'
				},
				{
					label = 'Komoda - Civil', 
					value = 'komodacivil'
				},
				{
					label = 'Rebla GTS - Civil', 
					value = 'reblacivil'
				},
				{
					label = 'Schafter - Civil', 
					value = 'schafter3civil'
				},
				{
					label = 'Buffaloh - Civil', 
					value = 'polcbuffaloh'
				},
				{
					label = 'Imperial - Civil', 
					value = 'polcimperial'
				},
				{
					label = 'XLS - Romeo', 
					value = 'xlscivil'
				},
				{
					label = 'VSTR - Krim', 
					value = 'vstrcivil'
				},
				{
					label = 'Oracle - Krim', 
					value = 'oraclecivil'
				},
				{
					label = 'Dubsta - Krim', 
					value = 'dubsta2civil'
				},
				{
					label = 'Baller2 - Krim', 
					value = 'ballercivil'
				}
			}},
		})
		local plate = GeneratePlate()
		TriggerServerEvent('Emil_dealership:giveVehicle', GetPlayerServerId(input[1]), input[2], plate)
	end
end

function GeneratePlate()
	local generatedPlate
	local doBreak = false

	while true do
		Citizen.Wait(2)
		math.randomseed(GetGameTimer())
		generatedPlate = string.upper(GetRandomLetter(2) .. GetRandomNumber(5))

		ESX.TriggerServerCallback('esx_vehicleshop:isPlateTaken', function(isPlateTaken)
			if not isPlateTaken then
				doBreak = true
			end
		end, generatedPlate)

		if doBreak then
			break
		end
	end

	return generatedPlate
end
function IsPlateTaken(plate)
	local callback = 'waiting'

	ESX.TriggerServerCallback('esx_vehicleshop:isPlateTaken', function(isPlateTaken)
		callback = isPlateTaken
	end, plate)

	while type(callback) == 'string' do
		Citizen.Wait(0)
	end

	return callback
end

function GetRandomNumber(length)
	Citizen.Wait(0)
	math.randomseed(GetGameTimer())
	if length > 0 then
		return GetRandomNumber(length - 1) .. NumberCharset[math.random(1, #NumberCharset)]
	else
		return ''
	end
end

function GetRandomLetter(length)
	Citizen.Wait(0)
	math.randomseed(GetGameTimer())
	if length > 0 then
		return GetRandomLetter(length - 1) .. Charset[math.random(1, #Charset)]
	else
		return ''
	end
end
RegisterNetEvent('Emil_chefmenu:police:openclient')
AddEventHandler('Emil_chefmenu:police:openclient', function()
	OpenResellerMenu()
end)