functionHandler = function(command, data, meta)
    ESX.TriggerServerCallback("esx_service:isInService", function(isInService)
        if not hasPoliceJob then 
            return
        end

        if isTackling then
            return
        end

        local gradeName = ESX.PlayerData.job.grade_name
        if not isTableEmpty(data) then
            if data["rangBlacklist"] then
                local hasBlacklist = false
                for k, rang in pairs(data["rangBlacklist"]) do
                    if string.find(gradeName, rang) then
                        hasBlacklist = true
                    end
                end

                if hasBlacklist then
                    ----exports['mythic_notify']:DoHudText('error', 'Du har ikke lov til dette.', 5000)
                    TriggerEvent('ox_lib:notify', {type = 'error', description = 'Du har ikke lov til dette.' })
                    return
                end
            end

            if data["isServiceRequired"] then
                local hasByPass = false
                if data["serviceByPass"] then
                    for i=1, #data["serviceByPass"], 1 do
                        local rang = data["serviceByPass"][i]
                        if string.find(gradeName, rang) then
                            hasByPass = true
                        end
                    end
                end

                if not isInService and not hasByPass then
                    --exports['mythic_notify']:DoHudText('error', 'Du skal melde på arbejde før du kan gøre dette.', 5000)
                    TriggerEvent('ox_lib:notify', {type = 'error', description = "Du skal melde på arbejde før du kan gøre dette." })
                    return
                end
            end

            if data["rangPolyRequired"] then
                local isPolyZone = false
                for k, rang in pairs(data["rangPolyRequired"]) do
                    if string.find(gradeName, rang) then
                        isPolyZone = true
                    end
                end

                if isPolyZone and EnteredStation == nil then
                    --exports['mythic_notify']:DoHudText('error', 'Du kan kun gøre dette på en Politistation/Fængsel.', 5000)
                    TriggerEvent('ox_lib:notify', {type = 'error', description = "Du kan kun gøre dette på en Politistation/Fængsel." })
                    return
                end
            end

            if data["polyRequired"] then
                if EnteredStation == nil then
                    --exports['mythic_notify']:DoHudText('error', 'Du kan kun gøre dette på en Politistation/Fængsel.', 5000)
                    TriggerEvent('ox_lib:notify', {type = 'error', description = "Du kan kun gøre dette på en Politistation/Fængsel." })
                    return
                end
            end
        end

        if command == 'police_tablet' then
            local apps = {
                {name = "policedatabase", label = "Politi", img = "politi.png"},
                {name = "kriminal", label = "Fængslet", img = "politi.png"},
            }

            OpenPoliceTablet(apps)
        end

        if command == 'giveplayer' then
            TriggerServerEvent("esx_policejob:giveItem", data)
        end

        if command == 'ToggleService' then
            ToggleService(isInService)
        end

        if command == 'Cloakrooms' then
            Cloakroom()
        end

        if command == 'MissionRowArmory' then
            exports.ox_inventory:openInventory('shop', { type = 'MissionRowArmory', id = 1 })
        end

        if command == 'WeazelArmory' then
            exports.ox_inventory:openInventory('shop', { type = 'WeazelArmory', id = 1 })
        end

        if command == 'PaletoArmory' then
            exports.ox_inventory:openInventory('shop', { type = 'PaletoArmory', id = 1 })
        end

        if command == 'SandyArmory' then
            exports.ox_inventory:openInventory('shop', { type = 'SandyArmory', id = 1 })
        end

        if command == 'PrisonCanteen' then
            exports.ox_inventory:openInventory('shop', { type = 'PrisonCanteen', id = 1 })
        end

        if command == 'MissionRowCanteen' then
            exports.ox_inventory:openInventory('shop', { type = 'MissionRowCanteen', id = 1 })
        end

        if command == 'WeazelCanteen' then
            exports.ox_inventory:openInventory('shop', { type = 'WeazelCanteen', id = 1 })
        end

        if command == 'PaletoCanteen' then
            exports.ox_inventory:openInventory('shop', { type = 'PaletoCanteen', id = 1 })
        end

        if command == 'SandyCanteen' then
            exports.ox_inventory:openInventory('shop', { type = 'SandyCanteen', id = 1 })
        end
        
        if command == 'clothing_toggle' then
            SetClotheProp(data)
        end

        if command == 'identity_card' then
            local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
            if closestPlayer == -1 or closestDistance > 3.0 then
                --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
                TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
                return
            end

            OpenIdentityCardMenu(closestPlayer)
        end

        if command == 'fine' then
            local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
            if closestPlayer == -1 or closestDistance > 3.0 then
                --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
                TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
                return
            end

            SendFine(closestPlayer)
        end

        if command == 'BossActions' then
            local actionCoords = data["coords"]

            ESX.UI.Menu.Open("default", GetCurrentResourceName(), "citizen_interaction", {
                title = 'Personlig Informationer',
                align = "top-left",
                elements = {
                    {label = "Administration", value = "boss_actions"},
                    {label = "Udlever Civil Bil", value = "boss_car"},
                }
            }, function(data, menu)
                menu.close()

                local value = data.current.value
                if value == nil then return end

                local hasWhitelist = data.current.whitelistRangs == nil
                if data.current.whitelistRangs ~= nil then
                    local whitelistRangs = data.current.whitelistRangs
                    for k, rang in pairs(whitelistRangs) do
                        if string.find(gradeName, rang) then
                            hasWhitelist = true
                        end
                    end
                end

                if hasWhitelist or gradeName == "boss" then
                    if value == "boss_actions" then
                        if gradeName == "boss" then
                            menu.close()
                            
							TriggerServerEvent("esx_jobs:openCompanyAdmin")
                        end
                    end

                    if value == "boss_car" then
                        exports.ESX_VEHICLESHOP:OpenResellerMenu(4)
                    end

                    if value == "hire_closest_player" then
                        print(data.current.firstgrade)
                        local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                        if closestPlayer == -1 or closestDistance > 3.0 then
                            --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
                            TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
                            return
                        end
                        
                        local firstgrade = data.current.firstgrade
                        TriggerServerEvent("esx_policejob:hirePlayer", GetPlayerServerId(closestPlayer), firstgrade, actionCoords)
                    end
                end
            end, function(data, menu)
                menu.close()
            end)
        end
        
        if command == 'spawnVehicle' or command == 'spawnBoat' or command == 'spawnHeli' then
            OpenVehicleMenu(command, data)
        end

        if command == 'vehicle' then
            spawnVehicle(data)
        end

        if command == 'deleteVehicle' then
            removeVehicle()
        end

        if command == 'handcuff_soft' or command == "handcuff_hard" then
            HandCuffPlayer(command)
        end

        if command == 'drag' then
            DragPlayer()
        end

        if command == 'put_in_vehicle' then
            SetIntoVehicle()
        end

        if command == 'out_the_vehicle' then
            SetOutOfVehicle()
        end

        if command == 'put_in_checkdata' then
            CheckVitals()
        end

        if command == 'vehicle_infos_plate' then
            GetVehicleInfosFromPlate()
        end
		
		if command == 'toggle_police_badge' then
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local badgeModel = GetHashKey("prop_fib_badge")

            LoadModel(badgeModel)

            local badgeProp = CreateObject(badgeModel, playerCoords.x, playerCoords.y, playerCoords.z + 0.2, true, true, true)
            local boneIndex = GetPedBoneIndex(playerPed, 28422)

            AttachEntityToEntity(badgeProp, playerPed, boneIndex, 0.065, 0.029, -0.035, 80.0, -1.90, 75.0, true, true, false, true, 1, true)

            local animDict = "paper_1_rcm_alt1-9"
            RequestAnimDict(animDict)
            while not HasAnimDictLoaded(animDict) do
                Citizen.Wait(1)
            end
            
            TaskPlayAnim(playerPed, animDict, 'player_one_dual-9', 8.0, -8, 10.0, 49, 0, 0, 0, 0)

            Citizen.Wait(3500)

            ClearPedSecondaryTask(playerPed)
            DeleteObject(badgeProp)
        end

        if command == 'traffic_menu' then
            TrafficMenu()
        end

        if command == 'gps' then
            local input = lib.inputDialog('Sæt badgenummer og gruppe', {
                { type = "input", label = "Badge nummer", description = "Angiv dit badge nummer (Ses på GPS)", icon = "hashtag"},
                { type = 'select', label = 'Vælg beredskab', options = {
                    { value = 'option1', label = 'Indsatsleder' },
                    { value = 'option2', label = 'Beredskabet' },
                    { value = 'option3', label = 'MC'},
                    { value = 'option4', label = 'Civil'},
                    { value = 'option5', label = 'Romeo'},
                    { value = 'option6', label = 'Krim'}, 
                    { value = 'option7', label = 'Foxtrot'},
                }, description = "Vælg dit beredskab, der skal vises på GPSen.", icon = "building-shield"},
                { type = 'select', label = 'GPS Status', options = {
                    { value = 'option8', label = 'GPS Status 🟢' },
                    { value = 'option9', label = 'GPS Status 🔴' },
                }, icon = "sliders"}
            })
        
            if input then
                local badgeNumber = input[1].value
                local selectedGroup = input[2].value
                local gpsStatus = input[3].value
        
                if gpsStatus == 'option8' then
                    exports['rflx_pdblips']:goOnDuty() -- Turn on the blip
                elseif gpsStatus == 'option9' then
                    exports['rflx_pdblips']:goOffDuty() -- Turn off the blip
                end
            end
        end
        

    RegisterCommand('toggleblip', function()
        if not isPlayerInService then
            exports['mythic_notify']:SendAlert('error', 'Du er ikke på vagt.', 5000)
            return
        end
    
        local player = PlayerId()
        if blipActive then
            TriggerServerEvent('badBlips:server:removePlayerBlipGroup', GetPlayerServerId(player), 'police')
            blipActive = false
    
            exports['mythic_notify']:SendAlert('error', 'Du har slået din GPS fra.', 5000)
            return
        end
    
        if not blipActive then
            TriggerServerEvent('badBlips:server:registerPlayerBlipGroup', GetPlayerServerId(player), 'police')
            blipActive = true
    
            exports['mythic_notify']:SendAlert('success', 'Du har slået din GPS til.', 5000)
            return
        end
    end)

    print(json.encode(input, {indent=true}))

        if command == 'panic_button' then
            ExecutePanicButton()
        end

        if command == 'spawn_object' then
            PlaceObject(data)
        end

        if command == 'spawn_stinger' then
            PlaceStinger(data)
        end

        if command == 'toggle_object_finder' then
            lookforObjects = not lookforObjects

            if lookforObjects then
                --exports['mythic_notify']:DoHudText('success', 'Scanner for Genstande er startet.', 5000)
                TriggerEvent('ox_lib:notify', {type = 'error', description = "Scanner for Genstande er startet." })
            end

            if not lookforObjects then
                --exports['mythic_notify']:DoHudText('error', 'Scanner for Genstande er sluttet.', 5000)
                TriggerEvent('ox_lib:notify', {type = 'error', description = 'Scanner for Genstande er sluttet.' })
            end

            StartObjectFinder()
        end

        if command == 'delete_objects' then
            DeleteLocalObjects()
        end
    end, "police")
end

ToggleService = function(isInService)
    local player = PlayerId()
    if not isInService then
        ESX.TriggerServerCallback("esx_service:enableService", function(canTakeService, maxInService, inServiceCount)
            if not canTakeService then
                ESX.ShowNotification("Du kan ikke tage på vagt, der er for mange på arbejde: " .. inServiceCount .. "/" .. maxInService)
            end

            if canTakeService then
                local notification = {
                    title = "Vagtinformation",
                    subject = "",
                    msg = "Operatør " .. GetPlayerName(PlayerId()) .. " er kommet på vagt.",
                    iconType = 0
                }
                        
                TriggerServerEvent('badBlips:server:registerSourceName')
                TriggerServerEvent('esx_service:notifyAllInService', notification, 'police')
                TriggerServerEvent('badBlips:server:registerPlayerBlipGroup', source, 'police')
                --exports['mythic_notify']:DoHudText('success', 'Du er taget på vagt.', 5000)
                TriggerEvent('ox_lib:notify', {type = 'success', description = "Du er taget på vagt.", icon = 'id-badge' })
                blipActive = true

                isPlayerInService = true
            end
        end, "police")
    end

    if isInService then
        local notification = {
            title = "Vagtinformation",
            subject = "",
            msg = "Operatør " .. GetPlayerName(PlayerId()) .. " har stoppet sin vagt.",
            iconType = 0
        }
            
        TriggerServerEvent("esx_service:notifyAllInService", notification, "police")
        TriggerServerEvent("esx_service:disableService", "police")

        TriggerServerEvent('badBlips:server:removePlayerBlipGroup', source, 'police')
        blipActive = false

        --exports['mythic_notify']:DoHudText('error', 'Du har stoppet din vagt.', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Du har stoppet din vagt.", icon = 'id-badge' })

        isPlayerInService = false
    end
end

RegisterCommand('toggleblip', function()
    if not isPlayerInService then
        --exports['mythic_notify']:DoHudText('error', 'Du er ikke på vagt.', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Du er ikke på vagt." })
        return
    end

    local player = PlayerId()
    if blipActive then
        TriggerServerEvent('badBlips:server:removePlayerBlipGroup', GetPlayerServerId(player), 'police')
        blipActive = false

        --exports['mythic_notify']:DoHudText('error', 'Du har slået din GPS fra.', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Du har slået din GPS fra." })
        return
    end

    if not blipActive then
        TriggerServerEvent('badBlips:server:registerPlayerBlipGroup', GetPlayerServerId(player), 'police')
        blipActive = true

        --exports['mythic_notify']:DoHudText('success', 'Du har slået din GPS til.', 5000)
        TriggerEvent('ox_lib:notify', {type = 'success', description = "Du har slået din GPS til." })
        return
    end
end)


ExecutePanicButton = function()
    local playerPed = PlayerPedId()
    local x, y, z = table.unpack(GetEntityCoords(playerPed, false))

    local streetName = nil
    local streetName, crossing = GetStreetNameAtCoord(x, y, z)
    streetName = GetStreetNameFromHashKey(streetName)
    
    TriggerServerEvent('3dme:shareDisplay', 'Trykker på panik knap', 'me')
    TriggerServerEvent('esx_policejob:panic_button', x, y, z, streetName)
end

OpenIdentityCardMenu = function(closestPlayer)
    ESX.TriggerServerCallback("esx_policejob:getOtherPlayerData", function(data)
        if data then
            local elements = {}

            local nameLabel = 'Fulde navn: ' .. data.firstname .. " " .. data.lastname
            local dobLabel = 'Fødselsdag: ' .. data.dob
            local heightLabel = 'Højde: ' .. data.height .. 'cm'

			if data.sex then
				if string.lower(data.sex) == 'm' then
					sexLabel = 'Køn: Mand'
				else
					sexLabel = 'Køn: Kvinde'
				end
			else
				sexLabel = 'Køn: Ukendt'
			end

            table.insert(elements, {label = nameLabel, value = nil})
            table.insert(elements, {label = dobLabel, value = nil})
            table.insert(elements, {label = heightLabel, value = nil})
            table.insert(elements, {label = sexLabel, value = nil})

            if data.licenses then
                table.insert(elements, {label = '', value = nil})
                table.insert(elements, {label = '--- Licenser ---', value = nil})

                if #data.licenses > 0 then
                    for i = 1, #data.licenses, 1 do
                        if data.licenses[i].label and data.licenses[i].type then
                            table.insert(elements, {
                                label = data.licenses[i].label,
                                type = data.licenses[i].type,
                                value = 'license',
                            })
                        end
                    end
                end

                if #data.licenses <= 0 then
                    table.insert(elements, {label = 'INGEN LICENSER', value = nil})
                end
            end

            ESX.UI.Menu.Open("default", GetCurrentResourceName(), "citizen_interaction", {
                title = 'Personlig Informationer',
                align = "top-left",
                elements = elements
            }, function(data, menu)
                local value = data.current.value
                if value == nil then return end

                ESX.ShowNotification('Du har fjernet ' .. data.current.label)
                TriggerServerEvent("esx_policejob:message", GetPlayerServerId(closestPlayer), 'Du har fået fjernet ' .. data.current.label)
                
                TriggerServerEvent("esx_license:removeLicense", GetPlayerServerId(closestPlayer), data.current.type)
                TriggerServerEvent("esx_dmvschool:reloadLicenses", GetPlayerServerId(closestPlayer))

                ESX.SetTimeout(300, function()
                    OpenIdentityCardMenu(closestPlayer)
                end)
            end, function(data, menu)
                menu.close()
            end)
        end
    end, GetPlayerServerId(closestPlayer))
end


OpenBodySearchMenu = function(closestPlayer, isReopen)
    exports.ox_inventory:openInventory('player', GetPlayerServerId(closestPlayer))
    --ESX.TriggerServerCallback("esx_policejob:getOtherPlayerData", function(data)
    --    if data then
    --        local elements = {}
--
    --        if not isReopen then
    --            TriggerServerEvent('3dme:shareDisplay', 'Visitere Personen', 'me')
    --        end
--
    --        for i = 1, #data.accounts, 1 do
    --            if data.accounts[i].name == "black_money" and data.accounts[i].money > 0 then
    --                table.insert(elements, {
    --                    label = ESX.Math.GroupDigits(data.accounts[i].money) .. ',- DKK',
    --                    value = "black_money",
    --                    itemType = "item_account",
    --                    amount = data.accounts[i].money
    --                })
    --            end
    --        end
--
    --        for i = 1, #data.weapons, 1 do
    --            table.insert(elements, {
    --                label = ESX.GetWeaponLabel(data.weapons[i].name),
    --                value = data.weapons[i].name,
    --                itemType = "item_weapon",
    --                amount = data.weapons[i].ammo
    --            })
    --        end
--
    --        for i = 1, #data.inventory, 1 do
    --            if data.inventory[i].count > 0 then
    --                table.insert(elements, {
    --                    label = data.inventory[i].label .. ' x' .. data.inventory[i].count,
    --                    value = data.inventory[i].name,
    --                    itemType = "item_standard",
    --                    amount = data.inventory[i].count
    --                })
    --            end
    --        end
--
    --        ESX.UI.Menu.Open("default", GetCurrentResourceName(), "body_search", {
    --            title = 'Personens Inventar',
    --            align = "top-left",
    --            elements = elements
    --        }, function(data, menu)
    --            local itemType = data.current.itemType
    --            local itemName = data.current.value
    --            local amount = data.current.amount
    --            
    --            if data.current.value ~= nil then
    --                TriggerServerEvent("esx_policejob:confiscatePlayerItem", GetPlayerServerId(closestPlayer), itemType, itemName, amount)
    --                OpenBodySearchMenu(closestPlayer, true)
    --            end
    --        end, function(data, menu)
    --            menu.close()
    --        end)
    --    end
    --end, GetPlayerServerId(closestPlayer))
end

HandCuffPlayer = function(command)
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
    if closestPlayer == -1 or closestDistance > 1.0 then
        --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
        return
    end

    local playerPed = PlayerPedId()
    local targetPed = GetPlayerPed(closestPlayer)
    if command == "handcuff_hard" then
        if not IsEntityPlayingAnim(targetPed, "random@mugging3", "handsup_standing_base", 3) then
            --exports['mythic_notify']:DoHudText('error', 'Personen har ikke hænderne op.', 5000)
            TriggerEvent('ox_lib:notify', {type = 'error', description = "Personen har ikke hænderne op." })
            return
        end
    end

    if IsPedInAnyVehicle(playerPed) then
        return
    end

    local closestID = GetPlayerServerId(closestPlayer)
    if Player(closestID).state.isDead then
        return
    end

    TriggerServerEvent("esx_policejob:handcuff", closestID, command)
end

DragPlayer = function()
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
    if closestPlayer == -1 or closestDistance > 3.0 then
        --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
        return
    end

    TriggerServerEvent("esx_policejob:drag", GetPlayerServerId(closestPlayer))
end

SetIntoVehicle = function()
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
    if closestPlayer == -1 or closestDistance > 3.0 then
        --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
        return
    end

    TriggerServerEvent('3dme:shareDisplay', 'Sætter Personen i køretøjet', 'me')
    TriggerServerEvent("esx_policejob:putInVehicle", GetPlayerServerId(closestPlayer))
end

SetOutOfVehicle = function()
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
    if closestPlayer == -1 or closestDistance > 3.0 then
        --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
        return
    end

    TriggerServerEvent('3dme:shareDisplay', 'Tager personen ud af køretøjet', 'me')
    TriggerServerEvent("esx_policejob:OutVehicle", GetPlayerServerId(closestPlayer))
end

JailPlayer = function()
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
    if closestPlayer == -1 or closestDistance > 3.0 then
        --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "'Ingen personer i nærheden. (Gå tættere på)" })
        return
    end

    ESX.UI.Menu.Open("dialog", GetCurrentResourceName(), "jail_menu",  {
        title = 'Fængselstid (I Min)'
    }, function(data, menu)
        local amount = tonumber(data.value)

        if amount == nil then
            --exports['mythic_notify']:DoHudText('error', 'Ugyldigt antal.', 5000)
            TriggerEvent('ox_lib:notify', {type = 'error', description = "Ugyldigt antal." })
            return
        end

        if amount ~= nil then
            --exports['mythic_notify']:DoHudText('success', "Du har nu fængslet " .. GetPlayerServerId(closestPlayer) .. ' i ' .. amount .. ' min.', 5000)
            TriggerEvent('ox_lib:notify', {type = 'error', description = "Du har nu fængslet " .. GetPlayerServerId(closestPlayer) .. ' i ' .. amount .. ' min.' })
            TriggerServerEvent("savanha_prison:putInJail", GetPlayerServerId(closestPlayer), amount * 60)

            menu.close()
        end
    end, function(data, menu)
        menu.close()
    end)
end

SendFine = function(closestPlayer)
    ESX.UI.Menu.Open("dialog", GetCurrentResourceName(), "fine_amount",  {
        title = 'Bøde Størrelse'
    }, function(data, menu)
        local amount = tonumber(data.value)
            
        if amount == nil then
            --exports['mythic_notify']:DoHudText('error', 'Ugyldigt antal.', 5000)
            TriggerEvent('ox_lib:notify', {type = 'error', description = "Ugyldigt antal." })
            return
        end

        if amount ~= nil then
            --exports['mythic_notify']:DoHudText('success', "Bøden er nu blevet givet til: " .. GetPlayerServerId(closestPlayer), 5000)
            TriggerEvent('ox_lib:notify', {type = 'error', description = "Bøden er nu blevet givet til: " .. GetPlayerServerId(closestPlayer) })
            TriggerServerEvent("esx_billing:sendBill", GetPlayerServerId(closestPlayer), "society_police", "Samlet bøde: " .. ESX.Math.GroupDigits(data.value) .. " DKK", tonumber(data.value))

            menu.close()
        end
    end, function(data, menu)
        menu.close()
    end)
end

CheckUnpaidBills = function(closestPlayer)
    ESX.TriggerServerCallback("esx_billing:getTargetBills", function(bills)
        if bills then
            local elements = {}

            for i = 1, #bills, 1 do
                local bill = bills[i]

                if bill["target"] == "society_police" then
                    table.insert(elements, {
                        label = bills[i].label .. ' - <span style="color: red;">' .. bills[i].amount .. ",- DKK</span>",
                        value = bills[i].id
                    })
                end
            end

            ESX.UI.Menu.Open("default", GetCurrentResourceName(), "billing", {
                title = 'Bøder fra Personen',
                align = "top-left",
                elements = elements
            }, function(data, menu)
                local gradeName = ESX.PlayerData.job.grade_name
                if gradeName ~= "boss" then
                    return
                end

                local value = data.current.value
                TriggerServerEvent("esx_policejob:removeBill", value, GetPlayerServerId(closestPlayer))

                --exports['mythic_notify']:DoHudText('success', 'Du har fjernet en bøde fra ID: ' .. GetPlayerServerId(closestPlayer), 5000)
                TriggerEvent('ox_lib:notify', {type = 'error', description = 'Du har fjernet en bøde fra ID: ' .. GetPlayerServerId(closestPlayer) })

                ESX.SetTimeout(300, function()
                    CheckUnpaidBills(closestPlayer)
                end)
            end,function(data, menu)
                menu.close()
            end)
        end
    end, GetPlayerServerId(closestPlayer))
end

CheckVitals = function()
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
    if closestPlayer == -1 or closestDistance > 3.0 then
        --exports['mythic_notify']:DoHudText('error', 'Ingen personer i nærheden. (Gå tættere på)', 5000)
        TriggerEvent('ox_lib:notify', {type = 'error', description = "Ingen personer i nærheden. (Gå tættere på)" })
        return
    end

    TriggerServerEvent("medSystem:Check", GetPlayerServerId(closestPlayer))
end

GetVehicleInfos = function(plate)
    ESX.TriggerServerCallback("esx_policejob:getVehicleInfos", function(retrivedInfo)
        if retrivedInfo then
			local elements = {}

			table.insert(elements, {label = 'Nummerplade: ' .. retrivedInfo.plate, value = nil})
			
			if retrivedInfo.owner == nil then
				table.insert(elements, {label = 'Ukendt', value = nil})
			end

			if retrivedInfo.owner ~= nil then
				table.insert(elements, {label = 'Ejer: ' .. retrivedInfo.owner, value = nil})
                table.insert(elements, {label = 'Ejerens Telefon Nummer: ' .. retrivedInfo.number, value = nil})
				table.insert(elements, {label = 'Fødselsdags Dato: ' .. retrivedInfo.dob, value = nil})
			end
            
            ESX.UI.Menu.Open("default", GetCurrentResourceName(), "vehicle_infos", {
                title = 'Køretøjsinformationer',
                align = "top-left",
                elements = elements
            }, function(data, menu)
            end, function(data, menu)
                menu.close()
            end)
        end
    end, plate)
end
GetVehicleInfosFromPlate = function()
    ESX.UI.Menu.Open("dialog", GetCurrentResourceName(), "fine_amount",  {
        title = 'Indtast nummerplade'
    }, function(data, menu)
        menu.close()

        local plate = data.value
        if plate == nil then
            --exports['mythic_notify']:DoHudText('error', 'Ugyldig nummerplade.', 5000)
            TriggerEvent('ox_lib:notify', {type = 'error', description = "Ugyldig nummerplade." })
            return
        end

        if plate ~= nil then
            GetVehicleInfos(plate)
        end
    end, function(data, menu)
        menu.close()
    end)
end

HighJackVehicle = function(vehicle)
    local playerPed = PlayerPedId()
    
    if not DoesEntityExist(vehicle) then
        return
    end

    TaskTurnPedToFaceEntity(playerPed, vehicle, 1500)
    Citizen.Wait(1500)

    exports.rprogress:Custom({
        Type = 'linear',
        Duration = 20000,
        Width = 300,
        Height = 35,
        y = 0.75,
        Label = "Åbner køretøj",
        Animation = {
            scenario = "WORLD_HUMAN_WELDING",
        },
        DisableControls = {
            Player = true,
            Vehicle = true
        },
        onComplete = function()
            if networkControl(vehicle) then
                SetVehicleDoorsLocked(vehicle, 1)
                SetVehicleDoorsLockedForAllPlayers(vehicle, false)

                ClearPedTasksImmediately(playerPed)

                local playerCoords = GetEntityCoords(playerPed)
                ClearAreaOfObjects(playerCoords.x, playerCoords.y, playerCoords.z, 5.0, 0)

                TriggerEvent('vehicle:ForceOpen')
            end
        end
    })
end


PlaceObject = function(data)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local forward = GetEntityForwardVector(playerPed)
    local x, y, z = table.unpack(coords + forward * 1.0)

    local model = data["object"]
    ESX.Game.SpawnObject(model, {
        x = x,
        y = y,
        z = z
    }, function(obj)
        SetEntityHeading(obj, GetEntityHeading(playerPed))
        PlaceObjectOnGroundProperly(obj)
    end)
end

PlaceStinger = function(data)
    local elements = {
        {
            label = "Antal",
            value = data["value"],
            type = 'slider',
            min = data["min"],
            max = data["max"],
        }
    }

    ESX.UI.Menu.CloseAll()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'stinger_spikes', {
		title    = "Trafik Zone",
		align    = 'bottom-right',
		elements = elements
    }, function(menuData, menu)
        local amount = menuData.current.value
        
        local playerPed = PlayerPedId()
        FreezeEntityPosition(playerPed, true)

        local spawnCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 2.0, 0.0)
        local dict = "anim@amb@clubhouse@tutorial@bkr_tut_ig3@"
        local anim = "machinic_loop_mechandplayer"

        LoadAnim(dict)

        TaskPlayAnim(playerPed, dict, anim, 2.0, 2.0, -1, 1, 0, false, false, false)
        exports['progressBars']:startUI(amount * 750, 'Placere Spike Strips')

        local model = data["object"]
        for i = 1, amount do
            Citizen.Wait(750)

            local x, y, z = table.unpack(spawnCoords)
            ESX.Game.SpawnObject(model, {
                x = x,
                y = y,
                z = z
            }, function(obj)
                SetEntityHeading(obj, GetEntityHeading(playerPed))
                PlaceObjectOnGroundProperly(obj)

                spawnCoords = GetOffsetFromEntityInWorldCoords(obj, 0.0, 4.0, 0.0)
            end)
        end

        FreezeEntityPosition(playerPed, false)
        ClearPedTasks(playerPed)

        menu.close()
    end, function(menuData, menu)
		menu.close()
	end)
end

DeleteLocalObjects = function()
    local Objects = {}

    for k,v in pairs(Config.PoliceMenu) do
        if v.action == "object_spawner" then
            for i=1, #v.menu, 1 do
                local object = v.menu[i]

                if object.data ~= nil then
                    if object.data.object ~= nil then
                        table.insert(Objects, GetHashKey(object.data.object))
                    end
                end
            end
        end
    end

    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)

    local objectsInArea = ESX.Game.GetObjects()
    for k, object in pairs(objectsInArea) do
        local targetObject = GetEntityModel(object)
        
        for i=1, #Objects, 1 do
            local localObject = Objects[i]

            if targetObject == localObject then
                local objectsCoords = GetEntityCoords(object)
                local distance = #(objectsCoords - coords)
                
                if distance <= 20.0 then
                    DeleteLocalObject(object)
                end
            end
        end
    end
end

DeleteLocalObject = function(object)
    local attempt = 0
    while not NetworkHasControlOfEntity(object) and attempt < 100 and DoesEntityExist(object) do
        Wait(100)
        NetworkRequestControlOfEntity(object)
        attempt = attempt + 1
    end

    if DoesEntityExist(object) and NetworkHasControlOfEntity(object) then
        ESX.Game.DeleteObject(object)
    end
end

Cloakroom = function()
    local gender = 'Male'
    local menuOptions = {}
    TriggerEvent("skinchanger:getSkin", function(skin)
        if skin.sex == 0 then
            gender = 'Male'
        end

        if skin.sex ~= 0 then
            gender = 'Female'
        end
    end)

    for k, v in ipairs(Config.Cloakroom[gender]) do
        menuOptions[#menuOptions+1] = {
            title = v.label,
            description = '',
            icon = 'shirt',
            onSelect = function()
                local outfit = Config.Cloakroom[gender][k]
                local action = Config.Cloakroom[gender][v.action]
        
                local playerPed = PlayerPedId()
                if action == 'civil' then
                    SetPedArmour(playerPed, 0)
        
                    ESX.TriggerServerCallback("esx_skin:getPlayerSkin", function(skin, jobSkin)
                        local isMale = skin.sex == 0
        
                        TriggerEvent("skinchanger:loadDefaultModel", isMale, function()
                            ESX.TriggerServerCallback("esx_skin:getPlayerSkin", function(skin)
                                TriggerEvent("skinchanger:loadSkin", skin)
                            end)
                        end)
                    end)
                end
        
                if action ~= 'civil' then
                    if action == 'bullet_wear' then
                        SetPedArmour(playerPed, 100)
                    end
        
                    setUniform(outfit.cloth)
                end
                --end
            end,
          }
        --end

        lib.registerContext({
            id = 'popo_cloakroom',
            title = 'Politi - Omklædningen',
            options = menuOptions
        })
        lib.showContext('popo_cloakroom')
    end
end

Cloakroom2 = function()
    local gender = 'Male'
    local cloakroom_menu = {}
    
    TriggerEvent("skinchanger:getSkin", function(skin)
        if skin.sex == 0 then
            gender = 'Male'
        end

        if skin.sex ~= 0 then
            gender = 'Female'
        end
    end)
    
    for k, v in ipairs(Config.Cloakroom[gender]) do
        table.insert(cloakroom_menu, {label = v.label, value = k})
    end
    
    ESX.UI.Menu.Open("default", GetCurrentResourceName(), "cloakroom", {
        title = 'Omklædning',
        align = "top-left",
        elements = cloakroom_menu
    }, function(data, menu)
        local outfit = Config.Cloakroom[gender][data.current.value]
        local action = outfit.action

        local playerPed = PlayerPedId()
        if action == 'civil' then
            SetPedArmour(playerPed, 0)

            ESX.TriggerServerCallback("esx_skin:getPlayerSkin", function(skin, jobSkin)
                local isMale = skin.sex == 0

                TriggerEvent("skinchanger:loadDefaultModel", isMale, function()
                    ESX.TriggerServerCallback("esx_skin:getPlayerSkin", function(skin)
                        TriggerEvent("skinchanger:loadSkin", skin)
                    end)
                end)
            end)
        end

        if action ~= 'civil' then
            if action == 'bullet_wear' then
                SetPedArmour(playerPed, 100)
            end

            setUniform(outfit.cloth)
        end
    end, function(data, menu)
        menu.close()
    end)
end

setUniform = function(cloth)
	TriggerEvent("skinchanger:getSkin", function(skin)
		if skin.sex == 0 then
			if cloth ~= nil then
				TriggerEvent("skinchanger:loadClothes", skin, cloth)
			end
        end

        if skin.sex ~= 0 then
			if cloth ~= nil then
				TriggerEvent("skinchanger:loadClothes", skin, cloth)
			end
		end
	end)
end

OpenArmoryMenu = function(data)
    exports.ox_inventory:openInventory('shop', { type = 'PoliceArmoury', id = 1 })
    --local station = Config.PoliceStations[data["station"]]
    --local armory = station.AuthorizedWeapons
--
    --for k,v in pairs(armory) do
    --    if v.data then
    --        if v.data["type"] == "weapon" then
    --            local name = v.data["name"]
    --            local label = ESX.GetWeaponLabel(name)
--
    --            v.label = label
    --        end
--
    --        v.data["label"] = v.label
    --    end
    --end
--
    --GenerateMenu(armory, '', '', true)
end

OpenCanteenMenu = function()
    --exports.ox_inventory:openInventory('shop', { type = 'PoliceArmoury', id = 1 })
    exports.ox_inventory:openInventory('shop', { type = 'PoliceCanteen', id = 1 })
   --local Canteen = deepcopy(Config.Canteen)
   --
   --for k,v in pairs(Canteen) do
   --    if v.label and v.data then
   --        v.label = v.label .. ' x' .. v.data.amount
   --        v.data["label"] = v.label
   --    end
   --end

   --GenerateMenu(Canteen, '', '')
end

SetClotheProp = function(data)
    local playerPed = PlayerPedId()

    TriggerEvent('skinchanger:getSkin', function(skin)
        if skin.sex == 0 then
            if data["componentId"] == 0 then
                local propComponent = GetPedPropIndex(playerPed, data["componentId"])

                if propComponent ~= data["propOn"] then
                    SetPedPropIndex(playerPed, data["componentId"], data["propOn"], data["propOnTextures"], 2)
                end

                if propComponent == data["propOn"] then
                    SetPedPropIndex(playerPed, data["componentId"], 0, 0, 2)

                    if data["propOff"] then
                        ClearPedProp(playerPed, 0)
                    end
                end
            end

            if data["componentId"] ~= 0 then
                local propComponent = GetPedDrawableVariation(playerPed, data["componentId"])

                if propComponent ~= data["propOn"] then
                    SetPedComponentVariation(playerPed, data["componentId"], data["propOn"], data["propOnTextures"], 2)
                end

                if propComponent == data["propOn"] then
                    SetPedComponentVariation(playerPed, data["componentId"], 0, 0, 2)
                end
            end
        end
    end)
end

OpenVehicleMenu = function(vehicle, data)
    local station = Config.PoliceStations[data["station"]]
    local vehicles = {}

    if vehicle == "spawnVehicle" then
        vehicles = station.AuthorizedVehicles
    end

    if vehicle == "spawnBoat" then
        vehicles = station.AuthorizedBoats
    end

    if vehicle == "spawnHeli" then
        vehicles = station.AuthorizedHelicopters
    end

    for k,v in pairs(vehicles) do
        if v.data then
            v.data["point"] = data["SpawnPoint"]
        end
    end

    GenerateMenu(vehicles, '', '')
end

spawnVehicle = function(data)
    local coords = vector3(data["point"].x, data["point"].y, data["point"].z)
    local heading = data["point"].w

    if not ESX.Game.IsSpawnPointClear(coords, 5.0) then
        exports['mythic_notify']:DoHudText('error', 'Spawn Pointet er ikke frit.', 5000)
        return
    end

    ESX.Game.SpawnVehicle(data.model, coords, heading, function(vehicle)
        local fuelAmount = 100
        local plate = exports['ESX_VEHICLESHOP']:GeneratedCustomPlate('POL', 4)
        if data["isCivil"] then
            plate = GeneratePlate()
        end
        
        SetVehicleNumberPlateText(vehicle, plate)
        
        local vehicleProps = ESX.Game.GetVehicleProperties(vehicle)
        TriggerServerEvent("setOwnedServer", vehicleProps)

        if data.model == "mercedesc250" then
            SetEntityRotation(vehicle, 1.0, 1.0, 1.0, 1.0, true)
        end
        
        SetEntityHeading(vehicle, heading)
        SetVehicleMaxMods(vehicle)
        exports['t1ger_keys']:GiveTemporaryKeys(plate, GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)), "POLITI")
        exports["LegacyFuel"]:SetFuel(vehicle, 100)
        Entity(vehicle).state.fuel = fuelAmount
    end)
end

SetVehicleMaxMods = function(vehicle)
    local props = {
        modEngine = 2,
        modBrakes = 2,
        modTransmission = 2,
        modSuspension = 3,
        modTurbo = true
    }
    
    ESX.Game.SetVehicleProperties(vehicle, props)
end

removeVehicle = function()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)

    if vehicle ~= 0 then
        local attempt = 0
        while not NetworkHasControlOfEntity(vehicle) and attempt < 100 and DoesEntityExist(vehicle) do
            Wait(150)
            
            NetworkRequestControlOfEntity(vehicle)
            attempt = attempt + 1
        end

        if DoesEntityExist(vehicle) and NetworkHasControlOfEntity(vehicle) then
            SetEntityAsMissionEntity(vehicle)
            DeleteVehicle(vehicle)
        end
    end
end

TrafficMenu = function()
    local elements = {}
	local radiusnum = { }
	local speednum = { }
	local speed = 0
	local radius = 0

    table.insert(elements, {
        label      = "Radius",
        option     = "set_zone_radius",

        -- menu properties
        value      = 50,
        type       = 'slider',
        min        = 1,
        max        = 100
    })

    table.insert(elements, {
        label      = "Max Hastighed",
        option     = "set_zone_speed",

        -- menu properties
        value      = 0,
        type       = 'slider',
        min        = 0,
        max        = 10
    })

    table.insert(elements, {
        label      = "Opret Zone",
        option     = "create_zone",
    })

    table.insert(elements, {
        label      = "Slet Zone",
        option     = "delete_zone",
    })

    ESX.UI.Menu.CloseAll()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'trafficzone', {
		title    = "Trafik Zone",
		align    = 'bottom-right',
		elements = elements
    }, function(data, menu)
        local playerPed = PlayerPedId()

        if data.current.option == 'create_zone' then
			if zoneActive then
                ESX.ShowNotification('Du har en aktiv hastigheds zone - Slet den før du opretter en ny!')
                return
            end

            local zoneRadius, zoneSpeed = 0, 0
            for k,v in pairs(data.elements) do
                if v.option == "set_zone_radius" then
                    zoneRadius = v.value
                end

                if v.option == "set_zone_speed" then
                    zoneSpeed = v.value
                end
            end
            
            
			speedZoneActive = true
			local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1)))
			radius = zoneRadius + 0.0
			speed = zoneSpeed + 0.0
			
			local streetName, crossing = GetStreetNameAtCoord(x, y, z)
			streetName = GetStreetNameFromHashKey(streetName)
	  
			local message = "" .. streetName .. "" 
			TriggerServerEvent('ZoneActivated', message, speed, radius, x, y, z)

            zoneActive = true
            ESX.ShowNotification('Opretter hastigheds zone')
        end
            
        if data.current.option == 'delete_zone' then
			TriggerServerEvent('Disable')

			zoneActive = false
            ESX.ShowNotification('Sletter hastigheds zone')
        end
	end, function(data, menu)
		menu.close()
	end)
end

RegisterNetEvent('Zone')
AddEventHandler('Zone', function(speed, radius, x, y, z)

  blip = AddBlipForRadius(x, y, z, radius)
  SetBlipSprite(blip,9)
  SetBlipColour(blip,70)
  SetBlipAlpha(blip,75)

  speedZone = AddSpeedZoneForCoord(x, y, z, radius, speed, false)

  table.insert(speedzones, {x, y, z, speedZone, blip})

end)

RegisterNetEvent('RemoveBlip')
AddEventHandler('RemoveBlip', function()

	if speedzones == nil then
		return
	end
	
    local playerPed = GetPlayerPed(-1)
    local x, y, z = table.unpack(GetEntityCoords(playerPed, true))
    local closestSpeedZone = 0
    local closestDistance = 1000
    for i = 1, #speedzones, 1 do
        local distance = Vdist(speedzones[i][1], speedzones[i][2], speedzones[i][3], x, y, z)
        if distance < closestDistance then
            closestDistance = distance
            closestSpeedZone = i
        end
    end
    RemoveSpeedZone(speedzones[closestSpeedZone][4])
    RemoveBlip(speedzones[closestSpeedZone][5])
    table.remove(speedzones, closestSpeedZone)

end)

CreateThread(function()
    TriggerEvent('chat:addSuggestion', '/+Onduty', 'Gå på job')
end)

RegisterKeyMapping('+Onduty', 'Gå på job', 'keyboard', '')
RegisterCommand("+Onduty", function(isInService)
    ToggleService()
end)

CreateThread(function()
    TriggerEvent('chat:addSuggestion', '/flip', 'Flip din hjelm')
end)

RegisterCommand("flip", function()
    FlipHelmet()
end)

FlipHelmet = function()
    if not hasPoliceJob then
        return
    end

    local dict = "anim@mp_helmets@on_foot"
    local upAnim = "goggles_up"
    local downAnim = "goggles_down"

    LoadAnim(dict)

    local playerPed = PlayerPedId()
    local texture = GetPedPropTextureIndex(playerPed, 0)

    if GetPedPropIndex(playerPed, 0) == 114 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 115, texture, true)
        return
    end

    if GetPedPropIndex(playerPed, 0) == 115 then
        TaskPlayAnim(playerPed, dict, downAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 114, texture, true)
        return
    end

    if GetPedPropIndex(playerPed, 0) == 116 then
        TaskPlayAnim(playerPed, dict, downAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 117, texture, true)
        return
    end

    if GetPedPropIndex(playerPed, 0) == 117 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 116, texture, true)
        return
    end

    if GetPedPropIndex(playerPed, 0) == 125 then
        TaskPlayAnim(playerPed, dict, upAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 126, texture, true)
        return
    end

    if GetPedPropIndex(playerPed, 0) == 126 then
        TaskPlayAnim(playerPed, dict, downAnim, 8.0, 8.0, 800, 1, 1, 0, 0, 0)

        Citizen.Wait(600)
        SetPedPropIndex(playerPed, 0, 125, texture, true)
        return
    end
end

local NumberCharset = {}
local Charset = {}

for i = 48,  57 do table.insert(NumberCharset, string.char(i)) end

for i = 65,  90 do table.insert(Charset, string.char(i)) end
for i = 97, 122 do table.insert(Charset, string.char(i)) end

GeneratePlate = function()
	local generatedPlate = nil
	local doBreak = false

	while true do
		Citizen.Wait(2)

		generatedPlate = string.upper(GetRandomLetter(2) .. GetRandomNumber(5))
        if not IsPlateTaken(generatedPlate) then
            doBreak = true
        end

		if doBreak then
			break
		end
	end

	return generatedPlate
end

IsPlateTaken = function(plate)
	local callback = 'waiting'

	ESX.TriggerServerCallback('ESX_VEHICLESHOP:isPlateTaken', function(isPlateTaken)
		callback = isPlateTaken
	end, plate)

	while type(callback) == 'string' do
		Citizen.Wait(0)
	end

	return callback
end

GetRandomNumber = function(length)
	if length > 0 then
		return GetRandomNumber(length - 1) .. NumberCharset[math.random(1, #NumberCharset)]
	end

    return ''
end

GetRandomLetter = function(length)
	if length > 0 then
		return GetRandomLetter(length - 1) .. Charset[math.random(1, #Charset)]
    end
    
    return ''
end

LoadAnim = function(dict)
	while not HasAnimDictLoaded(dict) do
		RequestAnimDict(dict)
		Citizen.Wait(1)
	end
end

LoadModel = function(model)
	while not HasModelLoaded(model) do
		RequestModel(model)
		Citizen.Wait(1)
	end
end
