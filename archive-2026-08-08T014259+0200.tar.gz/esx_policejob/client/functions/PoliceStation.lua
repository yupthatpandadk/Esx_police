local PolyPoliceStations = {}
local PolyPoliceZones = {}
EnteredStation = nil

RegisterPolyZone = function()
    Citizen.Wait(1000)

    for stationNum, station in pairs(Config.PoliceStations) do
        if station.Polys then
            local PolyStation = PolyZone:Create(station.Polys, {name = stationNum, debugPoly=false})
            table.insert(PolyPoliceStations, PolyStation)

            PolyStation:onPointInOut(PolyZone.getPlayerPosition, function(isPointInside, point)
                if isPointInside and EnteredStation == nil then
                    EnteredStation = stationNum
                end

                if not isPointInside and EnteredStation == stationNum then
                    EnteredStation = nil
                end
            end)
        end
    end

    for zone, polys in pairs(Config.Zones) do
        local PolyPoliceZone = PolyZone:Create(polys, {name = zone, debugPoly=false})
        table.insert(PolyPoliceZones, PolyPoliceZone)
    end
end

local EnteredZone = nil
local previousZone = nil

local zoneRefresh = 1 * 1000
InitZoneRefresh = function()
    Citizen.CreateThread(function()
        while hasPoliceJob do
            Citizen.Wait(zoneRefresh)

            if hasPoliceJob then
                local playerPed = PlayerPedId()
                local playerCoords = GetEntityCoords(playerPed)

                EnteredZone = GetPoliceZoneByCoords(playerCoords)
                if EnteredZone ~= previousZone then
                    if previousZone ~= nil then
                        AlertChangeOfZone()
                    end

                    previousZone = EnteredZone
                    Wait(10000)
                end
            end
        end
    end)
end

AlertChangeOfZone = function()
    PlaySoundFrontend(-1, 'FocusIn', 'HintCamSounds', true)
    --ESX.ShowNotification(("Du har nu bevæget dig ind i det ~y~%slige~s~ Distrikt"):format(GetPoliceZoneLabel(EnteredZone)))
    TriggerEvent('ox_lib:notify', {type = 'inform', description = ("Du har nu bevæget dig ind i det %slige Distrikt"):format(GetPoliceZoneLabel(EnteredZone)) })
end

GetPoliceZoneLabel = function(zone)
    return Config.ZonesLabel[zone]
end

GetPoliceZoneByCoords = function(coords)
    local coordsv2 = vector2(coords.x, coords.y)

    local policeZone = "north"
    for k, poly in pairs(PolyPoliceZones) do
        if poly:isPointInside(coords) then
            return poly.name
        end
    end

    for k, poly in pairs(PolyPoliceZones) do
        if not poly:isPointInside(coords) then
            for i=1, #poly.points, 1 do
                local distance = #(poly.points[i] - coordsv2)
                if distance <= 200.0 then
                    return poly.name
                end
            end
        end
    end

    return policeZone
end

exports("GetPoliceZoneByCoords", GetPoliceZoneByCoords)
exports("GetPoliceZoneLabel", GetPoliceZoneLabel)

RemoveRegisteredPolyZones = function()
    for k,poly in pairs(PolyPoliceStations) do
        if poly ~= nil then
            poly:destroy()
        end
    end

    for k,poly in pairs(PolyPoliceZones) do
        if poly ~= nil then
            poly:destroy()
        end
    end
end
