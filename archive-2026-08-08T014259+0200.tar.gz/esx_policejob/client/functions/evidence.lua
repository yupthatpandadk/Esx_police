exports.qtarget:AddTargetModel({`s_m_m_ciasec_01`}, {
	options = {
        {
			icon = "fas fa-archive",
			label = "Aflever Beviser",
            job = 'police',
            action = function()
                OpenEvidenceMenu(EnteredStation)
            end,
		},
	},
	distance = 2
})

RegisterNetEvent('policeevidence_menu:open', function(job)
    lib.registerContext({
        id = 'policeevidence_menu',
        title = 'Politi Bevis Menuen',
        onExit = function()
            lib.notify({
                title = 'Bevis Matriale Fyren',
                description = 'Tak fordi du kom forbi, hav en god patrulje.',
                type = 'success'
            })
        end,
        options = {
            {
                title = 'Aflever Beviser',
                description = 'Aflever beviser til manden.',
                onSelect = function()
                    OpenEvidenceMenu(EnteredStation)
                end,
            },
            {
                title = 'Aflever Beviser',
                description = 'Aflever beviser til manden.',
                onSelect = function()
                    OpenEvidenceLocker(EnteredStation)
                end,
            },
        }
    })
    lib.showContext('policeevidence_menu')
end)

OpenEvidenceMenu = function(station)
    ESX.TriggerServerCallback("esx_policejob:getOtherPlayerData", function(data)
        if data then
            local items = {}

            for i = 1, #data.accounts, 1 do
                local account = data.accounts[i]

                if account.name == "black_money" and account.money > 0 then
                    table.insert(items, {
                        label = ESX.Math.GroupDigits(account.money) .. ',- DKK',
                        name = "black_money",
                        type = "item_account",
                        count = account.money
                    })
                end
            end

            for i = 1, #data.weapons, 1 do
                local weapon = data.weapons[i]

                table.insert(items, {
                    label = ESX.GetWeaponLabel(weapon.name),
                    name = weapon.name,
                    type = "item_weapon",
                    count = weapon.ammo,
                })
            end

            for i = 1, #data.inventory, 1 do
                local item = data.inventory[i]

                if item.count > 0 then
                    table.insert(items, {
                        label = item.label,
                        name = item.name,
                        type = "item_standard",
                        count = item.count,
                    })
                end
            end

            SetNuiFocus(true, true)

            SendNUIMessage({
                openNewEvidence = true,
                inventory = items,
                station = station,
            })
        end
    end, GetPlayerServerId(PlayerId()))
end

OpenEvidenceLocker = function(station)
    if ESX.PlayerData.job.grade_name ~= "boss" then
        return
    end

    ESX.TriggerServerCallback("esx_policejob:getItemsFromLocker", function(cases)
        if cases then
            SetNuiFocus(true, true)

            SendNUIMessage({
                openWithdrawEvidence = true,
                locker = cases,
                station = station,
            })
        end
    end, station)
end

RegisterNUICallback('PutItemsInLocker', function(data, cb)
    SetNuiFocus(false)

    local station = data["station"]
    local case = data["case"]
    local items = data["items"]
    local officer = data["officer"]
    local badgeNumber = data["badgeNumber"]
    
    TriggerServerEvent("esx_policejob:putItemsInLocker", station, case, items, officer, badgeNumber)

    cb('ok')
end)

RegisterNUICallback('TakeItemsFromLocker', function(data, cb)
    SetNuiFocus(false)

    local station = data["station"]
    local caseID = data["case"]

    TriggerServerEvent("esx_policejob:takeItemsFromLocker", station, caseID)

    cb('ok')
end)

RegisterNUICallback('sendMessage', function(data, cb)
    local type = data["type"]
    local msg = data["message"]

    exports['mythic_notify']:DoHudText(type, msg, 5000)

    cb('ok')
end)

RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false)

    cb('ok')
end)