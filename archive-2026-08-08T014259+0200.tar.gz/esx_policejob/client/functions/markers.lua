RegisterMarkers = function()
    Citizen.Wait(1000)

    for stationNum, station in pairs(Config.PoliceStations) do
        if station.ToggleService then
            for k,v in ipairs(station.ToggleService) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_service_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at stemple ind/ud',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 24,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('ToggleService', {}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })

                Citizen.Wait(100)
            end
        end

        if station.Cloakrooms then
            for k,v in ipairs(station.Cloakrooms) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_cloak_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at åbne Omklædningen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 20,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('Cloakrooms', {station = stationNum}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })

                Citizen.Wait(100)
            end
        end

        if station.MissionRowArmory then
            for k, v in ipairs(station.MissionRowArmory) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_armory_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå våbenskabet',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 21,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('MissionRowArmory', {station = stationNum, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.WeazelArmory then
            for k, v in ipairs(station.WeazelArmory) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_armory_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå våbenskabet',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 21,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('WeazelArmory', {station = stationNum, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.PaletoArmory then
            for k, v in ipairs(station.PaletoArmory) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_armory_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå våbenskabet',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 21,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('PaletoArmory', {station = stationNum, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.SandyArmory then
            for k, v in ipairs(station.SandyArmory) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_armory_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå våbenskabet',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 21,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('SandyArmory', {station = stationNum, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.PrisonCanteen then
            for k, v in ipairs(station.PrisonCanteen) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_canteen_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå kantinen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 20,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('PrisonCanteen', {station = stationNum}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                
                Citizen.Wait(100)
            end
        end

        if station.MissionRowCanteen then
            for k, v in ipairs(station.MissionRowCanteen) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_canteen_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå kantinen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 20,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('MissionRowCanteen', {station = stationNum}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                
                Citizen.Wait(100)
            end
        end

        if station.WeazelCanteen then
            for k, v in ipairs(station.WeazelCanteen) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_canteen_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå kantinen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 20,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('WeazelCanteen', {station = stationNum}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                
                Citizen.Wait(100)
            end
        end

        if station.PaletoCanteen then
            for k, v in ipairs(station.PaletoCanteen) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_canteen_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå kantinen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 20,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('PaletoCanteen', {station = stationNum}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                
                Citizen.Wait(100)
            end
        end

        if station.SandyCanteen then
            for k, v in ipairs(station.SandyCanteen) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_canteen_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(0.75, 0.75, 0.75),
                    msg = 'Tryk <b>[E]</b> for at tilgå kantinen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 20,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('SandyCanteen', {station = stationNum}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                
                Citizen.Wait(100)
            end
        end

        if station.BossActions then
            for k, v in ipairs(station.BossActions) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_boss_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(1.5, 1.5, 1.0),
                    msg = 'Tryk <b>[E]</b> for at tilgå virksomheds menuen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 22,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    jobGrade = Config.MinimunBossRank,
                    action = function()
                        functionHandler('BossActions', {coords = v}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.Vehicles then
            for k, v in ipairs(station.Vehicles) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_vehicle_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v.Spawner,
                    scale = vector3(1.0, 1.0, 1.0),
                    msg = 'Tryk <b>[E]</b> for at tilgå Køretøjs Menuen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 36,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        --functionHandler('spawnVehicle', {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                        lib.registerContext({
                            id = 'veh_menu',
                            title = 'Vælg køretøjer',
                            options = {
                              {
                                title = 'Markerede Køretøjer',
                                description = 'Vælg en af de markerede køretøjer',
                                icon = 'car',
                                onSelect = function()
                                    local data = {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}
                                    local station = Config.PoliceStations[data["station"]]
                                    local vehicles = station.MarkedVehicles
                                    for k,v in pairs(vehicles) do
                                        if v.data then
                                            v.data["point"] = data["SpawnPoint"]
                                        end
                                    end
                                
                                    GenerateMenu(vehicles, '', '')
                                    --functionHandler('spawnVehicle', {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                                    --OpenVehicleMenu(marked, {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}})
                                end,
                              },
                              {
                                title = 'Civile Køretøjer',
                                description = 'Vælg en af de civile køretøjer',
                                icon = 'car',
                                onSelect = function()
                                    local data = {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}
                                    local station = Config.PoliceStations[data["station"]]
                                    local vehicles = station.CivilVehicles
                                    for k,v in pairs(vehicles) do
                                        if v.data then
                                            v.data["point"] = data["SpawnPoint"]
                                        end
                                    end
                                
                                    GenerateMenu(vehicles, '', '')
                                    --functionHandler('spawnVehicle', {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                                    --OpenVehicleMenu(marked, {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}})
                                end,
                              },
                              {
                                title = 'Aktionsstyrkens Køretøjer',
                                description = 'Vælg en af aktionsstyrkens køretøjer',
                                icon = 'car',
                                onSelect = function()
                                    local data = {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}
                                    local station = Config.PoliceStations[data["station"]]
                                    local vehicles = station.KrimVehicles
                                    for k,v in pairs(vehicles) do
                                        if v.data then
                                            v.data["point"] = data["SpawnPoint"]
                                        end
                                    end
                                
                                    GenerateMenu(vehicles, '', '')
                                    --functionHandler('spawnVehicle', {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                                    --OpenVehicleMenu(marked, {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}})
                                end,
                              },
                              {
                                title = 'Motorcykler',
                                description = 'Vælg en af motorcyklerne',
                                icon = 'car',
                                onSelect = function()
                                    local data = {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}
                                    local station = Config.PoliceStations[data["station"]]
                                    local vehicles = station.MCVehicles
                                    for k,v in pairs(vehicles) do
                                        if v.data then
                                            v.data["point"] = data["SpawnPoint"]
                                        end
                                    end
                                
                                    GenerateMenu(vehicles, '', '')
                                    --functionHandler('spawnVehicle', {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                                    --OpenVehicleMenu(marked, {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}})
                                end,
                              }
                            }
                          })
                          lib.showContext('veh_menu')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.Boats then
            for k, v in ipairs(station.Boats) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_boat_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v.Spawner,
                    scale = vector3(1.0, 1.0, 1.0),
                    msg = 'Tryk <b>[E]</b> for at tilgå Køretøjs Menuen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 35,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('spawnBoat', {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.Helicopters then
            for k, v in ipairs(station.Helicopters) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_helicopter_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v.Spawner,
                    scale = vector3(1.0, 1.0, 1.0),
                    msg = 'Tryk <b>[E]</b> for at tilgå Køretøjs Menuen',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 34,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('spawnHeli', {station = stationNum, SpawnPoint = v.SpawnPoint, isServiceRequired = true}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end

        if station.VehicleDeleters then
            for k, v in ipairs(station.VehicleDeleters) do
                TriggerEvent('gridsystem:registerMarker', {
                    name = 'police_deleters_' .. tostring(stationNum) .. '_' .. tostring(k),
                    pos = v,
                    scale = vector3(3.0, 3.0, 3.0),
                    msg = 'Tryk <b>[E]</b> for at fjerne køretøj',
                    control = 'E',
                    show3D = false,
                    showHTML = true,
                    type = 27,
                    color = {r = 50, g = 50, b = 204},
                    forceExit = true,
                    permission = 'police',
                    action = function()
                        functionHandler('deleteVehicle', {station = stationNum, isServiceRequired = true, serviceByPass = {"prison_elev", "prison_officer", "prison_director"}}, '')
                    end,
                    onExit = function()
                        ESX.UI.Menu.CloseAll()
                    end
                })
                Citizen.Wait(100)
            end
        end
    end
end