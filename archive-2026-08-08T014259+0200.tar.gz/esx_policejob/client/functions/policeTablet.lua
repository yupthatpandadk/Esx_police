local targetPlayers = {}

RegisterCommand("policetablet", function()
    functionHandler("police_tablet", {
        rangBlacklist = {
            "prison_elev", 
            "prison_officer", 
            "prison_director"
        }, 
        polyRequired = true
    })
end)

OpenPoliceTablet = function(apps)
    while not hasInited do
        Wait(0)
    end

    if not next(apps) then
        return
    end
    
    SetNuiFocus(true, true)

    SendNUIMessage({
        openTablet = true,
    })

    SendNUIMessage({
        refreshApps = true,
        availableApps = apps,
    })

    if not isTableEmpty(targetPlayers) then
        local hasOpened = false
        if tablelength(targetPlayers) == 1 and targetPlayers[1]["vehicles"] ~= nil and targetPlayers[1]["houses"] ~= nil then
            SendNUIMessage({
                receiveUser = true,
                Users = targetPlayers,
            })

            hasOpened = true
        end

        if not hasOpened then
            SendNUIMessage({
                receiveUsers = true,
                Users = targetPlayers,
            })
        end
    end
end

exports("OpenCustomTablet", OpenPoliceTablet)

RegisterNetEvent("esx_policejob:refreshPrisoners")
AddEventHandler("esx_policejob:refreshPrisoners", function(prisoners)
    while not hasInited do
        Wait(0)
    end

    SendNUIMessage({
        recievePrisoners = true,
        Prisoners = prisoners,
    })
end)

RegisterNetEvent("esx_policejob:refreshUsers")
AddEventHandler("esx_policejob:refreshUsers", function(players)
    while not hasInited do
        Wait(0)
    end

    targetPlayers = players

    SendNUIMessage({
        receiveUsers = true,
        Users = players,
    })
end)

RegisterNetEvent("esx_policejob:selectUser")
AddEventHandler("esx_policejob:selectUser", function(user, vehicles, houses, billings)
    while not hasInited do
        Wait(0)
    end

    local job_name = ESX.PlayerData.job.name
    if job_name == "exclusive" then
        houses = {}

        for k,v in pairs(billings) do
            if v.accountName ~= job_name then
                billings[k] = nil
            end
        end

        for k,v in pairs(vehicles) do
            if v.type ~= "lease" then
                table.remove(vehicles, k)
            end
        end
    end

    if job_name == "realestateagent" then
        vehicles = {}

        for k,v in pairs(billings) do
            if v.accountName ~= job_name then
                billings[k] = nil
            end
        end
    end

    for k,v in pairs(vehicles) do
        v.garageid = v.garage
        
        local garage = Config.VehicleGarageLabels[v.garage]
        local model = GetDisplayNameFromVehicleModel(v.model)

        v.garage = "Parkeret " .. garage
        v.model = GetLabelText(model)
    end

    for k,v in pairs(houses) do
        local streetName,_ = GetStreetNameAtCoord(v.entry.x, v.entry.y, v.entry.z)
        v.street = GetStreetNameFromHashKey(streetName)
    end

    table.sort(billings, function(a,b) return a.account < b.account end)
    table.sort(vehicles, function(a,b) return a.garage < b.garage end)
    table.sort(houses, function(a,b) return a.street < b.street end)

    local players = {}
    table.insert(players, {
        firstname = user.firstname,
        lastname = user.lastname,
        number = user.number,
        dob = user.dob,
        billings = billings,
        vehicles = vehicles,
        houses = houses,
    })

    SendNUIMessage({
        receiveUser = true,
        Users = players,
    })

    targetPlayers = players
end)

RegisterNUICallback('SearchUser', function(data, cb)
    local firstname = data["firstname"]
    local lastname = data["lastname"]

    TriggerServerEvent("esx_policejob:searchUsers", firstname, lastname)

    cb('ok')
end)

RegisterNUICallback('SelectUser', function(data, cb)
    local user = data["user"]

    TriggerServerEvent("esx_policejob:selectUser", user)

    cb('ok')
end)

RegisterNUICallback('AddVehicleGPS', function(data, cb)
    local plate = data["plate"]
    
    for k,v in pairs(targetPlayers[1]["vehicles"]) do
        if v.plate == plate then
            if DoesBlipExist(v.blip) then
                RemoveBlip(v.blip)
            end

            v.hasGPS = true
            local garageCoords = GetGarageCoordsFromID(v.type, v.garageid)
            v.blip = CreateTabletBlip(garageCoords, 326, 1, "Markeret Garage")
        end
    end

    SendNUIMessage({
        receiveUser = true,
        Users = targetPlayers,
    })

    cb('ok')
end)

RegisterNUICallback('RemoveVehicleGPS', function(data, cb)
    local plate = data["plate"]

    for k,v in pairs(targetPlayers[1]["vehicles"]) do
        if v.plate == plate then
            if DoesBlipExist(v.blip) then
                RemoveBlip(v.blip)
            end

            v.hasGPS = false
        end
    end

    SendNUIMessage({
        receiveUser = true,
        Users = targetPlayers,
    })

    cb('ok')
end)

RegisterNUICallback('AddHouseGPS', function(data, cb)
    local houseid = data["houseid"]

    for k,v in pairs(targetPlayers[1]["houses"]) do
        if v.houseid == houseid then
            if DoesBlipExist(v.blip) then
                RemoveBlip(v.blip)
            end

            v.hasGPS = true
            v.blip = CreateTabletBlip(v.entry, 40, 1, "Markeret Hus")
        end
    end

    SendNUIMessage({
        receiveUser = true,
        Users = targetPlayers,
    })

    cb('ok')
end)

RegisterNUICallback('RemoveHouseGPS', function(data, cb)
    local houseid = data["houseid"]

    for k,v in pairs(targetPlayers[1]["houses"]) do
        if v.houseid == houseid then
            if DoesBlipExist(v.blip) then
                RemoveBlip(v.blip)
            end

            v.hasGPS = false
        end
    end

    SendNUIMessage({
        receiveUser = true,
        Users = targetPlayers,
    })

    cb('ok')
end)

RegisterNUICallback('openPrison', function(data, cb)
    TriggerServerEvent("esx_policejob:updatePrison")

    cb('ok')
end)

RegisterNUICallback('openLeasing', function(data, cb)
    ESX.TriggerServerCallback('ESX_LEASING:getLeasedVehicles', function(Vehicles)
        local vehicleData = {}
        for k,v in pairs(Vehicles) do
            local data = {
                id = v.id,
                seller = v.owner,
                plate = v.plate,
                model = firstToUpper(v.model),
                rate = v.withdrawingformat,
                startdate = v.renteddateformat,
                enddate = v.expiredateformat,
            }

            table.insert(vehicleData, data)
        end

        SendNUIMessage({
            recieveLeasingData = true,
            LeasingVehicles = vehicleData,
        })
    end)

    cb('ok')
end)

RegisterNUICallback('WithDrawLeasing', function(data, cb)
    local plate = data["vehicle"]["plate"]

    SendNUIMessage({
        startLoader = true,
    })

    ESX.TriggerServerCallback('ESX_LEASING:returnVehicle', function(canReturn)
        ESX.TriggerServerCallback('ESX_LEASING:getLeasedVehicles', function(Vehicles)
            local vehicleData = {}
            for k,v in pairs(Vehicles) do
                local data = {
                    id = v.id,
                    seller = v.seller,
                    plate = v.plate,
                    model = firstToUpper(v.model),
                    rate = v.withdrawingformat,
                    startdate = v.renteddateformat,
                    enddate = v.expiredateformat,
                }
    
                table.insert(vehicleData, data)
            end
    
            SendNUIMessage({
                recieveLeasingData = true,
                LeasingVehicles = vehicleData,
            })
        end)
    end, plate)

    cb('ok')
end)

RegisterNUICallback('ExtendLeasing', function(data, cb)
    local plate = data["vehicle"]["plate"]
    local amount = data["amount"]

    SendNUIMessage({
        startLoader = true,
    })

    TriggerServerEvent('ESX_LEASING:extendedLeasing', plate, amount)

    Wait(1000)

    ESX.TriggerServerCallback('ESX_LEASING:getLeasedVehicles', function(Vehicles)
        local vehicleData = {}
        for k,v in pairs(Vehicles) do
            local data = {
                id = v.id,
                seller = v.seller,
                plate = v.plate,
                model = firstToUpper(v.model),
                rate = v.withdrawingformat,
                startdate = v.renteddateformat,
                enddate = v.expiredateformat,
            }

            table.insert(vehicleData, data)
        end

        SendNUIMessage({
            recieveLeasingData = true,
            LeasingVehicles = vehicleData,
        })
    end)

    cb('ok')
end)

GetGarageCoordsFromID = function(type, GarageId)
    if type == "car" or type == "lease" then
        for k,v in pairs(Config.CarGarages) do
            if v.GarageId == GarageId then
                return vector3(v.GaragePoint.x, v.GaragePoint.y, v.GaragePoint.z)
            end
        end
    end

    if type == "boat" then
        for k,v in pairs(Config.BoatGarages) do
            if v.GarageId == GarageId then
                return vector3(v.GaragePoint.x, v.GaragePoint.y, v.GaragePoint.z)
            end
        end
    end

    return nil
end

CreateTabletBlip = function(pos, sprite, color, text)
    local blip = AddBlipForCoord(pos.x,pos.y,pos.z)
    SetBlipSprite(blip, sprite)
    SetBlipColour(blip, color)
    SetBlipScale(blip, 1.0)

    SetBlipDisplay(blip, 3)
    SetBlipAsShortRange(blip, false)
    SetBlipHighDetail(blip, true)

    BeginTextCommandSetBlipName ("STRING")
    AddTextComponentString(text)
    EndTextCommandSetBlipName(blip)
    return blip
end

tablelength = function(T)
    local count = 0
    for _ in pairs(T) do count = count + 1 end
    return count
end
