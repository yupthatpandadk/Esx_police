exports.qtarget:Vehicle({
	options = {
		{
			icon = "far fa-flux-capacitor",
			label = "Køretøjsinformationer",
            job = 'police',
            action = function(entity)
                if DoesEntityExist(entity) then
                    local vehicleData = ESX.Game.GetVehicleProperties(entity)
                    GetVehicleInfos(vehicleData.plate)
                end
			end,
            canInteract = function()
                local data = {
                    rangBlacklist = {"prison_elev", "prison_officer", "prison_director"}, 
                }

                return CheckActionCredentials(data)
            end,
		}, {
			icon = "fas fa-lock-open-alt",
			label = "Lås køretøj op",
            job = 'police',
            action = function(entity)
                HighJackVehicle(entity)
			end,
            canInteract = function()
                local data = {
                    rangBlacklist = {"prison_elev", "prison_officer", "prison_director"}, 
                }

                return CheckActionCredentials(data)
            end,
		},
	},
	distance = 2
})

exports.qtarget:Player({
	options = {
		{
			icon = "fas fa-id-card",
			label = "ID Kort",
            job = 'police',
            num = 1,
            action = function(entity)
                OpenIdentityCardMenu(NetworkGetPlayerIndexFromPed(entity))
			end,
            canInteract = function()
                local data = {
					serviceByPass = {"statsadvokat"},
                    rangBlacklist = {"prison_elev", "prison_officer", "prison_director"},  
                    isServiceRequired = true, 
                }

                return CheckActionCredentials(data)
            end,
		}, {
			icon = "fad fa-siren",
			label = "Visiter",
            job = 'police',
            num = 2,
            action = function(entity)
                OpenBodySearchMenu(NetworkGetPlayerIndexFromPed(entity))
			end,
            canInteract = function()
                local data = {
                    serviceByPass = {"prison_elev", "prison_officer", "prison_director"}, 
                    rangPolyRequired = {"prison_elev", "prison_officer", "prison_director"}, 
                    isServiceRequired = true, 
                }

                return CheckActionCredentials(data)
            end,
		}, {
			icon = "fas fa-skull-crossbones",
			label = "Sæt i fængsel",
            job = 'police',
            num = 3,
            action = function(entity)
                JailPlayer(NetworkGetPlayerIndexFromPed(entity))
			end,
            canInteract = function()
                local data = {
                    serviceByPass = {"prison_elev", "prison_officer", "prison_director", "statsadvokat"}, 
                    rangPolyRequired = {"prison_elev", "prison_officer", "prison_director"}, 
                    isServiceRequired = true, 
                }

                return CheckActionCredentials(data)
            end,
		}, {
			icon = "fa-solid fa-file-invoice",
			label = "Giv en bøde",
            job = 'police',
            num = 4,
            action = function(entity)
                SendFine(NetworkGetPlayerIndexFromPed(entity))
			end,
            canInteract = function()
                local data = {
					serviceByPass = {"statsadvokat"},
                    rangBlacklist = {"prison_elev", "prison_officer", "prison_director"}, 
                    isServiceRequired = true, 
                }

                return CheckActionCredentials(data)
            end,
		}, {
			icon = "fas fa-clipboard-list",
			label = "Tjek Ubetalte bøder",
            job = 'police',
            num = 5,
            action = function(entity)
                CheckUnpaidBills(NetworkGetPlayerIndexFromPed(entity))
			end,
            canInteract = function()
                local data = {
					serviceByPass = {"statsadvokat"},
                    rangBlacklist = {"prison_elev", "prison_officer", "prison_director"}, 
                    isServiceRequired = true, 
                }

                return CheckActionCredentials(data)
            end,
		}, {
			icon = "fab fa-angellist",
			label = "Tag GSR Test",
            job = 'police',
            num = 6,
            action = function(entity)
                    TriggerServerEvent("esx_gsr:Check", GetPlayerServerId(NetworkGetPlayerIndexFromPed(entity)))
			end,
            canInteract = function()
                local data = {
                    rangBlacklist = {"prison_elev", "prison_officer", "prison_director"}, 
                    isServiceRequired = true, 
                }

                return CheckActionCredentials(data)
            end,
		},
	},
	distance = 2
})

CheckActionCredentials = function(data)
    if isTableEmpty(data) then
        return true
    end

    local gradeName = ESX.PlayerData.job.grade_name
    if data["rangBlacklist"] then
        for k, rang in pairs(data["rangBlacklist"]) do
            if string.find(gradeName, rang) then
                return false
            end
        end
    end

    local hasByPass = false
    if data["serviceByPass"] then
        for i=1, #data["serviceByPass"], 1 do
            local rang = data["serviceByPass"][i]
            if string.find(gradeName, rang) then
                hasByPass = true
            end
        end
    end

    if data["isServiceRequired"] and not isPlayerInService then
        if not hasByPass then
            return false
        end
    end

    if data["rangPolyRequired"] then
        local isPolyZone = false
        for k, rang in pairs(data["rangPolyRequired"]) do
            if string.find(gradeName, rang) then
                isPolyZone = true
            end
        end

        if isPolyZone and EnteredStation == nil then
            return false
        end
    end

    return true
end

RegisterNetEvent("esx_policejob:drag")
AddEventHandler("esx_policejob:drag", function(copID)
    if not IsHandcuffed then
        return
    end

    isDragged = not isDragged
    draggedBy = tonumber(copID)

    StartDragged()
end)

RegisterNetEvent('esx_policejob:panicButtonGps')
AddEventHandler('esx_policejob:panicButtonGps', function(x, y, z, officer, streetName, paniceSenderId)
    if hasPoliceJob then
        local text = "[" .. paniceSenderId .. "] " .. officer
        TriggerServerEvent('esx_outlawalert:panicButton', streetName, text)

        if paniceSenderId == GetPlayerServerId(PlayerId()) then
            TriggerServerEvent('InteractSound_CL:PlayOnOne', 'panicButton', 0.5)
        end

        SetNewWaypoint(x, y)
    end
end)

RegisterNetEvent("esx_policejob:putInVehicle")
AddEventHandler("esx_policejob:putInVehicle", function()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    if IsAnyVehicleNearPoint(playerCoords, 2.5) then
        local vehicle = GetClosestVehicle(playerCoords, 2.5, 0, 71)

        if vehicle == 0 then
            vehicle = VehicleInFront()
        end
        
        if DoesEntityExist(vehicle) then
            local maxSeats, freeSeat = GetVehicleMaxNumberOfPassengers(vehicle)
            for i = maxSeats - 1, 0, -1 do
                if IsVehicleSeatFree(vehicle, i) then
                    freeSeat = i
                    break
                end
            end
            
            if freeSeat then
                TaskWarpPedIntoVehicle(playerPed, vehicle, freeSeat)
                isDragged = false
            end
        end
    end
end)

RegisterNetEvent("esx_policejob:OutVehicle")
AddEventHandler("esx_policejob:OutVehicle", function()
    local playerPed = PlayerPedId()
        
    if not IsPedSittingInAnyVehicle(playerPed) then
        return
    end
    
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    TaskLeaveVehicle(playerPed, vehicle, 16)
end)

RegisterNetEvent("esx_policejob:handcuff")
AddEventHandler("esx_policejob:handcuff", function(target, command)
    local playerPed = PlayerPedId()

    local targetPed = GetPlayerPed(GetPlayerFromServerId(target))
    local isInHandCuff = IsEntityPlayingAnim(playerPed, "mp_arresting", "idle", 3)

    if not isInHandCuff then
        if command == "handcuff_soft" then
            local dict, anim = "mp_arresting", "a_uncuff"

            LoadAnim(dict)

            TaskPlayAnim(playerPed, dict, anim, 8.0, -8, 3000, 2, 0, 0, 0, 0)
            Citizen.Wait(3000)
        end

        if command == "handcuff_hard" then
            local dict, anim = "mp_arrest_paired", "cop_p2_back_left"

            LoadAnim(dict)

            TaskPlayAnim(playerPed, dict, anim, 8.0, -8.0, 5500, 33, 0, false, false, false)
            Citizen.Wait(3000)
        end
    end

    if isInHandCuff then
        local dict, anim = "mp_arresting", "a_uncuff"

        LoadAnim(dict)

        TaskPlayAnim(playerPed, dict, anim, 8.0, -8, 8000, 2, 0, 0, 0, 0)
        Citizen.Wait(8000)
    end
end)

RegisterNetEvent("esx_policejob:getHandcuffed")
AddEventHandler("esx_policejob:getHandcuffed", function(target, command)
    local playerPed = PlayerPedId()
    
    if not IsHandcuffed then
        if command == "handcuff_soft" then
            local dict, anim = "mp_arresting", "b_uncuff"

            LoadAnim(dict)

            TaskPlayAnim(playerPed, dict, anim, 8.0, -8, 3000, 2, 0, 0, 0, 0)
            TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 5.0, 'handcuffs', 0.2)

            Citizen.Wait(3000)
        end

        if command == "handcuff_hard" then
            local dict, anim = "mp_arrest_paired", "crook_p2_back_left"
            local targetPed = GetPlayerPed(GetPlayerFromServerId(target))

            LoadAnim(dict)

            AttachEntityToEntity(playerPed, targetPed, 11816, -0.1, 0.45, 0.0, 0.0, 0.0, 20.0, false, false, false, false, 20, false)
            TaskPlayAnim(playerPed, dict, anim, 8.0, -8.0, 5500, 33, 0, false, false, false)

            TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 5.0, 'handcuffs', 0.2)
        
            Citizen.Wait(950)
            DetachEntity(playerPed, true, false)
            Citizen.Wait(2000)
        end

        EnableHandCuff()
		exports['gcphone']:SetCuffStatus(true)
		
        return
    end

    if IsHandcuffed then
        DisableHandCuff()

        local dict, anim = "mp_arresting", "b_uncuff"
        LoadAnim(dict)

        TaskPlayAnim(playerPed, dict, anim, 8.0, -8, 8000, 2, 0, 0, 0, 0)
        TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 5.0, 'handcuffsoff', 0.2)
		exports['gcphone']:SetCuffStatus(false)

        Citizen.Wait(8000)
    end
end)

EnableHandCuff = function()
    local playerPed = PlayerPedId()

    DisplayRadar(false)

    SetEnableHandcuffs(playerPed, true)
    DisablePlayerFiring(playerPed, true)
    SetCurrentPedWeapon(playerPed, `WEAPON_UNARMED`, true)
    SetPedCanPlayGestureAnims(playerPed, false)

    IsHandcuffed = true
    StartHandcuffLoop()
end

DisableHandCuff = function()
    isDragged = false
    IsHandcuffed = false
    
    Citizen.Wait(100)

    local playerPed = PlayerPedId()
    DisplayRadar(true)

    ClearPedSecondaryTask(playerPed)
    SetEnableHandcuffs(playerPed, false)
    DisablePlayerFiring(playerPed, false)
    SetPedCanPlayGestureAnims(playerPed, true)
    DetachEntity(playerPed, true, false)
end

RegisterNetEvent("esx_policejob:unrestrain")
AddEventHandler("esx_policejob:unrestrain", function()
    if not IsHandcuffed then
        return
    end

    DisableHandCuff()
end)
