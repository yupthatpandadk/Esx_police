RunHelmetArmor = function()
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(5000)

            local playerPed = PlayerPedId()
            if not hasPoliceJob then
                local flag = GetPedConfigFlag(playerPed, 438, 0)
                if not flag then
                    SetPedConfigFlag(playerPed, 438, true)
                end
            end

            if hasPoliceJob then
                local flag = GetPedConfigFlag(playerPed, 438, 0)
                if flag then
                    SetPedConfigFlag(playerPed, 438, false)
                end
            end
        end
    end)
end

local nearestObject = nil
StartObjectFinder = function()
    if not lookforObjects then
        return
    end

    local Objects = {}
    for k,v in pairs(Config.PoliceMenu) do
        if v.action == "object_spawner" then
            for i=1, #v.menu, 1 do
                local object = v.menu[i]

                if object.data ~= nil then
                    if object.data.object ~= nil then
                        table.insert(Objects, GetHashKey(object.data.object))
                    end
                end
            end
        end
    end

    Citizen.CreateThread(function()
        while lookforObjects do
            Citizen.Wait(0)

            local letSleep = true
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)

            for k, object in pairs(Objects) do
                local obj = GetClosestObjectOfType(playerCoords, 3.0, object, false, false, false)

                if DoesEntityExist(obj) then
                    local objectCoords = GetEntityCoords(obj)
                    local objDistance = #(playerCoords - objectCoords)

                    if objDistance <= 2.0 then
                        nearestObject = object

                        if not hasHelpText then
                            TriggerEvent('cd_drawtextui:ShowUI', 'show', "Tryk [E] for slette genstand")
                            hasHelpText = true
                        end

                        if IsControlJustReleased(0, Keys['E']) and (GetGameTimer() - Time) > 1000 then
                            Time = GetGameTimer()
                            
                            DeleteLocalObject(obj)
        
                            hasHelpText = false
                            TriggerEvent('cd_drawtextui:HideUI')
        
                            Citizen.Wait(5000)
                        end
        
                        letSleep = false
                    end

                    if objDistance > 2.0 and hasHelpText and nearestObject == object then
                        TriggerEvent('cd_drawtextui:HideUI')
                        hasHelpText = false
                    end
                end
            end

            if letSleep then
                Citizen.Wait(500)
            end
        end
    end)
end

StartHandcuffLoop = function()
    Citizen.CreateThread(function()
        while IsHandcuffed do
            Citizen.Wait(1)

            local playerPed = PlayerPedId()
            DisableControlAction(0, 24, true) -- Attack
            DisableControlAction(0, 257, true) -- Attack 2
            DisableControlAction(0, 25, true) -- Aim
            DisableControlAction(0, 263, true) -- Melee Attack 1
            DisableControlAction(0, Keys["LEFTSHIFT"], true)-- Reload
            
            DisableControlAction(0, Keys["R"], true)-- Reload
            DisableControlAction(0, Keys["SPACE"], true)-- Jump
            DisableControlAction(0, Keys["Q"], true)-- Cover
            DisableControlAction(0, Keys["TAB"], true)-- Select Weapon
            DisableControlAction(0, Keys["F"], true)-- Also 'enter'?
            
            DisableControlAction(0, Keys["F1"], true)-- Disable phone
            DisableControlAction(0, Keys["F2"], true)-- Inventory
            DisableControlAction(0, Keys["F3"], true)-- Animations
            DisableControlAction(0, Keys["F6"], true)-- Job
            
            DisableControlAction(0, Keys["C"], true)-- Disable looking behind
            DisableControlAction(0, Keys["X"], true)-- Disable clearing animation
            DisableControlAction(2, Keys["P"], true)-- Disable pause screen
            
            DisableControlAction(0, 59, true)-- Disable steering in vehicle
            DisableControlAction(0, 71, true)-- Disable driving forward in vehicle
            DisableControlAction(0, 72, true)-- Disable reversing in vehicle
            
            DisableControlAction(2, Keys["LEFTCTRL"], true)-- Disable going stealth
            
            DisableControlAction(0, 47, true)-- Disable weapon
            DisableControlAction(0, 264, true)-- Disable melee
            DisableControlAction(0, 257, true)-- Disable melee
            DisableControlAction(0, 140, true)-- Disable melee
            DisableControlAction(0, 141, true)-- Disable melee
            DisableControlAction(0, 142, true)-- Disable melee
            DisableControlAction(0, 143, true)-- Disable melee
            DisableControlAction(0, 75, true)-- Disable exit vehicle
            DisableControlAction(27, 75, true)-- Disable exit vehicle
            
            local dict, anim = "mp_arresting", "idle"
            if not IsEntityPlayingAnim(playerPed, dict, anim, 3) then
                LoadAnim(dict)

                TaskPlayAnim(playerPed, dict, anim, 8.0, -8, -1, 49, 0.0, false, false, false)
                RemoveAnimDict(dict)
            end
        end
    end)
end

StartDragged = function()
    Citizen.CreateThread(function()
        while IsHandcuffed do
            Citizen.Wait(1)

            local playerPed = PlayerPedId()
            local targetPed = GetPlayerPed(GetPlayerFromServerId(draggedBy))

            if isDragged then
                if not IsPedSittingInAnyVehicle(targetPed) then
                    AttachEntityToEntity(playerPed, targetPed, 11816, 0.54, 0.54, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
                end

                if IsPedSittingInAnyVehicle(targetPed) then
                    DetachEntity(playerPed, true, false)
                    isDragged = false
                end
            end

            if not isDragged then
                DetachEntity(playerPed, true, false)
                isDragged = false
            end
        end
    end)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        local letSleep = true
        local playerPed = PlayerPedId()

        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)

            if not IsVehicleTyreBurst(vehicle, 0, false) then
                local vehCoord = GetEntityCoords(vehicle)
                local spikes = GetClosestObjectOfType(vehCoord, 20.0, GetHashKey("P_ld_stinger_s"), false, false, false)

                if DoesEntityExist(spikes) then
                    local spikePos = GetEntityCoords(spikes, false)
                    local distance = #(vehCoord - spikePos)

                    if distance <= 2.0 then
                        SetVehicleTyreBurst(vehicle, 0, true, 1000.0)
                        SetVehicleTyreBurst(vehicle, 1, true, 1000.0)
                        SetVehicleTyreBurst(vehicle, 2, true, 1000.0)
                        SetVehicleTyreBurst(vehicle, 3, true, 1000.0)
                        SetVehicleTyreBurst(vehicle, 4, true, 1000.0)
                        SetVehicleTyreBurst(vehicle, 5, true, 1000.0)
                        SetVehicleTyreBurst(vehicle, 6, true, 1000.0)
                        SetVehicleTyreBurst(vehicle, 7, true, 1000.0)
                    end

                    letSleep = false
                end
            end
        end

        if letSleep then
            Citizen.Wait(500)
        end
    end
end)
