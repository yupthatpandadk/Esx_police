isTackling = false

RegisterKeyMapping('+tacklePlayer', 'Tackle en spiller', 'keyboard', 'E')
RegisterCommand('+tacklePlayer', function()
    local playerPed = PlayerPedId()
    if IsPedJumping(playerPed) and hasPoliceJob then
        TackePlayer()
    end

end, false)

RegisterCommand('-tacklePlayer', function()
    -- Do nothing, to avoid spam in chat.
end)

TackePlayer = function()
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed) then
        return
    end

    local Tackled = {}

    local ForwardVector = GetEntityForwardVector(playerPed)
    SetPedToRagdollWithFall(playerPed, 1000, 1500, 1, ForwardVector, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

    isTackling = true

    while IsPedRagdoll(playerPed) do
        Citizen.Wait(0)
        for Key, Value in ipairs(GetTouchedPlayers()) do
            if not Tackled[Value] then
                Tackled[Value] = true

                TriggerServerEvent('esx_police:TacklePlayer', GetPlayerServerId(Value), ForwardVector.x, ForwardVector.y, ForwardVector.z, GetPlayerName(PlayerId()))
            end
        end
    end

    isTackling = false
end

RegisterNetEvent('esx_police:TacklePlayer')
AddEventHandler('esx_police:TacklePlayer', function(ForwardVectorX, ForwardVectorY, ForwardVectorZ, Tackler)
	SetPedToRagdollWithFall(PlayerPedId(), 3000, 4000, 1, ForwardVectorX, ForwardVectorY, ForwardVectorZ, 10.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
end)

GetTouchedPlayers = function()
    local playerPed = PlayerPedId()
    local playersNearby = ESX.Game.GetPlayersInArea(GetEntityCoords(playerPed), 5.0)

    local TouchedPlayer = {}
    for Key, Value in ipairs(playersNearby) do
		if IsEntityTouchingEntity(playerPed, GetPlayerPed(Value)) then
			table.insert(TouchedPlayer, Value)
		end
    end

    return TouchedPlayer
end
