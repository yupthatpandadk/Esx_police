local isInVehicle = false
local menuEnabled = false
local IsSpeedRecording = false

local FrontFreeze = false
local FrontActive = false
local RearFreeze = false
local RearActive = false

local lastFrontPlate = ''
local lastRearPlate = ''

local lastSpeed = 0
local speeds = {}
local wantedVehicles = {}

RegisterNetEvent("esx_policejob:collectWantedPlates")
AddEventHandler("esx_policejob:collectWantedPlates", function(vehicles)
    if not hasPoliceJob then
        return
    end

    wantedVehicles = vehicles
end)

RegisterCommand("getwantedplates", function()
    if not hasPoliceJob then
        return
    end
    
    print_r(wantedVehicles)
end)

ValidateVehicle = function(playerPed, vehicle)
    local hasFoundVehicle = false

    if (GetPedInVehicleSeat(vehicle, -1) == playerPed or GetPedInVehicleSeat(vehicle, 0) == playerPed) and GetVehicleClass(vehicle) == 18 then
        local model = GetEntityModel(vehicle)
        for i=1, #Config.RadarVehicles, 1 do
            local vehicle = Config.RadarVehicles[i]
            if model == GetHashKey(vehicle) then
                hasFoundVehicle = true
            end
        end
    end

    return hasFoundVehicle
end

AddEventHandler("drp:EnteredVehicle", function()
    isInVehicle = true

    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)

        if ValidateVehicle(playerPed, vehicle) then
            SendNUIMessage({
                openScanner = true,
            })

            menuEnabled = true
            StartRadarMenu()

            local netID = NetworkGetNetworkIdFromEntity(vehicle)
            local ent = Entity(NetToVeh(netID))

            FrontFreeze = ent.state.frontfreeze
            FrontActive = ent.state.frontactive

            RearFreeze = ent.state.rearfreeze
            RearActive = ent.state.rearactive

            local AverageSpeed = ent.state.averagespeed

            SendNUIMessage({
                setFrontFreezeStatus = true,
                status = FrontFreeze,
            })

            SendNUIMessage({
                setFrontStatus = true,
                status = FrontActive,
            })

            SendNUIMessage({
                setRearFreezeStatus = true,
                status = RearFreeze,
            })

            SendNUIMessage({
                setRearStatus = true,
                status = RearActive,
            })

            SendNUIMessage({
                setAverageSpeed = true,
                averageSpeed = AverageSpeed,
            })

            speeds = {}
            lastSpeed = 0
        end
    end
end)

AddEventHandler("drp:LeavedVehicle", function()
    isInVehicle = false

    if menuEnabled then
        SendNUIMessage({
            closeScanner = true,
        })

        menuEnabled = false
    end

    speeds = {}
    lastSpeed = 0
end)

RegisterKeyMapping('+radarFocus', 'Integrere med Radaren', 'keyboard', 'G')
RegisterCommand('+radarFocus', function()
    if not menuEnabled then
        return
    end

    SetNuiFocus(true, true)
end, false)

RegisterCommand('-radarFocus', function()
    -- Do nothing, to avoid spam in chat.
end)

RegisterKeyMapping('+speedTrap', 'Start/Stop Fartmåling', 'keyboard', 'B')
RegisterCommand('+speedTrap', function()
    if not menuEnabled then
        return
    end

    IsSpeedRecording = not IsSpeedRecording

    if IsSpeedRecording then
        speeds = {}
        lastSpeed = 0
    end

    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    local netID = NetworkGetNetworkIdFromEntity(vehicle)

    if not IsSpeedRecording then
        local totalSpeed = 0
        for i=1, #speeds, 1 do
            totalSpeed = totalSpeed + speeds[i]
        end
        
        local AverageSpeed = round(totalSpeed / #speeds)

        SendNUIMessage({
            setAverageSpeed = true,
            averageSpeed = AverageSpeed,
        })

        TriggerServerEvent("esx_policejob:setRadarStatus", netID, 'averagespeed', AverageSpeed)

        speeds = {}
        lastSpeed = 0
    end

    SendNUIMessage({
        ToggleRecording = true,
        isRecording = IsSpeedRecording,
    })

    TriggerServerEvent("esx_policejob:setRadarStatus", netID, 'speedrecording', IsSpeedRecording)
end, false)

RegisterCommand('-speedTrap', function()
    -- Do nothing, to avoid spam in chat.
end)

StartRadarMenu = function()
    Citizen.CreateThread(function()
        while isInVehicle do
            Citizen.Wait(50)
            
            local playerPed = PlayerPedId()
            if IsPedInAnyVehicle(playerPed, false) then
                local vehicle = GetVehiclePedIsIn(playerPed, false)

                local currSpeed = GetEntitySpeed(vehicle)
                local speed = ("%.0f"):format(math.ceil(currSpeed * 3.6))

                if IsSpeedRecording then
                    if (GetGameTimer() - lastSpeed) > 1000 then
                        lastSpeed = GetGameTimer()

                        table.insert(speeds, speed)
                    end
                end

                local vehiclePos = GetEntityCoords(vehicle, true)
                local heading = round(GetEntityHeading(vehicle), 0)

                if not FrontFreeze and FrontActive then 
                    local forwardPosition = GetOffsetFromEntityInWorldCoords(vehicle, 0.0, 50.0, 0.0)
                    local fwdPos = { x = forwardPosition.x, y = forwardPosition.y, z = forwardPosition.z }
                    local _, fwdZ = GetGroundZFor_3dCoord(fwdPos.x, fwdPos.y, fwdPos.z + 500.0)

                    if (fwdPos.z < fwdZ and not (fwdZ > vehiclePos.z + 1.0)) then 
                        fwdPos.z = fwdZ + 0.5
                    end 

                    local packedFwdPos = vector3(fwdPos.x, fwdPos.y, fwdPos.z)
                    local fwdVeh = GetVehicleInDirectionSphere(vehicle, vehiclePos, packedFwdPos)

                    if (DoesEntityExist(fwdVeh) and IsEntityAVehicle(fwdVeh)) then
                        local fwdPlate = ESX.Math.Trim(GetVehicleNumberPlateText(fwdVeh))
                        if lastFrontPlate ~= fwdPlate then
                            lastFrontPlate = fwdPlate

                            if wantedVehicles[fwdPlate] then
                                PlaySoundFrontend(-1, "Beep_Red", "DLC_HEIST_HACKING_SNAKE_SOUNDS", 1)
                                ESX.ShowNotification(("Køretøjet ~y~%s~s~ er efterlyst."):format(fwdPlate))
                            end
                        end
                    end
                end

                if not RearFreeze and RearActive then 
                    local backwardPosition = GetOffsetFromEntityInWorldCoords(vehicle, -10.0, -50.0, 0.0)
                    local bwdPos = { x = backwardPosition.x, y = backwardPosition.y, z = backwardPosition.z }
                    local _, bwdZ = GetGroundZFor_3dCoord( bwdPos.x, bwdPos.y, bwdPos.z + 500.0)              

                    if (bwdPos.z < bwdZ and not (bwdZ > vehiclePos.z + 1.0)) then 
                        bwdPos.z = bwdZ + 0.5
                    end

                    local packedBwdPos = vector3(bwdPos.x, bwdPos.y, bwdPos.z)                
                    local bwdVeh = GetVehicleInDirectionSphere(vehicle, vehiclePos, packedBwdPos)

                    if (DoesEntityExist(bwdVeh) and IsEntityAVehicle(bwdVeh)) then
                        local bwdPlate = ESX.Math.Trim(GetVehicleNumberPlateText(bwdVeh))
                        if lastRearPlate ~= bwdPlate then
                            lastRearPlate = bwdPlate

                            if wantedVehicles[bwdPlate] then
                                PlaySoundFrontend(-1, "Beep_Red", "DLC_HEIST_HACKING_SNAKE_SOUNDS", 1)
                                ESX.ShowNotification(("Køretøjet ~y~%s~s~ er efterlyst."):format(bwdPlate))
                            end
                        end
                    end
                end

                SendNUIMessage({
                    setPatrolSpeed = true,
                    patrolSpeed = speed,
                    setFrontPlate = lastFrontPlate ~= fwdPlate,
                    frontPlate = lastFrontPlate,
                    setRearPlate = lastRearPlate ~= bwdPlate,
                    rearPlate = lastRearPlate,
                })
            end
        end
    end)
end

GetVehicleInDirectionSphere = function(entFrom, coordFrom, coordTo)
    local rayHandle = StartShapeTestCapsule( coordFrom.x, coordFrom.y, coordFrom.z, coordTo.x, coordTo.y, coordTo.z, 3.0, 10, entFrom, 7 )
    local _, _, _, _, vehicle = GetShapeTestResult( rayHandle )
    return vehicle
end

round = function(num)
    return tonumber(string.format("%.0f", num))
end

RegisterNUICallback('SetFrontFreeze', function(data, cb)
    FrontFreeze = data["frontFreeze"]

    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local netID = NetworkGetNetworkIdFromEntity(vehicle)
        
        TriggerServerEvent("esx_policejob:setRadarStatus", netID, 'frontfreeze', FrontFreeze)
    end

    cb('ok')
end)

RegisterNUICallback('SetFrontActive', function(data, cb)
    FrontActive = data["frontPlateActive"]

    SendNUIMessage({
        setFrontPlate = true,
        frontPlate = '',
    })

    lastFrontPlate = ''

    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local netID = NetworkGetNetworkIdFromEntity(vehicle)
        
        TriggerServerEvent("esx_policejob:setRadarStatus", netID, 'frontactive', FrontActive)
    end

    cb('ok')
end)

RegisterNUICallback('SetRearFreeze', function(data, cb)
    RearFreeze = data["rearFreeze"]

    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local netID = NetworkGetNetworkIdFromEntity(vehicle)

        TriggerServerEvent("esx_policejob:setRadarStatus", netID, 'rearfreeze', RearFreeze)
    end

    cb('ok')
end)

RegisterNUICallback('SetRearActive', function(data, cb)
    RearActive = data["rearPlateActive"]

    SendNUIMessage({
        setRearPlate = true,
        rearPlate = '',
    })

    lastRearPlate = ''

    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local netID = NetworkGetNetworkIdFromEntity(vehicle)

        TriggerServerEvent("esx_policejob:setRadarStatus", netID, 'rearactive', RearActive)
    end

    cb('ok')
end)

RegisterNUICallback('closeRadar', function(data, cb)
    SetNuiFocus(false)

    cb('ok')
end)

AddStateBagChangeHandler('frontfreeze', nil, function(bagName, key, value, _unused, replicated)
    local netID = bagName:gsub('entity:', '')
    local entNet = tonumber(netID)
    
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local localID = NetworkGetNetworkIdFromEntity(vehicle)

        if entNet == localID and ValidateVehicle(playerPed, vehicle) then
            SendNUIMessage({
                setFrontFreezeStatus = true,
                status = value,
            })

            FrontFreeze = value
            print("frontfreeze", value)
        end
    end
end)

AddStateBagChangeHandler('frontactive', nil, function(bagName, key, value, _unused, replicated)
    local netID = bagName:gsub('entity:', '')
    local entNet = tonumber(netID)
    
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local localID = NetworkGetNetworkIdFromEntity(vehicle)

        if entNet == localID and ValidateVehicle(playerPed, vehicle) then
            SendNUIMessage({
                setFrontStatus = true,
                status = value,
            })

            FrontActive = value
            print("frontactive", value)
        end
    end
end)

AddStateBagChangeHandler('rearfreeze', nil, function(bagName, key, value, _unused, replicated)
    local netID = bagName:gsub('entity:', '')
    local entNet = tonumber(netID)
    
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local localID = NetworkGetNetworkIdFromEntity(vehicle)

        if entNet == localID and ValidateVehicle(playerPed, vehicle) then
            SendNUIMessage({
                setRearFreezeStatus = true,
                status = value,
            })

            RearFreeze = value
            print("rearfreeze", value)
        end
    end
end)

AddStateBagChangeHandler('rearactive', nil, function(bagName, key, value, _unused, replicated)
    local netID = bagName:gsub('entity:', '')
    local entNet = tonumber(netID)
    
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local localID = NetworkGetNetworkIdFromEntity(vehicle)

        if entNet == localID and ValidateVehicle(playerPed, vehicle) then
            SendNUIMessage({
                setRearStatus = true,
                status = value,
            })

            RearActive = value
            print("rearactive", value)
        end
    end
end)

AddStateBagChangeHandler('speedrecording', nil, function(bagName, key, value, _unused, replicated)
    local netID = bagName:gsub('entity:', '')
    local entNet = tonumber(netID)
    
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local localID = NetworkGetNetworkIdFromEntity(vehicle)
        
        if entNet == localID and ValidateVehicle(playerPed, vehicle) then
            SendNUIMessage({
                ToggleRecording = true,
                isRecording = value,
            })

            IsSpeedRecording = value

            speeds = {}
            lastSpeed = 0

            print("speedrecording", value)
        end
    end
end)

AddStateBagChangeHandler('averagespeed', nil, function(bagName, key, value, _unused, replicated)
    local netID = bagName:gsub('entity:', '')
    local entNet = tonumber(netID)
    
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local localID = NetworkGetNetworkIdFromEntity(vehicle)
        
        if entNet == localID and ValidateVehicle(playerPed, vehicle) then
            SendNUIMessage({
                setAverageSpeed = true,
                averageSpeed = value,
            })

            speeds = {}
            lastSpeed = 0

            print("averagespeed", value)
        end
    end
end)
