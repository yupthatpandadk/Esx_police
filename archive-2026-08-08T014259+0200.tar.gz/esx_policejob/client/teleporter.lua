--[[local elevatorsLoc = {
    {loc = vector3(463.6297, -985.4273, 34.2973)},
    {loc = vector3(468.3418, -984.1045, 43.6931)},
}
local teleportTo = {
    {loc = vector3(461.5320, -985.2590, 34.2974)},
    {loc = vector3(466.2461, -984.0547, 43.6928)},
}
isInMarker = nil

Citizen.CreateThread(function()
    while true do
        local sleep = 5000
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        for i=1, #elevatorsLoc, 1 do
            if GetDistanceBetweenCoords(playerCoords, elevatorsLoc[i].loc, false) <= Config.DrawDistance then
                sleep = 1
                DrawMarker(20, elevatorsLoc[i].loc,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.5, 0.5, 0.5,
                30, 3, 187, 200,
                false, true, 2, false, nil, nil, false)
    
                if GetDistanceBetweenCoords(playerCoords, elevatorsLoc[i].loc, true) < 0.6 then
                    isInMarker = true
                    exports['id_helpnotify']:showUI('Tryk <b>[E]</b> for at tilgå elevator menuen')
                    if IsControlJustPressed(0, 51) then
                        lib.registerContext({
                            id = 'mrpd_elevator',
                            title = 'Politi - Elevator',
                            onExit = function()
                            end,
                            options = {
                                {
                                    title = 'Etage 2 - Kantine mm.',
                                    onSelect = function(args)
                                        lib.hideContext(onExit)
                                        DoScreenFadeOut(500)
                                        Citizen.Wait(3500)
                                        DoScreenFadeIn(500)
                                        SetEntityCoords(PlayerPedId(), teleportTo[1].loc.x, teleportTo[1].loc.y, teleportTo[1].loc.z)
                                    end
                                },
                                {
                                    title = 'Etage 3 - Helikopter plads.',
                                    onSelect = function(args)
                                        lib.hideContext(onExit)
                                        DoScreenFadeOut(500)
                                        Citizen.Wait(3500)
                                        DoScreenFadeIn(500)
                                        SetEntityCoords(PlayerPedId(), teleportTo[2].loc.x, teleportTo[2].loc.y, teleportTo[2].loc.z)
                                    end
                                }
                            }
                        })
                        lib.showContext('mrpd_elevator')
                    end
                elseif isInMarker then
                    exports['id_helpnotify']:hideUI()
                    isInMarker = false
                end
            end
        end

        Wait(sleep)
    end
end)]]

local teleportCoords = {
    { pos = vec3(-1096.9678, -848.0037, 4.8841), etage = -1, elevator = 1},
    { pos = vec3(-1096.9382, -847.9786, 10.2769), etage = -2, elevator = 1},
    { pos = vec3(-1096.9305, -847.9816, 13.6870), etage = -3, elevator = 1},
    { pos = vec3(-1096.9658, -847.9829, 19.0015), etage = 1, elevator = 1},
    { pos = vec3(-1096.9691, -847.9167, 23.0384), etage = 2, elevator = 1},
    { pos = vec3(-1096.9515, -847.9388, 26.8274), etage = 3, elevator = 1},
    { pos = vec3(-1096.9634, -847.9803, 30.7570), etage = 4, elevator = 1},
    { pos = vec3(-1096.9926, -847.9963, 34.3610), etage = 5, elevator = 1},
    { pos = vec3(-1097.0382, -847.8898, 38.0080), etage = 6, elevator = 1},

    { pos = vec3(-1066.8193, -831.3344, 5.4797), etage = -1, elevator = 2},
    { pos = vec3(-1066.8035, -831.3165, 11.0366), etage = -2, elevator = 2},
    { pos = vec3(-1066.8098, -831.2919, 14.8830), etage = -3, elevator = 2},
    { pos = vec3(-1066.9727, -831.3208, 19.0359), etage = 1, elevator = 2},
    { pos = vec3(-1066.8571, -831.3552, 27.0364), etage = 3, elevator = 2},
}

GetDisabled = function (etage, etage2)
    if etage == etage2 then
        return true
    end
    return false  
end
GetName = function (etage, etage2, option, name)
    if option == 'NAME' then
        if etage == etage2 then
            return name..' - Nuværende Etage'
        end
        return name  
    end
end

for i=1, #teleportCoords, 1 do
    exports.ox_target:addBoxZone({
        coords = teleportCoords[i].pos,
        size = vec3(0.7, 0.7, 2),
        rotation = 1.1218,
        debug = false,
        options = {
            {
                icon = 'fa-solid fa-elevator',
                label = 'Elevator Menu',
                onSelect = function(data)
                    ESX.TriggerServerCallback('Emil_policejob:codes:getCodes', function(num)
                        if ESX.GetPlayerData().job.name ~= 'police' then
                            local input = lib.inputDialog('Kode', {
                                {type = 'number', label = 'Indtast den nuværende kode.', description = 'Indtast den nuværende kode, som kan fås af en betjent.', icon = 'hashtag'}
                            })
                               
                            if input[1] == num then
                                ElevatorMenu(num, i)
                            end
                        end
                        ElevatorMenu(num, i)
                    end)
                end
            }
        }
    })
end

ElevatorMenu = function(num, i)
    if teleportCoords[i].elevator == 1 then
        lib.registerContext({
            id = 'some_menu5',
            title = 'Elevator Menu',
            options = {
                {
                    title = 'Nuværende Kode: '..num,
                    icon = 'fa-solid fa-elevator'
                },
                {
                    title = GetName(-1, teleportCoords[i].etage, 'NAME', 'Etage -1'),
                    disabled = GetDisabled(-1, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.9429, -848.1264, 4.8841), 36.3010)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Celler'},
                        {label = 'Etagen', value = 'Identifikationsrum'},
                        {label = 'Etagen', value = 'Forhørs Lokaler'},
                        {label = 'Etagen', value = 'Garage'}
                    }
                },
                {
                    title = GetName(-2, teleportCoords[i].etage, 'NAME', 'Etage -2'),
                    disabled = GetDisabled(-2, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.6897, -848.3799, 10.2768), 34.4827)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Kriminal Laboratorium'},
                        {label = 'Etagen', value = 'Bevis Lokale'}
                    }
                },
                {
                    title = GetName(-3, teleportCoords[i].etage, 'NAME', 'Etage -3'),
                    disabled = GetDisabled(-3, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.7446, -848.3798, 13.6869), 43.5449)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Garage'},
                        {label = 'Etagen', value = 'Våben Kammer'}
                    }
                },
                {
                    title = GetName(1, teleportCoords[i].etage, 'NAME', 'Etage 1'),
                    disabled = GetDisabled(1, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.7603, -848.5944, 19.0014), 216.2820)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Hovedindgang'},
                        {label = 'Etagen', value = 'Studie'},
                        {label = 'Etagen', value = 'Interview Rum'},
                        {label = 'Etagen', value = 'Konferencelokale'}
                    }
                },
                {
                    title = GetName(2, teleportCoords[i].etage, 'NAME', 'Etage 2'),
                    disabled = GetDisabled(2, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.8911, -848.2362, 23.0384), 37.4073)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Statsadvokater'},
                        {label = 'Etagen', value = 'Café'}
                    }
                },
                {
                    title = GetName(3, teleportCoords[i].etage, 'NAME', 'Etage 3'),
                    disabled = GetDisabled(3, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.5266, -848.6927, 26.8275), 42.2498)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Fitness Center'},
                        {label = 'Etagen', value = 'Kontorer'},
                        {label = 'Etagen', value = 'Omklædningsrum'},
                        {label = 'Etagen', value = 'Briefing Lokale'}
                    }
                },
                {
                    title = GetName(4, teleportCoords[i].etage, 'NAME', 'Etage 4'),
                    disabled = GetDisabled(4, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.8951, -848.3204, 30.7570), 39.3109)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Alarm Centralen'},
                        {label = 'Etagen', value = 'Inspektør\'s Kontor'},
                        {label = 'Etagen', value = 'Kontorer'}
                    }
                },
                {
                    title = GetName(5, teleportCoords[i].etage, 'NAME', 'Etage 5'),
                    disabled = GetDisabled(5, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.7415, -848.3472, 34.3609), 37.9345)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Kriminalpolitiet'},
                        {label = 'Etagen', value = 'Ledelses Kontor'},
                        {label = 'Etagen', value = 'Kontorer'}
                    }
                },
                {
                    title = GetName(6, teleportCoords[i].etage, 'NAME', 'Etage 6'),
                    disabled = GetDisabled(6, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1097.6323, -848.3098, 38.0079), 26.9587)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Helikopter Plads'},
                        {label = 'Etagen', value = 'Tag'}
                    }
                },
            }
        })
        lib.showContext('some_menu5')
    elseif teleportCoords[i].elevator == 2 then
        lib.registerContext({
            id = 'some_menu5',
            title = 'Elevator Menu',
            options = {
                {
                    title = 'Nuværende Kode: '..num,
                    icon = 'fa-solid fa-elevator'
                },
                {
                    title = GetName(-1, teleportCoords[i].etage, 'NAME', 'Etage -1'),
                    disabled = GetDisabled(-1, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1067.6027, -831.7144, 5.4797), 39.3842)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Celler'},
                        {label = 'Etagen', value = 'Identifikationsrum'},
                        {label = 'Etagen', value = 'Forhørs Lokaler'},
                        {label = 'Etagen', value = 'Garage'}
                    }
                },
                {
                    title = GetName(-2, teleportCoords[i].etage, 'NAME', 'Etage -2'),
                    disabled = GetDisabled(-2, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1067.6649, -831.6489, 11.0365), 32.3256)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Kriminal Laboratorium'},
                        {label = 'Etagen', value = 'Bevis Lokale'}
                    }
                },
                {
                    title = GetName(-3, teleportCoords[i].etage, 'NAME', 'Etage -3'),
                    disabled = GetDisabled(-3, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1067.7062, -831.6122, 14.8830), 43.5574)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Garage'},
                        {label = 'Etagen', value = 'Våben Kammer'}
                    }
                },
                {
                    title = GetName(1, teleportCoords[i].etage, 'NAME', 'Etage 1'),
                    disabled = GetDisabled(1, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1067.6283, -831.6674, 19.0358), 36.2855)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Hovedindgang'},
                        {label = 'Etagen', value = 'Studie'},
                        {label = 'Etagen', value = 'Interview Rum'},
                        {label = 'Etagen', value = 'Konferencelokale'}
                    }
                },
                {
                    title = GetName(3, teleportCoords[i].etage, 'NAME', 'Etage 3'),
                    disabled = GetDisabled(3, teleportCoords[i].etage),
                    description = 'Vespucci Politi Station',
                    icon = 'fa-solid fa-elevator',
                    onSelect = function()
                        Teleport(vec3(-1067.6357, -831.8009, 27.0364), 36.5075)
                    end,
                    metadata = {
                        {label = 'Etagen', value = 'Fitness Center'},
                        {label = 'Etagen', value = 'Kontorer'},
                        {label = 'Etagen', value = 'Omklædningsrum'},
                        {label = 'Etagen', value = 'Briefing Lokale'}
                    }
                },
            }
        })
        lib.showContext('some_menu5')
    end
end

Teleport = function (coords, heading)
    DoScreenFadeOut(500)
    Citizen.Wait(2500)
    DoScreenFadeIn(500)
    SetEntityCoords(PlayerPedId(), vec3(coords.x, coords.y, coords.z - 0.90))
    SetEntityHeading(PlayerPedId(), heading)
end